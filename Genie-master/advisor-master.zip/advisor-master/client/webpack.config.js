const path = require('path');

const isDev = process.env.NODE_ENV !== 'production';
const MiniCssExtractPlugin = require('mini-css-extract-plugin');
const Dotenv = require('dotenv-webpack');
const env = process.env.NODE_ENV;
const env_str = `./.env.${env}`
console.log(env_str);

module.exports = {
    mode: isDev ? "development" : "production",
    entry: [path.resolve(__dirname, 'src','index.js')],
    module: {
      rules: [
          {
              test: /\.jsx?$/,
              exclude: /(node_modules|bower_components)/,
              use: {
                loader: "babel-loader"
              }
          },
          {
            test: /\.module\.s(a|c)ss$/,
            loader: [
              //isDev ? 'style-loader' : MiniCssExtractPlugin.loader,
              'style-loader',
              {
                loader: 'css-loader',
                options: {
                  modules: true,
                  sourceMap: isDev
                }
              },
              {
                loader: 'sass-loader',
                options: {
                  sourceMap: isDev
                }
              }
            ],
            sideEffects: true
          },
          {
            test: /\.s(a|c)ss$/,
            exclude: /\.module.(s(a|c)ss)$/,
            loader: [
              //isDev ? 'style-loader' : MiniCssExtractPlugin.loader,
              'style-loader',
              'css-loader',
              {
                loader: 'sass-loader',
                options: {
                  sourceMap: isDev
                }
              }
            ],
            sideEffects: true
          }
      ]
    },
    resolve: {
      extensions:['.js','.jsx','.scss']
    },
    plugins: [
      new MiniCssExtractPlugin({
        filename: '[name].css',
        chunkFilename: '[id].css'}
      ),
      new Dotenv({
        path: `./.env.${env}`
      })
    ],
    output: {
        path: path.resolve(__dirname, "static/client/public/"),
        publicPath: "/static/client/public/",
        filename: 'main.js',
    },
    devServer: {
      contentBase: path.join(__dirname,"/"),
      port: 3000,
      publicPath: "http://locahost:3000/static/client/public",
      hotOnly: true,
      hot: true,
      historyApiFallback: true
    }
};