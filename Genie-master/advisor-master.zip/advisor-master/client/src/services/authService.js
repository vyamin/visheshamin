import {advisorWS} from '../apis'

export const authService = {
  createToken,
  forgotPassword,
  resetPassword
}

//params = {email,password}
async function createToken(params){
  try {
    // await new Promise((resolve, reject) => setTimeout(resolve, 10000));
    const response = await advisorWS.genie.post('/api/jwt/create/',params);
    const token = response.data;
    return token
  }
  catch (error){
    let errMessage = "Something went wrong. Try after some time"
    if(error.response && error.response.data)
      errMessage = Object.values(error.response.data).join();
    throw Error(errMessage)
  }
}

//params = {email}
async function forgotPassword(params){
  try {
    const response = await advisorWS.genie.post('/api/users/reset_password/',params);
    return response
  }
  catch (error){
    let errMessage = "Something went wrong. Try after some time"
    if(error.response && error.response.data)
      errMessage = Object.values(error.response.data).join();
    throw Error(errMessage)
  }
}

//params = {uid,token,password}
async function resetPassword(params){
  try {
    const response = await advisorWS.genie.post('/api/users/reset_password_confirm/',params);
    return response
  }
  catch (error){
    let errMessage = "Something went wrong. Try after some time"
    if(error.response && error.response.data)
      errMessage = Object.values(error.response.data).join();
    throw Error(errMessage)
  }
}