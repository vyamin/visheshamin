import {authConstants} from '../constants'

const INITIAL_STATE = {
  user: {},
  isAuthenticated: false,
  working: false,
  protectedPathUrl: '/',
  forgotPasswordWorking: false,
  resettingPassword:false,
}
let readin_state = {...INITIAL_STATE}
let user = JSON.parse(localStorage.getItem('user'))
if (user && user.access){
  readin_state.user = user;
  readin_state.isAuthenticated = true;
}


export default (state = readin_state, action) => {
  switch(action.type){

    case authConstants.USER_LOGIN_REQUEST:
      return {...state,working:true}
    case authConstants.USER_LOGIN_FAILURE:
      return {...state,working:false}
    case authConstants.USER_LOGIN_SUCCESS:{
      const user = action.payload;
      localStorage.setItem('user',JSON.stringify(user));
      return {...state,user:user,working:false,isAuthenticated:true}
    }
    case authConstants.PROTECTED_PATH_REDIRECT:
      return {...state,protectedPathUrl:action.payload}


    case authConstants.FORGOT_PASSWORD_REQUEST:
      return {...state,forgotPasswordWorking:true}
    case authConstants.FORGOT_PASSWORD_FAILURE:
      return {...state,forgotPasswordWorking:false}
    case authConstants.FORGOT_PASSWORD_SUCCESS:
      return {...state,forgotPasswordWorking:false}
    
    case authConstants.RESET_PASSWORD_REQUEST:
      return {...state,resettingPassword:true}
    case authConstants.RESET_PASSWORD_FAILURE:
      return {...state,resettingPassword:false}
    case authConstants.RESET_PASSWORD_SUCCESS:
      return {...state,resettingPassword:false}
  
    case authConstants.USER_LOGOUT:
    localStorage.removeItem('user');
    return {...INITIAL_STATE};

    default:
      return state
  }
}