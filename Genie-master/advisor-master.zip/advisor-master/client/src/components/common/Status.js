import React from 'react';
export class Status extends React.Component{
  render() {
    return(
        <div>
          Status Dashboard
        </div>
    )  
  }
}