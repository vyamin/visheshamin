import {hot} from 'react-hot-loader/root';
import React from 'react';
import { connect } from 'react-redux';
import {Router,Route,Switch} from 'react-router-dom'
import {Container,Alert} from 'react-bootstrap';

import {history} from '../helpers';
import {alertActions} from '../actions';
import {Header} from '.';
import {Status,Login} from './common';



class App extends React.Component {
  constructor(props){
    super(props);
    const {dispatch} = this.props;
    history.listen((location,action)=> {
      dispatch(alertActions.clear())
    });
  }
  render() {
    const alert = this.props.alert;
    return (
      <Container style={{maxWidth:1280}}>
        <Router history={history}>
          <div>
            <Header/>
            {
              alert.message && 
                <Alert header={alert.messaage} variant={alert.type}>
                  {alert.message}
                </Alert>
            }
            <Switch>
              <Route path='/' exact component={Status} />
              <Route path='/login/' exact component={Login} />
            </Switch>
          </div>
        </Router>
      </Container>
    )
  }
}

const hotApp = hot(App)
if (module.hot) {
  module.hot.accept();
}
const mapStateToProps = (state,ownProps)=> {
  return {
    alert: state.alert
  }
}

const connectedApp = connect(mapStateToProps,null)(hotApp)
export {connectedApp as App};