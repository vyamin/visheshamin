import { createBrowserHistory } from 'history';

const browserHistory = createBrowserHistory()
export {browserHistory as history};