from rest_framework import viewsets
from rest_framework.filters import SearchFilter,OrderingFilter
from rest_framework.permissions import IsAdminUser
from rest_framework import mixins
from rest_framework.viewsets import GenericViewSet

from core.permissions import ReadOnly,IsWorker
from core.models import WorkerEvent
from core.serializers import WorkerEventSerializer

class WorkerEventViewSet(mixins.CreateModelMixin,
                   mixins.RetrieveModelMixin,
                   mixins.ListModelMixin,
                   GenericViewSet):
  queryset = WorkerEvent.objects.all()
  serializer_class = WorkerEventSerializer
  permission_classes = [IsAdminUser|IsWorker|ReadOnly]
  filter_backends = [SearchFilter,OrderingFilter]
  search_fields = ['worker','category']
  ordering_fields = ['worker','category','event_type','event_time']
  ordering = ('-event_time')



