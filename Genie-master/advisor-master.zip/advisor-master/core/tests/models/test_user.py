import pytest
from django.contrib.auth import get_user_model

@pytest.mark.django_db
def test_create_user():
  User = get_user_model()
  user = User.objects.create_user(email='example@example.com',password="SomePass123")
  assert user.email == 'example@example.com'
  assert user.is_active == True
  assert user.is_staff == False
  assert user.is_superuser == False

@pytest.mark.django_db
def test_create_superuser():
  User = get_user_model()
  admin_user = User.objects.create_superuser('super@example.com','SomePass123')
  assert admin_user.email == 'super@example.com'
  assert admin_user.is_active == True
  assert admin_user.is_staff == True
  assert admin_user.is_superuser == True