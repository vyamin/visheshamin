import pytest
import factory

from core.tests.fixtures.common_fixtures import *
from core.tests.factories import UserFactory,UserWithPasswordFactory
from rest_framework import status
from django.urls import reverse


@pytest.mark.django_db
def test_register_user(api_client):
  user_dict = factory.build(dict,FACTORY_CLASS=UserWithPasswordFactory)
  response = api_client.post('/api/users/',data=user_dict)
  assert response.status_code == status.HTTP_201_CREATED
  new_user = response.data
  assert new_user['id'] is not None
  assert new_user['name'] == user_dict['name']
  assert new_user['email'] == user_dict['email']

@pytest.mark.django_db
def test_create_token(api_client,create_user):
  user = create_user(email='some_user@example.com',name='Some User',password='SomePass123')
  response = api_client.post(reverse('jwt_create'),data={'email':'some_user@example.com','password':'SomePass123'})
  assert response.status_code == status.HTTP_200_OK
  assert response.data['access'] is not None
  assert response.data['id'] == user.id
  assert response.data['name'] == user.name

@pytest.mark.django_db
def test_refresh_token(api_client,create_user):
  user = create_user(email='some_user@example.com',name='Some User',password='SomePass123')
  response = api_client.post(reverse('jwt_create'),data={'email':'some_user@example.com','password':'SomePass123'})
  refresh_token = response.data['refresh']
  response = api_client.post(reverse('jwt_refresh'),data={'refresh':refresh_token})
  assert response.status_code == status.HTTP_200_OK
  assert response.data['access'] is not None
  assert response.data['refresh'] is not None

@pytest.mark.django_db
def test_current_user_unauthenticated(api_client):
  response = api_client.get('/api/users/me/')
  assert response.status_code == status.HTTP_401_UNAUTHORIZED

@pytest.mark.django_db
def test_current_user_authenticated(api_client_with_cred):
  response = api_client_with_cred.get('/api/users/me/')
  assert response.status_code == status.HTTP_200_OK
  user = response.data
  assert user['id'] is not None
  assert user['name'] is not None
  assert user['email'] is not None

@pytest.mark.django_db
def test_current_user_with_token(api_client,create_user):
  user = create_user(email='some_user@example.com',name='Some User',password='SomePass123')
  response = api_client.post(reverse('jwt_create'),data={'email':'some_user@example.com','password':'SomePass123'})
  token = response.data['access']
  api_client.credentials(HTTP_AUTHORIZATION='Bearer ' + token)
  response = api_client.get('/api/users/me/')
  assert response.status_code == status.HTTP_200_OK
  assert response.data['name'] is not None
  assert response.data['id'] is not None
  assert response.data['email'] is not None

@pytest.mark.django_db
def test_user_list_should_have_only_one_entry(api_client_with_cred,create_user):
  other_user = create_user(email='someotheruer@example.com',password="somestring@123")
  response= api_client_with_cred.get('/api/users/')
  assert len(response.data)==1