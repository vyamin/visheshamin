from rest_framework_simplejwt.serializers import TokenObtainPairSerializer

class MyTokenObtainPairSerializer(TokenObtainPairSerializer):
  def validate(self,attrs):
    data = super().validate(attrs)
    data['id'] = self.user.id
    data['name'] = self.user.name
    return data