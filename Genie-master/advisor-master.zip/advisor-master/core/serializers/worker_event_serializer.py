from rest_framework import serializers
from core.models import WorkerEvent

class WorkerEventSerializer(serializers.ModelSerializer):
  class Meta:
    model = WorkerEvent
    fields = "__all__"
