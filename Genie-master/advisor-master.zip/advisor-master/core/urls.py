from django.urls import path,include
from rest_framework.routers import DefaultRouter
from rest_framework_simplejwt import views as jwt_views
from core.views import MyObtainTokenPairView
from core.views import worker_event_views


router = DefaultRouter()
router.register('events',worker_event_views.WorkerEventViewSet,basename='event')


urlpatterns = [
  path('',include('djoser.urls')),
  path('',include(router.urls)),
  path('jwt/create/',MyObtainTokenPairView.as_view(),name="jwt_create"),
  path('jwt/refresh/',jwt_views.TokenRefreshView.as_view(),name="jwt_refresh"),
  path('jwt/verify/',jwt_views.TokenVerifyView.as_view(),name="jwt_verify"),
]
