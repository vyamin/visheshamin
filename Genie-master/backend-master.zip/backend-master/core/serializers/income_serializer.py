from rest_framework import serializers
from core.models import Income

class IncomeSerializer(serializers.ModelSerializer):

    amount = serializers.FloatField()
    user = serializers.HiddenField(
        default=serializers.CurrentUserDefault())

    class Meta:
        model = Income
        fields = "__all__"
