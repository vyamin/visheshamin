from rest_framework import serializers
from core.models import Projection

class ProjectionSerializer(serializers.ModelSerializer):
    class Meta:
        model = Projection
        fields = '__all__'
    