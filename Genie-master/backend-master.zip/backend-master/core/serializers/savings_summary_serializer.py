from rest_framework import serializers
from core.models import SavingsSummary

class SavingsSummarySerializer(serializers.ModelSerializer):

    monthly_savings_goal = serializers.FloatField()
    current_monthly_savings = serializers.FloatField()
    
    user = serializers.HiddenField(
        default=serializers.CurrentUserDefault())    

    class Meta:
        model = SavingsSummary
        fields = '__all__'

