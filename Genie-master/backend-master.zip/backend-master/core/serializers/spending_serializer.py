from rest_framework import serializers
from core.models import Spending

class SpendingSerializer(serializers.ModelSerializer):

    amount = serializers.FloatField()
    user = serializers.HiddenField(
        default=serializers.CurrentUserDefault())

    class Meta:
        model = Spending
        fields = "__all__"
