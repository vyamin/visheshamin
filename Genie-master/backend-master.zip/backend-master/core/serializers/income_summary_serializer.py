from rest_framework import serializers
from core.models import IncomeSummary

class IncomeSummarySerializer(serializers.ModelSerializer):
    projected_monthly_income = serializers.FloatField()
    amount_earned_this_month = serializers.FloatField()
    user = serializers.HiddenField(
        default=serializers.CurrentUserDefault())
               
    class Meta:
        model = IncomeSummary
        fields = '__all__'