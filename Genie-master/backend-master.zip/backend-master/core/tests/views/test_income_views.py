import pytest

from django.urls import reverse
from rest_framework import status
from core.models import Income
from core.serializers import IncomeSerializer
from core.tests.fixtures.common_fixtures import *
from core.tests.factories import IncomeFactory,UserFactory

@pytest.mark.django_db
def test_income_list(api_client_with_cred,the_user):
    for i in range(3):
        IncomeFactory(user=the_user)
    response = api_client_with_cred.get(reverse('income-list'))
    assert response.status_code == status.HTTP_200_OK
    assert len(response.data)==3

@pytest.mark.django_db
def test_income_list_other_user(api_client_with_cred):
    user = UserFactory()
    for i in range(3):
        IncomeFactory(user=user)
    response = api_client_with_cred.get(reverse('income-list'))
    assert len(response.data)==0

@pytest.mark.django_db
def test_income_create(api_client_with_cred,the_user):
    income = IncomeFactory.build(user=the_user)
    data = IncomeSerializer(income).data
    response = api_client_with_cred.post(reverse('income-list'),data)
    assert response.status_code == status.HTTP_201_CREATED
    assert response.data['label'] == income.label

@pytest.mark.django_db
def test_income_create_other_user(api_client_with_cred,the_user):
    user = UserFactory()
    income = IncomeFactory.build(user=user)
    data = IncomeSerializer(income).data
    response = api_client_with_cred.post(reverse('income-list'),data)
    assert response.status_code == status.HTTP_201_CREATED
    assert user.incomes.count() == 0
    assert the_user.incomes.count() == 1

@pytest.mark.django_db
def test_income_retrieve(api_client_with_cred,the_user):
    income = IncomeFactory(user=the_user)
    response = api_client_with_cred.get(reverse('income-detail',args=[income.id]))
    assert response.status_code == status.HTTP_200_OK
    assert response.data['amount'] == float(income.amount)
    assert response.data['label'] == income.label

@pytest.mark.django_db
def test_income_retrieve_other_user(api_client_with_cred):
    income = IncomeFactory()
    response = api_client_with_cred.get(reverse('income-detail',args=[income.id]))
    assert response.status_code == status.HTTP_404_NOT_FOUND

@pytest.mark.django_db
def test_income_update(api_client_with_cred,the_user):
    income = IncomeFactory(user=the_user)
    income.amount = 123.45
    data = IncomeSerializer(income).data
    response = api_client_with_cred.put(reverse('income-detail',
                    args=[income.id]),data)
    assert response.status_code == status.HTTP_200_OK
    assert response.data['amount'] == 123.45
    assert response.data['label'] == income.label

@pytest.mark.django_db
def test_income_update_other_user(api_client_with_cred):
    income = IncomeFactory()
    income.amount = 123.45
    data = IncomeSerializer(income).data
    response = api_client_with_cred.put(reverse('income-detail',
                    args=[income.id]),data)
    assert response.status_code == status.HTTP_404_NOT_FOUND

@pytest.mark.django_db
def test_income_partial_update(api_client_with_cred,the_user):
    income = IncomeFactory(user=the_user)
    data = {'amount': 123.45}
    response = api_client_with_cred.patch(reverse(
        'income-detail',args=[income.id]),data)
    assert response.status_code == status.HTTP_200_OK
    assert response.data['amount'] == 123.45

@pytest.mark.django_db
def test_income_partial_update_other_user(api_client_with_cred,the_user):
    income = IncomeFactory()
    data = {'amount': 123.45}
    response = api_client_with_cred.patch(reverse(
        'income-detail',args=[income.id]),data)
    assert response.status_code == status.HTTP_404_NOT_FOUND


@pytest.mark.django_db
def test_income_destroy(api_client_with_cred,the_user):
    income = IncomeFactory(user=the_user)
    response = api_client_with_cred.delete(reverse(
                    'income-detail',args=[income.id]))
    assert response.status_code == status.HTTP_204_NO_CONTENT
    assert Income.objects.count() == 0

@pytest.mark.django_db
def test_income_destroy_other_user(api_client_with_cred):
    income = IncomeFactory()
    response = api_client_with_cred.delete(reverse(
                    'income-detail',args=[income.id]))
    assert response.status_code == status.HTTP_404_NOT_FOUND
    assert Income.objects.count() == 1
