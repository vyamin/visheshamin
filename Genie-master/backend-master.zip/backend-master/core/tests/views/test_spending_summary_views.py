import pytest
from datetime import date,timedelta
from django.urls import reverse
from rest_framework import status

from core.models import SpendingSummary
from core.serializers import SpendingSummarySerializer,ProjectionSerializer
from core.tests.fixtures.common_fixtures import *
from core.tests.factories import SpendingSummaryFactory
from core.tests.factories import UserFactory,SpendingFactory
from core.tests.factories import PaymentFactory
from core.tests.factories.projection_factory import SpendingProjectionFactory


@pytest.mark.django_db
def test_spending_summary_digest(api_client_with_cred,the_user):
    response = api_client_with_cred.get(reverse('spending-summary-digest'))
    assert response.status_code == status.HTTP_200_OK
    assert 'projected_monthly_spending' in response.data['spending_summary']

@pytest.mark.django_db
def test_spending_summary_digest_includes_spendings(api_client_with_cred,the_user):
    spending_summary = SpendingSummary(user = the_user)
    for i in range(3):
        SpendingFactory(user=the_user)
    response = api_client_with_cred.get(reverse('spending-summary-digest'))
    assert response.data['spending_summary'] is not None
    assert len(response.data['spendings']) == 3

@pytest.mark.django_db
def test_spending_summary_digest_includes_upcoming_payments(
                                api_client_with_cred,the_user):
    spending_summary = SpendingSummary(user = the_user)
    for i in range(3):
        PaymentFactory(user=the_user,
            due_date = date.today()+timedelta(days = (i+1)*30) )
    response = api_client_with_cred.get(reverse('spending-summary-digest'))
    assert response.data['spending_summary'] is not None
    assert len(response.data['upcoming_payments']) == 3    

@pytest.mark.django_db
def test_spending_summary_digest_includes_spending_projections(api_client_with_cred,the_user):
    spending_summary = SpendingSummary(user = the_user)
    for i in range(4):
        SpendingProjectionFactory(user=the_user)
    response = api_client_with_cred.get(reverse('spending-summary-digest'))
    assert response.data['spending_summary'] is not None
    assert len(response.data['spending_projections']) == 4   

@pytest.mark.django_db
def test_spending_summary_get_nonadmin_user(api_client_with_cred,the_user):
  spending_summary = the_user.spendingsummary
  spending_summary.projected_monthly_spending=4000
  spending_summary.amount_earned_this_month=2000
  spending_summary.save()
  response = api_client_with_cred.get(reverse('spending-summary'))
  new_spending_summary = response.data
  assert response.status_code == status.HTTP_200_OK
  assert new_spending_summary['projected_monthly_spending'] == spending_summary.projected_monthly_spending

@pytest.mark.django_db
def test_spending_summary_get_worker(api_client_with_worker_cred,the_worker):
  response = api_client_with_worker_cred.get(reverse('spending-summary'))
  assert response.status_code == status.HTTP_200_OK

@pytest.mark.django_db
def test_spending_summary_get_admin_user(api_client_with_admin_cred,the_admin_user):
  response = api_client_with_admin_cred.get(reverse('spending-summary'))
  assert response.status_code == status.HTTP_200_OK

@pytest.mark.django_db
def test_spending_summary_update_nonadmin_user(api_client_with_cred,the_user):
  data = {'projected_monthly_spending':2000}
  response = api_client_with_cred.patch(reverse('spending-summary'),data)
  assert response.status_code == status.HTTP_403_FORBIDDEN

@pytest.mark.django_db
def test_spending_summary_update_worker(api_client_with_worker_cred,the_worker):
  data = {'projected_monthly_spending':2000}
  response = api_client_with_worker_cred.patch(reverse('spending-summary'),data)
  assert response.status_code == status.HTTP_200_OK
  assert response.data['projected_monthly_spending'] == 2000

@pytest.mark.django_db
def test_spending_summary_update_admin_user(api_client_with_admin_cred,the_admin_user):
  data = {'projected_monthly_spending':2000}
  response = api_client_with_admin_cred.patch(reverse('spending-summary'),data)
  assert response.status_code == status.HTTP_200_OK
  assert response.data['projected_monthly_spending'] == 2000

@pytest.mark.django_db
def test_spending_projections_get_nonadmin_user(api_client_with_cred,the_user):
  projections = SpendingProjectionFactory.create_batch(12,user=the_user)
  response = api_client_with_cred.get(reverse('spending-projections'))
  assert response.status_code == status.HTTP_200_OK
  assert len(response.data) == 12

@pytest.mark.django_db
def test_spending_projections_get_worker(api_client_with_worker_cred,the_worker):
  projections = SpendingProjectionFactory.create_batch(12,user=the_worker)
  response = api_client_with_worker_cred.get(reverse('spending-projections'))
  assert response.status_code == status.HTTP_200_OK
  assert len(response.data) == 12  

@pytest.mark.django_db
def test_spending_projections_get_admin_user(api_client_with_admin_cred,the_admin_user):
  projections = SpendingProjectionFactory.create_batch(12,user=the_admin_user)
  response = api_client_with_admin_cred.get(reverse('spending-projections'))
  assert response.status_code == status.HTTP_200_OK
  assert len(response.data) == 12  

@pytest.mark.django_db
def test_spending_projections_post_nonadmin_user(api_client_with_cred,the_user):
  projections = SpendingProjectionFactory.build_batch(6)
  data = ProjectionSerializer(projections,many=True).data
  response = api_client_with_cred.post(reverse('spending-projections'),data)
  assert response.status_code == status.HTTP_403_FORBIDDEN

@pytest.mark.django_db
def test_spending_projections_post_worker(api_client_with_worker_cred,the_worker):
  SpendingProjectionFactory.create_batch(12,user=the_worker)
  projections = SpendingProjectionFactory.build_batch(6)
  data = ProjectionSerializer(projections,many=True).data
  response = api_client_with_worker_cred.post(reverse('spending-projections'),data)
  assert response.status_code == status.HTTP_201_CREATED
  assert len(response.data) == 6

@pytest.mark.django_db
def test_spending_projections_post_admin_user(api_client_with_admin_cred,the_admin_user):
  SpendingProjectionFactory.create_batch(12,user=the_admin_user)
  projections = SpendingProjectionFactory.build_batch(6)
  data = ProjectionSerializer(projections,many=True).data
  print(data)
  response = api_client_with_admin_cred.post(reverse('spending-projections'),data)
  assert response.status_code == status.HTTP_201_CREATED
  assert len(response.data) == 6
    


