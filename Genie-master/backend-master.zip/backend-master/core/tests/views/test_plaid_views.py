import pytest
import os
from rest_framework import status
from django.urls import reverse
from core.models import User,Institution,PlaidItem,Account
from core.tests.fixtures.common_fixtures import *
from core.tests.fixtures.plaid_fixtures import *
from core.tests.fixtures.plaid_response_fixtures import *
import plaid
from core.views import plaid_views
from django.db import transaction

@pytest.fixture
def mock_plaid_service(mocker,plaid_public_token,exchange_token_response,
    get_item_response,get_institution_response,
    get_accounts_response):
    class MockPlaidService():
        def __init__(self):
            self.exchange_token = mocker.patch.object(plaid_views.PlaidService,'exchange_token')
            self.exchange_token.return_value = True,exchange_token_response
            self.get_item = mocker.patch.object(plaid_views.PlaidService,'get_item')
            self.get_item.return_value = True,get_item_response
            self.get_institution = mocker.patch.object(plaid_views.PlaidService,'get_institution')
            self.get_institution.return_value = True,get_institution_response
            self.get_accounts = mocker.patch.object(plaid_views.PlaidService,'get_accounts')
            self.get_accounts.return_value = True,get_accounts_response

    return MockPlaidService()

@pytest.mark.django_db
def test_plaid_link_options_requires_auth(api_client):
    response = api_client.get(reverse('plaid-link-options'))
    assert response.status_code == status.HTTP_401_UNAUTHORIZED

@pytest.mark.django_db
def test_plaid_link_options_hash(api_client_with_cred):
    response = api_client_with_cred.get(reverse('plaid-link-options'))
    assert response.status_code == status.HTTP_200_OK
    assert 'env' in response.data
    assert 'key' in response.data
    assert 'product' in response.data

@pytest.mark.django_db
def test_plaid_access_token_requries_auth(api_client):
    response = api_client.post(reverse('plaid-get-access-token'))
    assert response.status_code == status.HTTP_401_UNAUTHORIZED

@pytest.mark.django_db
@pytest.mark.parametrize(
    'bad_public_token,status_code',[
        (None,400),
        ('',400)
    ]
)
def test_plaid_get_access_token_invalid_inputs(api_client_with_cred,bad_public_token,status_code):
    response = api_client_with_cred.post(reverse('plaid-get-access-token'),
                    data={'public_token':bad_public_token})
    assert response.status_code == status_code


@pytest.mark.django_db
def test_plaid_get_access_token_exchange_token_failed(api_client_with_cred,mock_plaid_service,plaid_public_token):
    mock_plaid_service.exchange_token.return_value = (False,'some error')

    response = api_client_with_cred.post(reverse('plaid-get-access-token'),
                data={'public_token':plaid_public_token})    
    
    mock_plaid_service.exchange_token.assert_called_once_with(plaid_public_token)
    assert response.status_code == status.HTTP_500_INTERNAL_SERVER_ERROR
    assert response.data == {'detail':'some error'}

@pytest.mark.django_db
def test_plaid_get_access_token_creates_plaid_item(api_client_with_cred,
        the_user,mock_plaid_service,plaid_public_token):

    response = api_client_with_cred.post(reverse('plaid-get-access-token'),
                data={'public_token':plaid_public_token})    
    
    assert response.status_code == status.HTTP_200_OK
    assert PlaidItem.objects.count() == 1
    assert the_user.plaid_items.count()== 1

@pytest.mark.django_db
def test_plaid_get_access_token_updates_access_token(api_client_with_cred,
            the_user,plaid_public_token,mock_plaid_service,plaid_item_id):
    '''
    If a plaid item already exists with the item id, then we should 
    just update that item and not create new one
    '''
    plaid_item = PlaidItem.objects.create(plaid_item_id=plaid_item_id,
                            plaid_access_token = 'some old token',
                            user = the_user)
    
    assert PlaidItem.objects.count()==1

    response = api_client_with_cred.post(reverse('plaid-get-access-token'),
                data={'public_token':plaid_public_token})    
    
    assert response.status_code == status.HTTP_200_OK
    assert PlaidItem.objects.count() == 1
    assert the_user.plaid_items.count()== 1   

@pytest.mark.django_db
def test_plaid_get_access_token_get_item_failure(api_client_with_cred,
            mock_plaid_service,plaid_public_token,plaid_access_token):
    '''
    Failure to get item will keep success for request, but will
    leave the item in the CREATED state
    '''
    mock_plaid_service.get_item.return_value = False,'Some Error'

    response = api_client_with_cred.post(reverse('plaid-get-access-token'),
                data={'public_token':plaid_public_token})    
    
    mock_plaid_service.get_item.assert_called_once_with(plaid_access_token)
    assert response.status_code == status.HTTP_200_OK
    assert PlaidItem.objects.first().status == PlaidItem.Status.CREATED

@pytest.mark.django_db
def test_plaid_get_access_token_get_institution_failure(api_client_with_cred,
            mock_plaid_service,plaid_public_token,plaid_institution_id):
    '''
    Failure to get institution will keep success for request, but will
    leave the item in the CREATED state
    '''
    mock_plaid_service.get_institution.return_value = False,'Some Error'

    response = api_client_with_cred.post(reverse('plaid-get-access-token'),
                data={'public_token':plaid_public_token})    
    
    mock_plaid_service.get_institution.assert_called_once_with(plaid_institution_id)
    assert response.status_code == status.HTTP_200_OK
    assert PlaidItem.objects.first().status == PlaidItem.Status.CREATED

@pytest.mark.django_db
def test_plaid_get_access_token_get_institution_is_not_called_if_exists(api_client_with_cred,
            mock_plaid_service,plaid_public_token,plaid_institution_id):
    '''
    The call to get institution details is required only if we do not have
    institution in the db. Else just use that.
    '''
    mock_plaid_service.get_institution.return_value = False,'Some Error'

    institution = Institution.objects.create(
                    plaid_institution_id=plaid_institution_id,
                    name = 'some name')

    response = api_client_with_cred.post(reverse('plaid-get-access-token'),
                data={'public_token':plaid_public_token})    
    
    mock_plaid_service.get_institution.assert_not_called()
    assert response.status_code == status.HTTP_200_OK

@pytest.mark.django_db
def test_plaid_get_access_token_creates_institution(api_client_with_cred,
            mock_plaid_service,plaid_public_token,plaid_institution_id):
    '''
    If we are dealing with a new institution, it is created in db
    '''
    response = api_client_with_cred.post(reverse('plaid-get-access-token'),
                data={'public_token':plaid_public_token})    
    assert Institution.objects.count() == 1
    assert response.status_code == status.HTTP_200_OK    

@pytest.mark.django_db
def test_plaid_get_access_token_get_accounts_failure(api_client_with_cred,
            mock_plaid_service,plaid_public_token,plaid_access_token):
    '''
    Get account failure should still lead to a success response
    '''
    mock_plaid_service.get_accounts.return_value = False,[]
    response = api_client_with_cred.post(reverse('plaid-get-access-token'),
                data={'public_token':plaid_public_token})    
    mock_plaid_service.get_accounts.assert_called_once_with(plaid_access_token)
    plaid_item = PlaidItem.objects.first()
    assert plaid_item.status == PlaidItem.Status.ENRICHED
    assert response.status_code == status.HTTP_200_OK  

@pytest.mark.django_db
def test_plaid_get_access_token_create_accounts_failure(api_client_with_cred,
            mock_plaid_service,mocker,plaid_public_token,plaid_access_token):
    '''
    Failure of create account should leave the plaid item in an enriched status
    '''
    create_accounts = mocker.patch.object(plaid_views.AccountService,'create_accounts')
    create_accounts.return_value = False,'Some reason'
    response = api_client_with_cred.post(reverse('plaid-get-access-token'),
                data={'public_token':plaid_public_token})    
    create_accounts.assert_called_once()
    plaid_item = PlaidItem.objects.first()
    assert plaid_item.status == PlaidItem.Status.ENRICHED
    assert response.status_code == status.HTTP_200_OK        


@pytest.mark.django_db
def test_plaid_get_access_token_create_accounts_success(api_client_with_cred,
            mock_plaid_service,mocker,plaid_public_token,plaid_access_token):
    '''
    Success in create account should leave the item in Active state
    '''
    response = api_client_with_cred.post(reverse('plaid-get-access-token'),
                data={'public_token':plaid_public_token})    
    plaid_item = PlaidItem.objects.first()
    assert plaid_item.status == PlaidItem.Status.ACTIVE
    assert response.status_code == status.HTTP_200_OK      
    assert Account.objects.count() > 0
  

@pytest.mark.django_db
def test_plaid_get_access_token_create_accounts_no_duplicates(api_client_with_cred,
            mock_plaid_service,mocker,plaid_public_token,plaid_access_token):
    '''
    Duplicate accounts are not created
    '''
    response = api_client_with_cred.post(reverse('plaid-get-access-token'),
                data={'public_token':plaid_public_token})    
    account_count = Account.objects.count()
    response = api_client_with_cred.post(reverse('plaid-get-access-token'),
                data={'public_token':plaid_public_token})    
    assert Account.objects.count() == account_count