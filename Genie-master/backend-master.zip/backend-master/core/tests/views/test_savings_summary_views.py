import pytest
from django.urls import reverse
from rest_framework import status

from core.models import SavingsSummary
from core.serializers import SavingsSummarySerializer,ProjectionSerializer
from core.tests.fixtures.common_fixtures import *
from core.tests.factories.savings_summary_factory import SavingsSummaryFactory
from core.tests.factories import SavingsProjectionFactory
from core.tests.factories.savings_goal_factory import SavingsGoalFactory

@pytest.mark.django_db
def test_savings_summary_retrieve(api_client_with_cred,the_user):
    ss = SavingsSummaryFactory(user=the_user)
    response = api_client_with_cred.get(reverse('savings-summary-digest'))
    assert response.status_code == status.HTTP_200_OK
    assert 'monthly_savings_goal' in response.data['savings_summary']

@pytest.mark.django_db
def test_savings_summary_retrieve_includes_projection(api_client_with_cred,the_user):
    ss = SavingsSummaryFactory(user=the_user)
    sp1 = SavingsProjectionFactory(user=the_user)
    sp2 = SavingsProjectionFactory(user=the_user)
    response = api_client_with_cred.get(reverse('savings-summary-digest'))
    assert response.status_code == status.HTTP_200_OK
    assert (float(response.data['savings_summary']['monthly_savings_goal'])== 
                float(ss.monthly_savings_goal))                
    assert (len(response.data['savings_projections'])==2)
    assert (float(response.data['savings_projections'][0]['amount'])==
                float(sp1.amount))


@pytest.mark.django_db
def test_savings_summary_retrieve_includes_savings_goals(api_client_with_cred,the_user):
    ss = SavingsSummaryFactory(user=the_user)
    sg1 = SavingsGoalFactory(user=the_user)
    sg2 = SavingsGoalFactory(user=the_user)
    sg3 = SavingsGoalFactory(user=the_user)
    response = api_client_with_cred.get(reverse('savings-summary-digest'))
    assert response.status_code == status.HTTP_200_OK
    assert (len(response.data['savings_goals'])==3)
    assert (float(response.data['savings_goals'][0]['amount'])==
                float(sg1.amount))                

@pytest.mark.django_db
def test_savings_summary_get_nonadmin_user(api_client_with_cred,the_user):
  savings_summary = the_user.savingssummary
  savings_summary.monthly_savings_goal=4000
  savings_summary.current_monthly_savings=2000
  savings_summary.save()
  response = api_client_with_cred.get(reverse('savings-summary'))
  new_savings_summary = response.data
  assert response.status_code == status.HTTP_200_OK
  assert new_savings_summary['monthly_savings_goal'] == savings_summary.monthly_savings_goal

@pytest.mark.django_db
def test_savings_summary_get_worker(api_client_with_worker_cred,the_worker):
  response = api_client_with_worker_cred.get(reverse('savings-summary'))
  assert response.status_code == status.HTTP_200_OK

@pytest.mark.django_db
def test_savings_summary_get_admin_user(api_client_with_admin_cred,the_admin_user):
  response = api_client_with_admin_cred.get(reverse('savings-summary'))
  assert response.status_code == status.HTTP_200_OK

@pytest.mark.django_db
def test_savings_summary_update_nonadmin_user(api_client_with_cred,the_user):
  data = {'monthly_savings_goal':2000}
  response = api_client_with_cred.patch(reverse('savings-summary'),data)
  assert response.status_code == status.HTTP_403_FORBIDDEN

@pytest.mark.django_db
def test_savings_summary_update_worker(api_client_with_worker_cred,the_worker):
  data = {'monthly_savings_goal':2000}
  response = api_client_with_worker_cred.patch(reverse('savings-summary'),data)
  assert response.status_code == status.HTTP_200_OK
  assert response.data['monthly_savings_goal'] == 2000

@pytest.mark.django_db
def test_savings_summary_update_admin_user(api_client_with_admin_cred,the_admin_user):
  data = {'monthly_savings_goal':2000}
  response = api_client_with_admin_cred.patch(reverse('savings-summary'),data)
  assert response.status_code == status.HTTP_200_OK
  assert response.data['monthly_savings_goal'] == 2000

@pytest.mark.django_db
def test_savings_projections_get_nonadmin_user(api_client_with_cred,the_user):
  projections = SavingsProjectionFactory.create_batch(12,user=the_user)
  response = api_client_with_cred.get(reverse('savings-projections'))
  assert response.status_code == status.HTTP_200_OK
  assert len(response.data) == 12

@pytest.mark.django_db
def test_savings_projections_get_worker(api_client_with_worker_cred,the_worker):
  projections = SavingsProjectionFactory.create_batch(12,user=the_worker)
  response = api_client_with_worker_cred.get(reverse('savings-projections'))
  assert response.status_code == status.HTTP_200_OK
  assert len(response.data) == 12  

@pytest.mark.django_db
def test_savings_projections_get_admin_user(api_client_with_admin_cred,the_admin_user):
  projections = SavingsProjectionFactory.create_batch(12,user=the_admin_user)
  response = api_client_with_admin_cred.get(reverse('savings-projections'))
  assert response.status_code == status.HTTP_200_OK
  assert len(response.data) == 12  

@pytest.mark.django_db
def test_savings_projections_post_nonadmin_user(api_client_with_cred,the_user):
  projections = SavingsProjectionFactory.build_batch(6)
  data = ProjectionSerializer(projections,many=True).data
  response = api_client_with_cred.post(reverse('savings-projections'),data)
  assert response.status_code == status.HTTP_403_FORBIDDEN

@pytest.mark.django_db
def test_savings_projections_post_worker(api_client_with_worker_cred,the_worker):
  SavingsProjectionFactory.create_batch(12,user=the_worker)
  projections = SavingsProjectionFactory.build_batch(6)
  data = ProjectionSerializer(projections,many=True).data
  response = api_client_with_worker_cred.post(reverse('savings-projections'),data)
  assert response.status_code == status.HTTP_201_CREATED
  assert len(response.data) == 6

@pytest.mark.django_db
def test_savings_projections_post_admin_user(api_client_with_admin_cred,the_admin_user):
  SavingsProjectionFactory.create_batch(12,user=the_admin_user)
  projections = SavingsProjectionFactory.build_batch(6)
  data = ProjectionSerializer(projections,many=True).data
  print(data)
  response = api_client_with_admin_cred.post(reverse('savings-projections'),data)
  assert response.status_code == status.HTTP_201_CREATED
  assert len(response.data) == 6
    


