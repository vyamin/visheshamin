import pytest
import factory

from core.tests.fixtures.common_fixtures import *
from core.tests.factories import UserFactory,UserWithPasswordFactory
from rest_framework import status
from django.urls import reverse

@pytest.mark.django_db
def test_register_user(api_client):
  user_dict = factory.build(dict,FACTORY_CLASS=UserWithPasswordFactory)
  response = api_client.post('/auth/users/',data=user_dict)
  assert response.status_code == status.HTTP_201_CREATED
  new_user = response.data
  assert new_user['id'] is not None
  assert new_user['name'] == user_dict['name']
  assert new_user['email'] == user_dict['email']

@pytest.mark.django_db
def test_create_token(api_client,create_user):
    user = create_user(email='testuser1@example.com',password='somepassword@123')
    response = api_client.post('/auth/jwt/create/',data={'email':'testuser1@example.com','password':'somepassword@123'})
    assert response.status_code == status.HTTP_200_OK

@pytest.mark.django_db
def test_refresh_token(api_client,create_user):
    user = create_user(email='testuser1@example.com',password='somepassword@123')
    response = api_client.post('/auth/jwt/create/',data={'email':'testuser1@example.com','password':'somepassword@123'})
    access_token=response.data['access']
    refresh_token = response.data['refresh']
    api_client.credentials(HTTP_AUTHORIZATION='Bearer '+access_token)
    response = api_client.post('/auth/jwt/refresh/',data={'refresh':refresh_token})
    assert response.status_code == status.HTTP_200_OK

@pytest.mark.django_db
def test_current_user_unauthenticated(api_client):
    response = api_client.get('/auth/users/me/')
    assert response.status_code == status.HTTP_401_UNAUTHORIZED

@pytest.mark.django_db
def test_current_user_authenticated(api_client_with_cred):
    response= api_client_with_cred.get('/auth/users/me/')
    assert response.status_code == status.HTTP_200_OK

@pytest.mark.django_db
def test_user_list_should_have_only_one_entry(api_client_with_cred,create_user):
    other_user = create_user(email='someotheruer@example.com',password="somestring@123")
    response= api_client_with_cred.get('/auth/users/')
    assert len(response.data) == 1

