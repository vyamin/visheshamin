import pytest
from core.tests.fixtures.plaid_fixtures import *


@pytest.fixture
def exchange_token_response(plaid_access_token,plaid_item_id):
    return {
        'access_token': plaid_access_token, 
        'item_id': plaid_item_id, 
        'request_id': 'jWSgeb6U0cG6Cjo'}

@pytest.fixture
def get_item_response():
    return {
    'available_products': ['auth', 'balance', 'credit_details', 'identity'], 
    'billed_products': ['assets', 'income', 'liabilities', 'transactions'], 
    'consent_expiration_time': None, 'error': None, 
    'institution_id': 'ins_5', 
    'item_id': 'abR6J4dgjETGppEKrEWlT9lpr1ReRVi76p9ne', 'webhook': ''}

@pytest.fixture
def get_institution_response():
    return {
        'country_codes': ['US'], 
        'credentials': [
            {'label': 'User ID', 'name': 'username', 'type': 'text'}, 
            {'label': 'Password', 'name': 'password', 'type': 'password'}], 
        'has_mfa': True, 
        'input_spec': 'fixed', 
        'institution_id': 'ins_5', 
        'mfa': ['questions', 'selections'], 
        'mfa_code_type': 'numeric', 
        'name': 'Citi', 
        'oauth': False, 
        'products': ['assets', 'auth', 'balance', 'transactions', 'credit_details', 'income', 'identity', 'liabilities'], 
        'routing_numbers': ['021000089', '021001486', '021272655', '052002166', '067004764', '091409571', '113193532', '122401710', '221172610', '254070116', '266086554', '271070801', '321171184', '322271724']}


@pytest.fixture
def plaid_account_hash():
    return {
        'account_id': 'mn6MWoLREeUWZZxEyxaVhPaXJBRRWVcLJ6z8a', 
        'balances': {
            'available': 100, 
            'current': 110, 
            'iso_currency_code': 'USD', 
            'limit': None, 
            'unofficial_currency_code': None
        }, 
        'mask': '0000', 
        'name': 'Plaid Checking', 
        'official_name': 'Plaid Gold Standard 0% Interest Checking', 
        'subtype': 'checking', 
        'type': 'depository'
    }

@pytest.fixture
def plaid_accounts_array_hash():
    return [
        {
            'account_id': 'mn6MWoLREeUWZZxEyxaVhPaXJBRRWVcLJ6z8a', 
            'balances': {
                'available': 100, 
                'current': 110, 
                'iso_currency_code': 'USD', 
                'limit': None, 
                'unofficial_currency_code': None
            }, 
            'mask': '0000', 
            'name': 'Plaid Checking', 
            'official_name': 'Plaid Gold Standard 0% Interest Checking', 
            'subtype': 'checking', 
            'type': 'depository'
        },
        {
            'account_id': 'yn6k9v3NBaUK77R9QRnWhLkej5aaKWiyAxepZ', 
            'balances': {
                'available': 200, 
                'current': 210, 
                'iso_currency_code': 'USD', 
                'limit': None, 
                'unofficial_currency_code': None
            }, 
            'mask': '1111', 
            'name': 'Plaid Saving', 
            'official_name': 
            'Plaid Silver Standard 0.1% Interest Saving', 
            'subtype': 'savings', 
            'type': 'depository'
        }]    

@pytest.fixture
def get_accounts_response():
    return [
    {
        'account_id': 'mn6MWoLREeUWZZxEyxaVhPaXJBRRWVcLJ6z8a', 
        'balances': {
            'available': 100, 
            'current': 110, 
            'iso_currency_code': 'USD', 
            'limit': None, 
            'unofficial_currency_code': None
        }, 
        'mask': '0000', 
        'name': 'Plaid Checking', 
        'official_name': 'Plaid Gold Standard 0% Interest Checking', 
        'subtype': 'checking', 
        'type': 'depository'
    },
    {
        'account_id': 'yn6k9v3NBaUK77R9QRnWhLkej5aaKWiyAxepZ', 
        'balances': {
            'available': 200, 
            'current': 210, 
            'iso_currency_code': 'USD', 
            'limit': None, 
            'unofficial_currency_code': None
        }, 
        'mask': '1111', 
        'name': 'Plaid Saving', 
        'official_name': 
        'Plaid Silver Standard 0.1% Interest Saving', 
        'subtype': 'savings', 
        'type': 'depository'
    },
    {'account_id': 
        '9EoRW4V1BvuKee5NM5gRhK4eX7zzkdhRDjaMe', 
        'balances': {
            'available': None, 
            'current': 1000, 
            'iso_currency_code': 'USD', 
            'limit': None, 
            'unofficial_currency_code': None
        }, 
        'mask': '2222', 
        'name': 'Plaid CD', 
        'official_name': 'Plaid Bronze Standard 0.2% Interest CD', 
        'subtype': 'cd', 
        'type': 'depository'
    },
    {
        'account_id': 'vn6gbm5dKrUWyyJEVJeAhLl98q55WeiWRrAVa', 
        'balances': {
            'available': None, 
            'current': 410, 
            'iso_currency_code': 'USD', 
            'limit': 2000, 
            'unofficial_currency_code': None
        }, 
        'mask': '3333', 
        'name': 'Plaid Credit Card', 
        'official_name': 'Plaid Diamond 12.5% APR Interest Credit Card', 
        'subtype': 'credit card', 
        'type': 'credit'
    },
    {
        'account_id': 'GDVnb8391GhAzz1KJ1laspKJkZ66rqF13kyRZ', 
        'balances': {
            'available': 43200, 
            'current': 43200, 
            'iso_currency_code': 'USD',
             'limit': None, 
             'unofficial_currency_code': None
        }, 
        'mask': '4444', 
        'name': 'Plaid Money Market', 
        'official_name': 'Plaid Platinum Standard 1.85% Interest Money Market', 
        'subtype': 'money market',
         'type': 'depository'
    },
    {
        'account_id': 'nn6RmgplWXUpXX9Gd94Wund3QMvvpDc6bvwgD', 
        'balances': {
            'available': None, 
            'current': 320.76, 
            'iso_currency_code': 'USD', 
            'limit': None, 
            'unofficial_currency_code': None
        }, 
        'mask': '5555', 
        'name': 'Plaid IRA', 
        'official_name': None, 
        'subtype': 'ira', 
        'type': 'investment'
    },
    {
        'account_id': 'bWRDeN3k7asqZZkGykAWSw1QMg66zVhVq8Qrr', 
        'balances': {
            'available': None, 
            'current': 23631.9805, 
            'iso_currency_code': 'USD', 
            'limit': None, 
            'unofficial_currency_code': None
        }, 
        'mask': '6666', 
        'name': 'Plaid 401k', 
        'official_name': None, 
        'subtype': '401k', 
        'type': 'investment'
    },
    {
        'account_id': 'mn6MWoLREeUWZZxEyxaVhPaXJBRRWVcLJ6z83', 
        'balances': {
            'available': None, 
            'current': 65262, 
            'iso_currency_code': 'USD', 
            'limit': None, 
            'unofficial_currency_code': None
        }, 
        'mask': '7777', 
        'name': 'Plaid Student Loan',
        'official_name': None,
        'subtype': 'student',
        'type': 'loan'
    }]
        
@pytest.fixture
def get_transactions_response():
    return [
    {'account_id': 'vn6gbm5dKrUWyyJEVJeAhLl98q55WeiWRrAVa', 
    'account_owner': None, 
    'amount': 500, 
    'authorized_date': None, 
    'category': ['Travel', 'Airlines and Aviation Services'], 
    'category_id': '22001000', 
    'date': '2020-04-30', 
    'iso_currency_code': 'USD', 
    'location': {
        'address': None, 
        'city': None, 
        'country': None, 
        'lat': None, 
        'lon': None, 
        'postal_code': None, 
        'region': None, 
        'store_number': None
    }, 
    'name': 'United Airlines', 
    'payment_channel': 'in store', 
    'payment_meta': {
        'by_order_of': None, 
        'payee': None, 
        'payer': None, 
        'payment_method': None, 
        'payment_processor': None, 
        'ppd_id': None, 
        'reason': None, 
        'reference_number': None
    }, 
    'pending': False, 
    'pending_transaction_id': None, 
    'transaction_code': None, 
    'transaction_id': 'VDzZoV1PKXhrggpyRpeNseoaM4yz8bfWd31AN', 
    'transaction_type': 'special', 
    'unofficial_currency_code': None
     },
    {
        'account_id': 'vn6gbm5dKrUWyyJEVJeAhLl98q55WeiWRrAVa', 
        'account_owner': None, 
        'amount': 500, 
        'authorized_date': None, 
        'category': ['Food and Drink', 'Restaurants'], 
        'category_id': '13005000', 
        'date': '2020-04-25', 
        'iso_currency_code': 'USD', 
        'location': {
            'address': None, 
            'city': None, 
            'country': None, 
            'lat': None, 
            'lon': None, 
            'postal_code': None, 
            'region': None, 
            'store_number': None
        }, 
        'name': 'Tectra Inc', 
        'payment_channel': 'in store', 
        'payment_meta': {
            'by_order_of': None, 
            'payee': None, 
            'payer': None, 
            'payment_method': None, 
            'payment_processor': None, 
            'ppd_id': None, 
            'reason': None, 
            'reference_number': None
        }, 
        'pending': False, 
        'pending_transaction_id': None, 
        'transaction_code': None, 
        'transaction_id': 'MDng9bwrk1h8zz49v43kSW9gJXPaQaF9pP8GB', 
        'transaction_type': 'place', 
        'unofficial_currency_code': None
     },
    {
        'account_id': 'vn6gbm5dKrUWyyJEVJeAhLl98q55WeiWRrAVa', 
        'account_owner': None, 
        'amount': 2078.5, 
        'authorized_date': None, 
        'category': ['Payment'], 
        'category_id': '16000000', 
        'date': '2020-04-24', 
        'iso_currency_code': 'USD', 
        'location': {
            'address': None, 
            'city': None, 
            'country': None, 
            'lat': None, 
            'lon': None, 
            'postal_code': None, 
            'region': None, 
            'store_number': None
        }, 
        'name': 'AUTOMATIC PAYMENT - THANK', 
        'payment_channel': 'other', 
        'payment_meta': {
            'by_order_of': None, 
            'payee': None, 
            'payer': None, 
            'payment_method': None, 
            'payment_processor': None, 
            'ppd_id': None, 
            'reason': None, 
            'reference_number': None
        }, 
        'pending': False, 
        'pending_transaction_id': None, 
        'transaction_code': None, 
        'transaction_id': 'pn6MbELKGJU5ggMEyMAbSwbdrJP5g5iLjVN8r', 
        'transaction_type': 'special', 
        'unofficial_currency_code': None
     },
    {
        'account_id': 'vn6gbm5dKrUWyyJEVJeAhLl98q55WeiWRrAVa', 
        'account_owner': None, 
        'amount': 500, 
        'authorized_date': None, 
        'category': ['Food and Drink', 'Restaurants', 'Fast Food'], 
        'category_id': '13005032', 
        'date': '2020-04-24', 
        'iso_currency_code': 'USD', 
        'location': {
            'address': None, 
            'city': None, 
            'country': None, 
            'lat': None, 
            'lon': None, 
            'postal_code': None, 
            'region': None, 
            'store_number': None
        }, 
        'name': 'KFC', 
        'payment_channel': 'in store', 
        'payment_meta': {
            'by_order_of': None, 
            'payee': None, 
            'payer': None, 
            'payment_method': None, 
            'payment_processor': None, 
            'ppd_id': None, 
            'reason': None, 
            'reference_number': None
        }, 
        'pending': False, 
        'pending_transaction_id': None, 
        'transaction_code': None, 
        'transaction_id': 'LDApGnjK8Rh7XXNbWNBZHobpA6wdldFPKpydx', 
        'transaction_type': 'place', 
        'unofficial_currency_code': None
     },
    {
        'account_id': 'vn6gbm5dKrUWyyJEVJeAhLl98q55WeiWRrAVa', 
        'account_owner': None, 
        'amount': 500, 
        'authorized_date': None, 
        'category': ['Shops', 'Sporting Goods'], 
        'category_id': '19046000', 
        'date': '2020-04-24', 
        'iso_currency_code': 'USD', 
        'location': {
            'address': None, 
            'city': None, 
            'country': None, 
            'lat': None, 
            'lon': None, 
            'postal_code': None, 
            'region': None, 
            'store_number': None
        }, 
        'name': 'Madison Bicycle Shop', 
        'payment_channel': 'in store', 
        'payment_meta': {
            'by_order_of': None, 
            'payee': None, 
            'payer': None, 
            'payment_method': None, 
            'payment_processor': None, 
            'ppd_id': None, 
            'reason': None, 
            'reference_number': None
        }, 
        'pending': False, 
        'pending_transaction_id': None, 
        'transaction_code': None, 
        'transaction_id': '1EA6rKyNneux66M7yMLlfo5emVbrRrF5XeGEz', 
        'transaction_type': 'place', 
        'unofficial_currency_code': None
     }]