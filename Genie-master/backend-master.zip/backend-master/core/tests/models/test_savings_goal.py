import pytest
from datetime import date,timedelta

from core.models import SavingsGoal
from core.tests.factories import SavingsGoalFactory

def test_monthly_savings_needed():
    today = date.today()
    sg1 = SavingsGoalFactory.build(amount=1200,
                target_date=today + timedelta(days=365))
    assert sg1.monthly_savings_needed == 100
    sg1 = SavingsGoalFactory.build(amount=1200,
                target_date=today + timedelta(days=180))
    assert sg1.monthly_savings_needed == 200
    sg1 = SavingsGoalFactory.build(amount=1200,
                target_date=today + timedelta(days=90))
    assert sg1.monthly_savings_needed == 400    
    sg1 = SavingsGoalFactory.build(amount=1000,
                target_date=today + timedelta(days=90))
    assert sg1.monthly_savings_needed == 334        
    sg1 = SavingsGoalFactory.build(amount=1000,
                target_date=today + timedelta(days=75))
    assert sg1.monthly_savings_needed == 500            
    sg1 = SavingsGoalFactory.build(amount=1000,
                target_date=today + timedelta(days=15))
    assert sg1.monthly_savings_needed == 1000                