import pytest
from core.tests.factories import UserFactory
from core.tests.factories import IncomeSummaryFactory

@pytest.mark.django_db
def test_user_creates_income_summary():
  user = UserFactory()
  assert user.incomesummary is not None

@pytest.mark.django_db
def test_user_creates_spending_summary():
  user = UserFactory()
  assert user.spendingsummary is not None  

@pytest.mark.django_db
def test_user_creates_savings_summary():
  user = UserFactory()
  assert user.savingssummary is not None    