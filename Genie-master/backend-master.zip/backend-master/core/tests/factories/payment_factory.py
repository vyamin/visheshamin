import factory

from core.models import Payment
from core.tests.factories import UserFactory


class PaymentFactory(factory.django.DjangoModelFactory):
    class Meta:
        model = Payment

    description = factory.Faker('random_element',elements=['Rent','Gym Fees',
                            'Zumba subscription','School Fees',
                            'Utility bill','Car EMI','House loan',
                            'OTT subscription'])
    amount = factory.Faker('pydecimal',right_digits=0,positive=True,
                                min_value=10,max_value=1000)
    due_date = factory.Faker('future_date',end_date='+30d')
    status = Payment.Status.DUE
    
    user = factory.SubFactory(UserFactory)