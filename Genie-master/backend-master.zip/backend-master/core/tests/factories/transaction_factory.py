import factory
from core.tests.factories import UserFactory,AccountFactory
from core.models.transaction import Transaction

@factory.use_strategy(factory.BUILD_STRATEGY)
class TransactionFactory(factory.django.DjangoModelFactory):
    class Meta():
        model = Transaction
           
    category = factory.Faker('random_element',elements=['CREDIT',"DEBIT"])
    sub_category = factory.Faker('random_element',elements=[
        'BILL_PAYMENT', 'CASH_WITHDRAWL', 'CHEQUE' ,'DIRECT_DEBIT',
        'INTEREST_INCURRED','STANDING_ORDER','TRANSFER','BANK_CHARGE',
        'CASH_DEPOSIT', 'CHEQUE_DEPOSIT', 'INTEREST_EARNED', 'OTHER'])
    channel = factory.Faker('random_element',elements=[
        'ONLINE','IN_STORE','OTHER'])
    description = factory.Faker('text',max_nb_chars=40)
    amount = factory.Faker('pydecimal',left_digits=4,right_digits=2,positive=True,
                                min_value=10,max_value=10000)
    currency = 'USD'
    date = factory.Faker('date_this_month')
    authorized_date = factory.Faker('date_this_month')

    account = factory.SubFactory(AccountFactory)
