import factory
from core.models.user_model import User

class UserFactory(factory.django.DjangoModelFactory):
    class Meta:
        model = User
    name = factory.Faker('name')
    email = factory.Faker('email')
    
class UserWithPasswordFactory(UserFactory):
  password = factory.Faker('password')