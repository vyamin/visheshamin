import factory
import random

from core.models import IncomeSummary
from core.tests.factories import UserFactory

class IncomeSummaryFactory(factory.django.DjangoModelFactory):
    class Meta:
        model = IncomeSummary
            
    projected_monthly_income = factory.Faker('pydecimal',
                    right_digits=0,positive=True,
                    min_value=1000,max_value=5000)
    amount_earned_this_month = factory.lazy_attribute(
        lambda obj: round((float(obj.projected_monthly_income)*random.random()))
    )
    
    user = factory.SubFactory(UserFactory)
    
