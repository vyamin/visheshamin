import factory

from core.models import Spending
from core.tests.factories import UserFactory

class SpendingFactory(factory.django.DjangoModelFactory):
    class Meta:
        model = Spending

    label = factory.Faker('random_element', elements=[
        'Movies','Parties','Food','Fuel','Games'
    ])
    amount = factory.Faker('pydecimal',right_digits=0,positive=True,
                    min_value=100,max_value=10000)
    user = factory.SubFactory(UserFactory)