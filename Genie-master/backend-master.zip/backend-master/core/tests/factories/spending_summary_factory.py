import factory
import random

from core.models import SpendingSummary
from core.tests.factories import UserFactory

class SpendingSummaryFactory(factory.django.DjangoModelFactory):
    class Meta:
        model = SpendingSummary
            
    projected_monthly_spending = factory.Faker('pydecimal',
                    right_digits=0,positive=True,
                    min_value=1000,max_value=5000)
    amount_spent_this_month = factory.lazy_attribute(
        lambda obj: round((float(obj.projected_monthly_spending)*random.random()))
    )
    
    user = factory.SubFactory(UserFactory)
    
