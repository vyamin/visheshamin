import factory

from core.models import SavingsGoal
from core.tests.factories import UserFactory

class SavingsGoalFactory(factory.django.DjangoModelFactory):
    class Meta:
        model = SavingsGoal
    
    description = factory.Faker('random_element',elements=[
        'New iphone', 'New gaming console', 'College course',
        'Model trainset', 'Taxes', 'Europe Holiday','Drone'
    ])
    amount = factory.Faker('pydecimal',right_digits=0,positive=True,
                                min_value=100,max_value=10000)
    target_date = factory.Faker('future_date',end_date='+360d')
    user = factory.SubFactory(UserFactory)

