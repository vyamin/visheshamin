import factory
from core.models.plaid_item import PlaidItem
from core.tests.factories.institution_factory import InstitutionFactory
from core.tests.factories.user_factory import UserFactory


class PlaidItemFactory(factory.django.DjangoModelFactory):
    class Meta:
        model = PlaidItem

    plaid_item_id = factory.Faker('pystr',min_chars=20)
    plaid_access_token = factory.Faker('pystr',min_chars=20)
    user = factory.SubFactory(UserFactory)
    institution = factory.SubFactory(InstitutionFactory)