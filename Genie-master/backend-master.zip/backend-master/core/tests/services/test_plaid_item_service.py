import pytest

from core.services import PlaidItemService
from core.tests.factories import UserFactory,PlaidItemFactory

@pytest.fixture
def service():
    return PlaidItemService()

@pytest.mark.django_db
def test_get_user_plaid_items(service):
    user = UserFactory()
    plaid_items = [
        PlaidItemFactory(user=user),
        PlaidItemFactory(user=user)
    ]
    retval = service.get_user_plaid_items(user)
    assert len(retval) == 2

@pytest.mark.django_db
def test_get_user_plaid_items_other_user(service):
    user = UserFactory()
    plaid_items = [
        PlaidItemFactory(user=user),
        PlaidItemFactory()
    ]
    retval = service.get_user_plaid_items(user)
    assert len(retval) == 1    