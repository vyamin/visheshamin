import pytest
from core.models import Account
from core.services import AccountService
from core.tests.factories import UserFactory,InstitutionFactory,PlaidItemFactory,AccountFactory
from core.tests.fixtures.common_fixtures import *
from core.tests.fixtures.plaid_response_fixtures import *

@pytest.fixture
def service():
    return AccountService()
    
def test_update_details(service):
    account1 = Account()
    account1.account_limit = 100
    account2 = Account()
    account2.account_limit = 200
    account1 = service._update_details(account1,account2)
    assert account1.account_limit == 200

@pytest.mark.django_db
def test_create_or_update_creation(service):
    user = UserFactory()
    institution = InstitutionFactory()
    plaid_item = PlaidItemFactory(user=user,institution=institution)
    account = AccountFactory.build(user=user,plaid_item = plaid_item,institution=institution)
    assert Account.objects.count()==0
    service._create_or_update(user,account)
    assert Account.objects.count()==1

@pytest.mark.django_db
def test_create_or_update_updation(service):
    account1 = AccountFactory()
    account2 = AccountFactory.build(user=account1.user,plaid_item = account1.plaid_item,
                    institution=account1.institution,name=account1.name)
    assert Account.objects.count()==1
    ret_account = service._create_or_update(account1.user,account2)
    assert Account.objects.count()==1    
    assert ret_account.available_balance == account2.available_balance

@pytest.mark.django_db
def test_create_or_update_different_user(service):
    account1 = AccountFactory()
    user2 = UserFactory()
    account2 = AccountFactory.build(user = user2,plaid_item = account1.plaid_item,
                    institution=account1.institution,name=account1.name)
    assert Account.objects.count()==1
    ret_account = service._create_or_update(user2,account2)
    assert Account.objects.count()==2    

def test_account_from_plaid_repr(service,plaid_account_hash):
    input = plaid_account_hash
    account = service._account_from_plaid_repr(input)
    assert account.available_balance == input['balances']['available']


@pytest.mark.django_db
def test_create_accounts(service,plaid_accounts_array_hash):
    user = UserFactory()
    institution = InstitutionFactory()
    plaid_item = PlaidItemFactory(user = user, institution = institution)
    result, accounts = service.create_accounts(plaid_accounts_array_hash,
                    user,institution,plaid_item)
    assert result== True
    assert len(accounts) == 2
    assert Account.objects.count()==2


@pytest.mark.django_db
def test_create_accounts_no_user(service,plaid_accounts_array_hash):
    user = UserFactory()
    institution = InstitutionFactory()
    plaid_item = PlaidItemFactory(user = user, institution = institution)
    result, response = service.create_accounts(plaid_accounts_array_hash,
                    UserFactory.build(),institution,plaid_item)
    assert result == False
    assert Account.objects.count() == 0

@pytest.mark.django_db
def test_create_accounts_no_institution(service,plaid_accounts_array_hash):
    user = UserFactory()
    institution = InstitutionFactory()
    plaid_item = PlaidItemFactory(user = user, institution = institution)
    result, response = service.create_accounts(plaid_accounts_array_hash,
                    user,InstitutionFactory.build(),plaid_item)
    assert result == False
    assert Account.objects.count() == 0    

@pytest.mark.django_db
def test_create_accounts_no_plaid_item(service,plaid_accounts_array_hash):
    user = UserFactory()
    institution = InstitutionFactory()
    plaid_item = PlaidItemFactory(user = user, institution = institution)
    result, response = service.create_accounts(plaid_accounts_array_hash,
                    user,institution,PlaidItemFactory.build())
    assert result == False
    assert Account.objects.count() == 0        


@pytest.mark.django_db
def test_create_accounts_empty_response_from_plaid(service,plaid_accounts_array_hash):
    user = UserFactory()
    institution = InstitutionFactory()
    plaid_item = PlaidItemFactory(user = user, institution = institution)
    result, response = service.create_accounts([],
                    user,institution,PlaidItemFactory.build())
    assert result == False
    assert Account.objects.count() == 0    

def test_get_type_and_subtype(service):
    assert service._get_type_and_subtype('other','other') == (
        Account.AccountType.OTHER, Account.AccountType.OTHER)
    assert service._get_type_and_subtype('depository','savings') == (
        Account.AccountType.DEPOSITORY,Account.AccountSubType.SAVINGS)        
    assert service._get_type_and_subtype('depository','checking') == (
        Account.AccountType.DEPOSITORY,Account.AccountSubType.CHECKING)
    assert service._get_type_and_subtype('depository','cd') == (
        Account.AccountType.DEPOSITORY,Account.AccountSubType.SAVINGS)
    assert service._get_type_and_subtype('depository','some other') == (
        Account.AccountType.DEPOSITORY,Account.AccountSubType.SAVINGS)

    assert service._get_type_and_subtype('investment','401k') == (
        Account.AccountType.INVESTMENT,Account.AccountSubType.INVESTMENT)
    assert service._get_type_and_subtype('investment','mutual fund') == (
        Account.AccountType.INVESTMENT,Account.AccountSubType.INVESTMENT) 
    assert service._get_type_and_subtype('investment','some other') == (
        Account.AccountType.INVESTMENT,Account.AccountSubType.INVESTMENT)                

    assert service._get_type_and_subtype('credit','credit card') == (
        Account.AccountType.CREDIT,Account.AccountSubType.CREDIT_CARD)
    assert service._get_type_and_subtype('credit','some other') == (
        Account.AccountType.CREDIT,Account.AccountSubType.CREDIT_CARD)        
      
    assert service._get_type_and_subtype('loan','auto') == (
        Account.AccountType.LOAN,Account.AccountSubType.AUTO_LOAN)
    assert service._get_type_and_subtype('loan','mortgage') == (
        Account.AccountType.LOAN,Account.AccountSubType.MORTGAGE)
    assert service._get_type_and_subtype('loan','home') == (
        Account.AccountType.LOAN,Account.AccountSubType.MORTGAGE)
    assert service._get_type_and_subtype('loan','home equity') == (
        Account.AccountType.LOAN,Account.AccountSubType.MORTGAGE)
    assert service._get_type_and_subtype('loan','student') == (
        Account.AccountType.LOAN,Account.AccountSubType.STUDENT_LOAN) 
    assert service._get_type_and_subtype('loan','some other') == (
        Account.AccountType.LOAN,Account.AccountSubType.OTHER)  

    assert service._get_type_and_subtype('other','some other') == (
        Account.AccountType.OTHER,Account.AccountSubType.OTHER)    

@pytest.mark.django_db
def test_get_user_accounts(service):
    user = UserFactory()
    accounts = [
        AccountFactory(user=user),
        AccountFactory(user=user)
    ]
    retval = service.get_user_accounts(user)
    assert len(retval) ==2

@pytest.mark.django_db
def test_get_user_accounts_other_user(service):
    user = UserFactory()
    accounts = [
        AccountFactory(user=user),
        AccountFactory()
    ]
    retval = service.get_user_accounts(user)
    assert len(retval) ==1 