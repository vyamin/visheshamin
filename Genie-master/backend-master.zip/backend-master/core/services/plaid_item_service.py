from core.models import PlaidItem

class PlaidItemService():
    def get_user_plaid_items(self,user):
        return PlaidItem.objects.filter(user_id=user.id)