import os
import plaid
from datetime import date,timedelta
from plaid.errors import PlaidError

class PlaidService():
    def __init__(self):
        self.client = plaid.Client(
            client_id = os.getenv('PLAID_CLIENT_ID'), 
            secret = os.getenv('PLAID_SECRET'),
            public_key = os.getenv('PLAID_PUBLIC_KEY'),
            environment = os.getenv('PLAID_ENV'))
    
    def exchange_token(self,public_token):
        if not public_token:
            return (False, "Public token is required")
        try:
            exchange_response = self.client.Item.public_token.exchange(
                                public_token)
        except PlaidError as e:
            return (False,e.message)
        except:
            return (False, 'Unknown error')
        return (True,exchange_response)

    def get_institution(self,institution_id):
        #{'institution': {'country_codes': ['US'], 'credentials': [{'label': 'User ID', 'name': 'username', 'type': 'text'}, {'label': 'Password', 'name': 'password', 'type': 'password'}], 'has_mfa': True, 'input_spec': 'fixed', 'institution_id': 'ins_5', 'mfa': ['questions', 'selections'], 'mfa_code_type': 'numeric', 'name': 'Citi', 'oauth': False, 'products': ['assets', 'auth', 'balance', 'transactions', 'credit_details', 'income', 'identity', 'liabilities'], 'routing_numbers': ['021000089', '021001486', '021272655', '052002166', '067004764', '091409571', '113193532', '122401710', '221172610', '254070116', '266086554', '271070801', '321171184', '322271724']}, 'request_id': 'kt6sCdyPe88VE46'}        
        if not institution_id:
            return(False,'Institution id is required')
        try:
            institution_response = (self.client.Institutions.
                                get_by_id(institution_id))
        except PlaidError as e:
            return(False,e.message)
        except:
            return (False, 'Unknown error')
        return (True, institution_response['institution'])

    def get_item(self,access_token):
        #{'item': {'available_products': ['auth', 'balance', 'credit_details', 'identity'], 'billed_products': ['assets', 'income', 'liabilities', 'transactions'], 'consent_expiration_time': None, 'error': None, 'institution_id': 'ins_5', 'item_id': 'abR6J4dgjETGppEKrEWlT9lpr1ReRVi76p9ne', 'webhook': ''}, 'request_id': 'UEwgfcFdjHJzXCc', 'status': {'last_webhook': None, 'transactions': {'last_failed_update': None, 'last_successful_update': '2020-04-29T14:24:48.555Z'}}}
        if not access_token:
            return (False, "Access token is required")
        try:
            get_response = self.client.Item.get(access_token)
        except plaid.errors.PlaidError as e:
            return (False,e.message)
        except:
            return (False, 'Unknown error')
        return (True,get_response['item'])      

    def get_accounts(self,access_token):
        if not access_token:
            return (False,'Access token is required')
        try:
            accounts_response = self.client.Accounts.get(access_token)
        except plaid.errors.PlaidError as e:
            return (False, e.message)
        except:
            return (False, 'Unknown error')
        return (True, accounts_response['accounts'])

    def get_transactions(self,access_token,start_date=None, end_date=None,
                account_ids=None,count = 50, offset = 0):
        if not access_token:
            return(False,'Access token is required')
        if not end_date:
            end_date = date.today()
        if not start_date:
            start_date = end_date-timedelta(days=30)
                
        start_date_str = start_date.strftime("%Y-%m-%d")
        end_date_str = end_date.strftime("%Y-%m-%d")
        try:
            response = self.client.Transactions.get(access_token,
            start_date_str,end_date_str,account_ids=account_ids,
            count=count,offset=offset)
        except plaid.errors.PlaidError as e:
            return (False, e.message)
        except:
            return (False, 'Unknown error')
        return (True, response['transactions'])