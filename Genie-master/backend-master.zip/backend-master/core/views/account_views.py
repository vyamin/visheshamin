from rest_framework import viewsets
from rest_framework import mixins
from rest_framework import status
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from rest_framework.decorators import action
from core.models.account import Account
from core.services import PlaidService,TransactionService
from core.serializers import TransactionSerializer
from core.permissions import IsOwnerOrAdmin
from core.serializers import AccountSerializer,TransactionSerializer


class AccountViewSet(mixins.ListModelMixin,
                    mixins.RetrieveModelMixin,
                    viewsets.GenericViewSet):
    serializer_class = AccountSerializer
    permission_classes = [IsOwnerOrAdmin]

    def get_queryset(self):
        return self.request.user.accounts.all()

    # def get_permissions(self):
    #     if self.action == 'retrieve':
    #         permission_classes = [IsOwnerOrAdmin]
    #     else:
    #         permission_classes = [IsAuthenticated]
    #     return [permission() for permission in permission_classes]

    @action(detail=True, methods=['get'],url_name='transactions-list',
            permission_classes = [IsOwnerOrAdmin])
    def transactions(self,request,pk=None):
        account = self.get_object()
        plaid_service = PlaidService()
        result,response = plaid_service.get_transactions(
            account.plaid_item.plaid_access_token,account_ids=[account.plaid_account_id])
        if not result:
            return Response({'detail':response},status.HTTP_500_INTERNAL_SERVER_ERROR)
        transaction_service = TransactionService()
        result,response = transaction_service.get_transactions_from_plaid_response(response)
        if not result:
            return Response({'detail':response},status.HTTP_500_INTERNAL_SERVER_ERROR)
        transactions = response
        for transaction in transactions:
            transaction.account = account
        serializer = TransactionSerializer(transactions,many=True)
        return Response(serializer.data)


    

