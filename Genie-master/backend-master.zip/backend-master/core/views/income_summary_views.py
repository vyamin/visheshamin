from django.db import transaction
from rest_framework import status
from rest_framework.decorators import api_view,permission_classes
from rest_framework.generics import GenericAPIView
from rest_framework.mixins import UpdateModelMixin,RetrieveModelMixin
from rest_framework.response import Response
from rest_framework.permissions import IsAdminUser

from core.models import IncomeSummary,Income,Projection
from core.serializers import IncomeSerializer,IncomeSummarySerializer
from core.serializers import ProjectionSerializer
from core.permissions import ReadOnly,IsWorker

@api_view(['GET'])
def income_summary_digest(request):
    user = request.user
    try:
        income_summary = user.incomesummary
    except AttributeError:
        return Response(status=status.HTTP_404_NOT_FOUND)
    
    income_summary_serializer = IncomeSummarySerializer(income_summary)

    incomes = user.incomes.all()
    income_serializer = IncomeSerializer(incomes,many=True)

    income_projections = user.projections.filter(
        category=Projection.Category.INCOME)
    income_projections_serializer = ProjectionSerializer(
        income_projections,many=True)
    
    return Response({
        'income_summary':income_summary_serializer.data,
        'incomes':income_serializer.data,
        'income_projections':income_projections_serializer.data
    })

class IncomeSummaryView(RetrieveModelMixin,UpdateModelMixin,GenericAPIView):
  queryset = IncomeSummary.objects.all()
  serializer_class = IncomeSummarySerializer
  permission_classes = [IsAdminUser|IsWorker|ReadOnly]

  def get(self,request,*args,**kwargs):
    return self.retrieve(request,*args,**kwargs)

  def patch(self,request,*args,**kwargs):
    return self.partial_update(request,*args,**kwargs)

  def get_object(self):
    return self.request.user.incomesummary

@api_view(['GET','POST'])
@permission_classes([IsAdminUser|IsWorker|ReadOnly])
@transaction.atomic
def income_projections(request):
  user = request.user
  if request.method == 'GET':
    income_projections = user.projections.filter(
      category=Projection.Category.INCOME)
    serializer = ProjectionSerializer(
      income_projections, many = True)
    return Response(serializer.data)
  elif request.method == 'POST':
    data = []
    for projection in request.data:
      projection['user'] = user.id
      data.append(projection)
    serializer = ProjectionSerializer(data=data,many=True)
    if serializer.is_valid():
      # Delete existing projections
      user.projections.filter(category=Projection.Category.INCOME).delete()
      serializer.save()
      return Response(serializer.data,status = status.HTTP_201_CREATED)
    return Response(serializer.errors,status=status.HTTP_400_BAD_REQUEST)

