import os
from django.db import transaction
from datetime import date
from rest_framework import status
from rest_framework.decorators import api_view,permission_classes
from rest_framework.response import Response
from rest_framework.generics import GenericAPIView
from rest_framework.mixins import UpdateModelMixin,RetrieveModelMixin
from rest_framework.permissions import IsAdminUser

from core.models import SavingsSummary,Projection,SavingsGoal
from core.serializers import SavingsSummarySerializer,ProjectionSerializer,SavingsGoalSerializer
from core.permissions import ReadOnly,IsWorker


@api_view(['GET'])
def savings_summary_digest(request):
    user = request.user
    try:
        savings_summary = user.savingssummary
    except AttributeError:
        return Response(status=status.HTTP_404_NOT_FOUND)
    savings_summary_serializer = SavingsSummarySerializer(savings_summary)

    today = date.today()
    savings_goals = SavingsGoal.objects.filter(user=user).filter(
                target_date__gte = today)
    savings_goals_serializer = SavingsGoalSerializer(savings_goals,many=True)

    savings_projections = user.projections.filter(
                    category=Projection.Category.SAVINGS)
    savings_projections_serializer = ProjectionSerializer(
                savings_projections,many=True)
    return Response({
        'savings_summary': savings_summary_serializer.data,
        'savings_goals': savings_goals_serializer.data,
        'savings_projections': savings_projections_serializer.data
    })

class SavingsSummaryView(RetrieveModelMixin,UpdateModelMixin,GenericAPIView):
  queryset = SavingsSummary.objects.all()
  serializer_class = SavingsSummarySerializer
  permission_classes = [IsAdminUser|IsWorker|ReadOnly]

  def get(self,request,*args,**kwargs):
    return self.retrieve(request,*args,**kwargs)

  def patch(self,request,*args,**kwargs):
    return self.partial_update(request,*args,**kwargs)

  def get_object(self):
    return self.request.user.savingssummary

@api_view(['GET','POST'])
@permission_classes([IsAdminUser|IsWorker|ReadOnly])
@transaction.atomic
def savings_projections(request):
  user = request.user
  if request.method == 'GET':
    savings_projections = user.projections.filter(
      category=Projection.Category.SAVINGS)
    serializer = ProjectionSerializer(
      savings_projections, many = True)
    return Response(serializer.data)
  elif request.method == 'POST':
    data = []
    for projection in request.data:
      projection['user'] = user.id
      data.append(projection)
    serializer = ProjectionSerializer(data=data,many=True)
    if serializer.is_valid():
      # Delete existing projections
      user.projections.filter(category=Projection.Category.SAVINGS).delete()
      serializer.save()
      return Response(serializer.data,status = status.HTTP_201_CREATED)
    return Response(serializer.errors,status=status.HTTP_400_BAD_REQUEST)

