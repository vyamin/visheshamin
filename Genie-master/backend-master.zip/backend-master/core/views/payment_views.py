from django_filters import rest_framework as filters
from datetime import date,datetime,timedelta
from rest_framework import viewsets
from rest_framework.filters import SearchFilter,OrderingFilter
from rest_framework.permissions import IsAuthenticated


from core.models import Payment
from core.serializers import PaymentSerializer

class PaymentViewSet(viewsets.ModelViewSet):
    queryset = Payment.objects.all()
    serializer_class = PaymentSerializer
    permission_classes = [IsAuthenticated]
    filter_backends=[filters.DjangoFilterBackend,SearchFilter,OrderingFilter]
    filterset_fields = {'due_date':['gte','lte']}
    search_fields = ('^description',)
    ordering_fields = ('description','amount','due_date',)
    ordering=('due_date',)


    def get_queryset(self):
        return self.queryset \
            .filter(user=self.request.user)