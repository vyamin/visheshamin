from datetime import date
from django.db import transaction
from rest_framework import status
from rest_framework.decorators import api_view,permission_classes
from rest_framework.generics import GenericAPIView
from rest_framework.response import Response
from rest_framework.mixins import UpdateModelMixin,RetrieveModelMixin
from rest_framework.permissions import IsAdminUser

from core.models import SpendingSummary,Spending,Projection,Payment
from core.serializers import SpendingSerializer,SpendingSummarySerializer
from core.serializers import ProjectionSerializer,PaymentSerializer
from core.permissions import ReadOnly,IsWorker

@api_view(['GET'])
def spending_summary_digest(request):
    user = request.user
    try:
        spending_summary = user.spendingsummary
    except AttributeError:
        return Response(status=status.HTTP_404_NOT_FOUND)
    
    spending_summary_serializer = SpendingSummarySerializer(spending_summary)

    spendings = user.spendings.all()
    spending_serializer = SpendingSerializer(spendings,many=True)

    today = date.today()
    upcoming_payments = Payment.objects.filter(user=user).filter(
                due_date__gte = today)
    payments_serializer = PaymentSerializer(upcoming_payments,many=True)

    spending_projections = user.projections.filter(
        category=Projection.Category.SPENDING)
    spending_projections_serializer = ProjectionSerializer(
        spending_projections,many=True)
    
    return Response({
        'spending_summary':spending_summary_serializer.data,
        'spendings':spending_serializer.data,
        'upcoming_payments':payments_serializer.data,
        'spending_projections':spending_projections_serializer.data
    })

class SpendingSummaryView(RetrieveModelMixin,UpdateModelMixin,GenericAPIView):
  queryset = SpendingSummary.objects.all()
  serializer_class = SpendingSummarySerializer
  permission_classes = [IsAdminUser|IsWorker|ReadOnly]

  def get(self,request,*args,**kwargs):
    return self.retrieve(request,*args,**kwargs)

  def patch(self,request,*args,**kwargs):
    return self.partial_update(request,*args,**kwargs)

  def get_object(self):
    return self.request.user.spendingsummary

@api_view(['GET','POST'])
@permission_classes([IsAdminUser|IsWorker|ReadOnly])
@transaction.atomic
def spending_projections(request):
  user = request.user
  if request.method == 'GET':
    spending_projections = user.projections.filter(
      category=Projection.Category.SPENDING)
    serializer = ProjectionSerializer(
      spending_projections, many = True)
    return Response(serializer.data)
  elif request.method == 'POST':
    data = []
    for projection in request.data:
      projection['user'] = user.id
      data.append(projection)
    serializer = ProjectionSerializer(data=data,many=True)
    if serializer.is_valid():
      # Delete existing projections
      user.projections.filter(category=Projection.Category.SPENDING).delete()
      serializer.save()
      return Response(serializer.data,status = status.HTTP_201_CREATED)
    return Response(serializer.errors,status=status.HTTP_400_BAD_REQUEST)
