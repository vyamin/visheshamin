from django.urls import path,include
from rest_framework.routers import DefaultRouter
from core.views import plaid_views,account_views,payment_views
from core.views import savings_goal_views,savings_summary_views
from core.views import income_views, income_summary_views
from core.views import spending_views,spending_summary_views

router = DefaultRouter()
router.register('accounts',account_views.AccountViewSet,basename='account')
router.register('payments',payment_views.PaymentViewSet,basename='payment')
router.register('savings-goals',savings_goal_views.SavingsGoalViewSet,basename='savings-goal')
router.register('income',income_views.IncomeViewSet,basename='income')
router.register('spending',spending_views.SpendingViewSet,basename='spending')


urlpatterns=[
    path('api-auth',include('rest_framework.urls',namespace='rest_framework')),
    path('',include(router.urls)),
    path('genie/plaid-link-options/',plaid_views.plaid_link_options_hash,name='plaid-link-options'),
    path('genie/plaid-get-access-token/',plaid_views.plaid_get_access_token,name='plaid-get-access-token'),
    path('savings-summary/savings-summary',savings_summary_views.SavingsSummaryView.as_view(),name="savings-summary"),
    path('savings-summary/savings-projections',savings_summary_views.savings_projections,name='savings-projections'),
    path('savings-summary/',savings_summary_views.savings_summary_digest,name='savings-summary-digest'),    
    path('income-summary/income-summary',income_summary_views.IncomeSummaryView.as_view(),name="income-summary"),
    path('income-summary/income-projections',income_summary_views.income_projections,name='income-projections'),
    path('income-summary/',income_summary_views.income_summary_digest,name='income-summary-digest'),
    path('spending-summary/spending-summary',spending_summary_views.SpendingSummaryView.as_view(),name="spending-summary"),
    path('spending-summary/spending-projections',spending_summary_views.spending_projections,name='spending-projections'),
    path('spending-summary/',spending_summary_views.spending_summary_digest,name='spending-summary-digest'),            
]