from django.db import models
from .user_model import User
from .institution import Institution

class PlaidItem(models.Model):

    Status = models.IntegerChoices('Status',
        'CREATED ENRICHED ACTIVE ERRORED DELETED')

    plaid_item_id = models.CharField(max_length=128,default=None,null=True)
    plaid_access_token = models.CharField(max_length=128,default=None,null=True)
    status = models.IntegerField(
        choices=Status.choices,default=Status.CREATED
    )

    user = models.ForeignKey(User, related_name = 'plaid_items', on_delete=models.CASCADE)
    institution = models.ForeignKey(Institution,related_name = 'plaid_items', on_delete=models.SET_NULL,
                        blank=True,null=True)
    
    

    def __str__(self):
        return 'Plaid item: {}'.format(self.plaid_item_id)
