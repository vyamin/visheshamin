from django.db import models
from core.models import User
from datetime import date
import math


class SavingsGoal(models.Model):
    description = models.CharField(max_length=250)
    amount = models.DecimalField(max_digits=10,decimal_places=2)
    target_date = models.DateField()
    user = models.ForeignKey(User,on_delete=models.CASCADE,related_name='saving_goals')

    @property
    def monthly_savings_needed(self):
        today = date.today()
        if today < self.target_date : 
            days = (self.target_date-today).days
            months = (days//30)
            if months == 0:
                months = 1
            return math.ceil(float(self.amount)/months)
        else:
            return self.amount
    

    def __str__(self):
        return "{}::{}::{}".format(self.target_date.strftime("%Y-%m-%d"),
                    self.amount, self.description)
    