from django.db import models
from . import User,Institution,PlaidItem

class Account(models.Model):
    '''
    Represents the Account object. Though there are some 
    methods that are specific to plaid provider, they are
    optional in in alternate flows can be skipped.
    '''
    AccountType = models.TextChoices('AccountType',
        'DEPOSITORY CREDIT INVESTMENT LOAN OTHER')
    AccountSubType = models.TextChoices('AccountSubType',
      'CHECKING SAVINGS CREDIT_CARD INVESTMENT STUDENT_LOAN MORTGAGE AUTO_LOAN OTHER')

    name = models.CharField(max_length=256)
    nick_name = models.CharField(max_length=128) 
    institution_name = models.CharField(max_length=256)

    fqn = models.CharField(max_length=512,unique=True,editable=False)
    account_type = models.CharField( max_length=32,
        choices=AccountType.choices,default=AccountType.DEPOSITORY)
    account_subtype = models.CharField(max_length= 32,
        choices= AccountSubType.choices,default= AccountSubType.OTHER)
    current_balance = models.DecimalField(max_digits=16,
        decimal_places=2,default=0)
    available_balance = models.DecimalField(max_digits=16,
        decimal_places=2,default=0)
    account_limit = models.DecimalField(max_digits=16,
        decimal_places=2, default=0)
    currency = models.CharField(max_length=3,default='USD')
    
    plaid_account_id = models.CharField(max_length=128,default=None,null=True)
    
    institution = models.ForeignKey(Institution,related_name = 'accounts', on_delete=models.CASCADE)
    plaid_item = models.ForeignKey(PlaidItem,null=True,related_name='accounts',on_delete=models.SET_NULL)
    user = models.ForeignKey(User, related_name='accounts', on_delete=models.CASCADE)
    
    def __str__(self):
        if self.nick_name:
            return self.nick_name
        else:
            return self.name


    def get_fqn(user_id,institution_id,name):
        return "{}:::{}:::{}".format(user_id,institution_id,name)

    def get_my_fqn(self):
        return Account.get_fqn(self.user_id,self.institution_id,self.name)

    def save(self, *args, **kwargs):
        self.fqn = self.get_my_fqn()
        super(Account,self).save(*args,**kwargs)

        
