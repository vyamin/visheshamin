from backend.wsgi import application

app = application