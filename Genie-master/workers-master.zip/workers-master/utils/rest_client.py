import requests
import json
import jwt
import time

class RESTClient:
  def __init__(self,server,email,pwd,base_auth_path):
    self.server = server
    self.email = email
    self.pwd = pwd
    self.base_auth_path = base_auth_path
    self.headers = {
      'Accept':'application/json',
      'Content-Type':'application/json'}
    self.access_token = None
    self.refresh_token = None
    self._create_token()

  def get(self,path,params=None,additional_headers={}):
    url = "{}{}".format(self.server,path)
    headers = self.headers.copy()
    headers.update(additional_headers)
    headers['Authorization'] = 'Bearer '+self._get_active_token()
    return requests.get(url,params=params,headers=headers)

  def head(self,path,additional_headers={}):
    url = "{}{}".format(self.server,path)
    headers = self.headers.copy()
    headers.update(additional_headers)
    headers['Authorization'] = 'Bearer '+self._get_active_token()
    return requests.head(url,headers=headers)    

  def options(self,path,additional_headers={}):
    url = "{}{}".format(self.server,path)
    headers = self.headers.copy()
    headers.update(additional_headers)
    headers['Authorization'] = 'Bearer '+self._get_active_token()
    return requests.options(url,headers=headers)    

  def post(self,path,data=None,additional_headers={}):
    url = "{}{}".format(self.server,path)
    headers = self.headers.copy()
    headers.update(additional_headers)
    headers['Authorization'] = 'Bearer '+self._get_active_token()
    return requests.post(url,data=data,headers=headers)  

  def put(self,path,data=None,additional_headers={}):
    url = "{}{}".format(self.server,path)
    headers = self.headers.copy()
    headers.update(additional_headers)
    headers['Authorization'] = 'Bearer '+self._get_active_token()
    return requests.put(url,data=data,headers=headers)  

  def patch(self,path,data=None,additional_headers={}):
    url = "{}{}".format(self.server,path)
    headers = self.headers.copy()
    headers.update(additional_headers)
    headers['Authorization'] = 'Bearer '+self._get_active_token()
    return requests.patch(url,data=data,headers=headers)  

  def _get_active_token(self):
    if(self.access_token):
      print('Access Token Present')
      try:
        jwt.decode(self.access_token,algorithms=['HS256'],options={
            'verify_signature':False})
      except jwt.exceptions.ExpiredSignatureError:
        print('Access token has expired')
        try :
          jwt.decode(self.refresh_token,algorithms=['HS256'],options={
            'verify_signature':False})
          print('Refresh token is valid')
          self._refresh_token()
        except jwt.exceptions.ExpiredSignatureError:
          print('Refresh token has also expired')
          self._create_token()
    else:
      print('Access token is not present')
      self._create_token()
    assert self.access_token, "Could not establish contact with "+self.server
    return self.access_token
  
  # Requests REST Server for Access/Refresh token
  # 
  def _create_token(self):
    url = "{}{}/jwt/create/".format(self.server,self.base_auth_path)
    data = {'email':self.email,'password':self.pwd}
    response = requests.post(url,data=json.dumps(data),headers=self.headers)
    if response.status_code == 200:
      json_response = response.json()
      self.access_token = json_response['access']
      self.refresh_token = json_response['refresh']

  # Requests REST Server for Refresh token
  # 
  def _refresh_token(self):
    url = "{}{}/jwt/refresh/".format(self.server,self.base_auth_path)
    data = {'refresh':self.refresh_token}
    response = requests.post(url,data=json.dumps(data),headers=self.headers)
    if response.status_code == 200:
      json_response = response.json()
      self.access_token = json_response['access']
      self.refresh_token = json_response['refresh']
    

  
