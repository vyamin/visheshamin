import settings

print(settings.DEBUG)