from environs import Env

env = Env()
workers_env = env.str('WORKERS_ENV','dev')
env_fn = '.env_{}'.format(workers_env)
env.read_env(env_fn)


DEBUG = env.str('DEBUG',False)

