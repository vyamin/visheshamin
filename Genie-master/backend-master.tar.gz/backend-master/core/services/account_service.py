from core.models.user_model import User
from core.models.account import Account

class AccountService():
    def create_accounts(self,plaid_response,user,institution,plaid_item):
        if not user.pk:
            return False, 'User does not exist'
        if not institution.pk:
            return False, "Institution does not exist"
        if not plaid_item.pk:
            return False, "Plaid item does not exist"
        accounts_hash_array = plaid_response
        accounts_array = []
        for account_hash in plaid_response:
            account = self._account_from_plaid_repr(account_hash)
            account.institution_name = institution.name
            account.institution = institution
            account.user = user
            account.plaid_item = plaid_item
            account = self._create_or_update(user,account)
            accounts_array.append(account)
        if len(accounts_array) >0:
            return True, accounts_array
        else:
            return False,'Could not find any accounts'

    def _get_type_and_subtype(self,plaid_type,plaid_subtype):
        known_types= {
            'depository': (Account.AccountType.DEPOSITORY,Account.AccountSubType.SAVINGS),
            'credit': (Account.AccountType.CREDIT,Account.AccountSubType.CREDIT_CARD),
            'investment':(Account.AccountType.INVESTMENT,Account.AccountSubType.INVESTMENT),
            'loan': (Account.AccountType.LOAN,Account.AccountSubType.OTHER),
            'other': (Account.AccountType.OTHER,Account.AccountSubType.OTHER)
        }
        known_types_and_subtypes = {
            'depository':{
                'checking':Account.AccountSubType.CHECKING
            },
            'credit':{
                'paypal':Account.AccountSubType.OTHER
            },
            'investment':{
                
            },
            'loan':{
                'auto':Account.AccountSubType.AUTO_LOAN,
                'home':Account.AccountSubType.MORTGAGE,
                'home equity':Account.AccountSubType.MORTGAGE,
                'mortgage':Account.AccountSubType.MORTGAGE,
                'student':Account.AccountSubType.STUDENT_LOAN
            }
        }
        account_type = Account.AccountType.OTHER
        account_subtype= Account.AccountSubType.OTHER
        if plaid_type in known_types:
            known_type,known_default_subtype = known_types[plaid_type]
            account_type = known_type
            account_subtype = known_default_subtype
        if plaid_type in known_types_and_subtypes:
            known_subtypes = known_types_and_subtypes[plaid_type]
            if plaid_subtype in known_subtypes:
                account_subtype = known_subtypes[plaid_subtype]

        return account_type,account_subtype



    def _account_from_plaid_repr(self,plaid_repr):
        account = Account()
        account.name = plaid_repr['official_name']
        account.nick_name = plaid_repr['name']
        account.plaid_account_id = plaid_repr['account_id']
        if not account.name:
            account.name = account.nick_name
        account.account_type,account.account_subtype = (
            self._get_type_and_subtype(plaid_repr['type'],
                plaid_repr['subtype']))
        if plaid_repr['balances']['available']:
            account.available_balance = plaid_repr['balances']['available']
        if plaid_repr['balances']['current']:
            account.current_balance = plaid_repr['balances']['current']
        if plaid_repr['balances']['limit']:
            account.account_limit = plaid_repr['balances']['limit']
        if plaid_repr['balances']['iso_currency_code']:
            account.currency = plaid_repr['balances']['iso_currency_code']
        return account

    def _create_or_update(self,user,new_account):
        fqn = Account.get_fqn(new_account.user_id,new_account.institution_id,
                                    new_account.name)
        account = user.accounts.filter(fqn=fqn).first()
        if account is None:
            new_account.save()
            return new_account
        else:
            account = self._update_details(account,new_account)
            account.save()
            return account        

    def _update_details(self,first,second):
        first.nick_name = second.nick_name
        first.account_type = second.account_type
        first.account_subtype = second.account_subtype
        first.available_balance = second.available_balance
        first.current_balance = second.current_balance
        first.account_limit = second.account_limit
        first.currency = second.currency
        first.plaid_item = second.plaid_item
        first.plaid_account_id = second.plaid_account_id
        return first        

    def get_user_accounts(self,user):
        return Account.objects.filter(user_id=user.id)


        
    