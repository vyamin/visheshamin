from core.models import Transaction
from datetime import datetime


class TransactionService():
    def get_transactions_from_plaid_response(self,plaid_response):
        if plaid_response is None or type(plaid_response) != list:
            return False,'Internal server error (adapter)'
        transactions=[]
        for my_dict in plaid_response:
            transaction = Transaction()
            if my_dict['amount'] > 0:
                transaction.category = Transaction.Category.CREDIT
            else:
                transaction.category = Transaction.Category.DEBIT
            
            if my_dict['transaction_type'].upper() in Transaction.SubCategory.values:
                transaction.sub_category = my_dict['transaction_type'].upper()
            else:
                transaction.sub_category = 'OTHER'
            channel_map = {'online':'ONLINE','in store':'IN_STORE','other':'OTHER'}
            transaction.channel = channel_map.get(my_dict['payment_channel'],'OTHER')
            transaction.description = my_dict['name']
            transaction.amount = abs(my_dict['amount'])
            transaction.currency = my_dict['iso_currency_code']
            transaction.date = datetime.strptime(my_dict['date'],'%Y-%m-%d')
            try:
                transaction.authorized_date = datetime.strptime(my_dict['authorized_date'],'%Y-%m-%d')
            except:
                transaction.authorized_date = datetime.strptime(my_dict['date'],'%Y-%m-%d')
            transactions.append(transaction)
        return True,transactions
    


            
            
            
            