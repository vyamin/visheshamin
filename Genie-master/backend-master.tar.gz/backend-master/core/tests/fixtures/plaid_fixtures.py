import pytest
from core.tests.factories import UserFactory,InstitutionFactory
from core.tests.factories import AccountFactory,PlaidItemFactory


@pytest.fixture
def plaid_public_token():
    return 'public-sandbox-59117c67-4df6-4462-9903-016e62810640'

@pytest.fixture
def plaid_access_token():
    return 'access-sandbox-16e290d7-22d8-4d58-a9de-0810d217dc23'

@pytest.fixture
def plaid_institution_id():
    return 'ins_5'

@pytest.fixture
def plaid_item_id():
    return 'dppDApKLQ5f6ozVkMkR7inB8qdbW9aCZ3xrPZ'

@pytest.fixture
def plaid_account_id():
    return 'vn6gbm5dKrUWyyJEVJeAhLl98q55WeiWRrAVa'

@pytest.fixture
def plaid_account_ids():
    return [
        'mn6MWoLREeUWZZxEyxaVhPaXJBRRWVcLJ6z8a',
        'yn6k9v3NBaUK77R9QRnWhLkej5aaKWiyAxepZ',
        '9EoRW4V1BvuKee5NM5gRhK4eX7zzkdhRDjaMe',
        'vn6gbm5dKrUWyyJEVJeAhLl98q55WeiWRrAVa',
        'GDVnb8391GhAzz1KJ1laspKJkZ66rqF13kyRZ',
        'nn6RmgplWXUpXX9Gd94Wund3QMvvpDc6bvwgD',
        'bWRDeN3k7asqZZkGykAWSw1QMg66zVhVq8Qrr',
        'mn6MWoLREeUWZZxEyxaVhPaXJBRRWVcLJ6z83'
    ]

@pytest.fixture
def plaid_user_creds(plaid_institution_id,plaid_item_id,plaid_access_token,
                    plaid_account_id):
    user = UserFactory()
    institution = InstitutionFactory(plaid_institution_id=plaid_institution_id,
                    name='Citi')
    plaid_item = PlaidItemFactory(plaid_item_id=plaid_item_id,
            plaid_access_token = plaid_access_token, user = user,
            institution = institution)
    account = AccountFactory(plaid_account_id=plaid_account_id,
                    user = user, institution = institution,
                    plaid_item = plaid_item)
    return {
       'user':user,
       'institution':institution,
       'plaid_item':plaid_item,
       'account':account
   }

@pytest.fixture
def api_client_with_pu_cred(db,plaid_user_creds,api_client):
    api_client.force_authenticate(user=plaid_user_creds['user'])
    yield api_client
    api_client.force_authenticate(user=None)


