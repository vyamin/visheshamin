import pytest
import uuid

@pytest.fixture
def api_client():
    from rest_framework.test import APIClient
    return APIClient()

@pytest.fixture
def create_user(db, django_user_model):
  def make_user(**kwargs):
      return django_user_model.objects.create_user(**kwargs)
  return make_user

@pytest.fixture
def create_super_user(db, django_user_model):
  def make_user(**kwargs):
      return django_user_model.objects.create_superuser(**kwargs)
  return make_user  

@pytest.fixture
def create_worker(db, django_user_model):
  def make_user(**kwargs):
      return django_user_model.objects.create_worker(**kwargs)
  return make_user    

@pytest.fixture
def get_or_create_token(db,create_user):
    user = create_user(email='testuser1@example.com',password='somestring@123')
    token,_ = Token.objects.get_or_create(user=user)
    return token

@pytest.fixture
def the_user(create_user):
    return create_user(email='testuser1@example.com',password='somestring@123')

@pytest.fixture
def the_admin_user(create_super_user):
    return create_super_user(email='adminuser1@example.com',password='somestring@123')    

@pytest.fixture
def the_worker(create_worker):
    return create_worker(email='worker1@example.com',password='somestring@123')        


@pytest.fixture
def api_client_with_cred(db,the_user,api_client):
    api_client.force_authenticate(user=the_user)
    yield api_client
    api_client.force_authenticate(user=None)

@pytest.fixture
def api_client_with_admin_cred(db,the_admin_user,api_client):
    api_client.force_authenticate(user=the_admin_user)
    yield api_client
    api_client.force_authenticate(user=None)  

@pytest.fixture
def api_client_with_worker_cred(db,the_worker,api_client):
    api_client.force_authenticate(user=the_worker)
    yield api_client
    api_client.force_authenticate(user=None)        




