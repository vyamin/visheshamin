import pytest
import json
from datetime import date,timedelta
from django.urls import reverse
from rest_framework import status
from rest_framework.renderers  import JSONRenderer
from core.models import Payment
from core.serializers import PaymentSerializer
from core.tests.factories import PaymentFactory,UserFactory
from core.tests.fixtures.common_fixtures import *

@pytest.mark.django_db
def test_payment_list(api_client_with_cred,the_user):
    # Available filter and ordering params - guide
    # data = {'due_date__gte':'2020-05-08','search':'School',
    #           'ordering':'-description'}
    due_date = date.today()
    for i in range(5):
        PaymentFactory(user=the_user,due_date=due_date+timedelta(days=i))
    response = api_client_with_cred.get(reverse('payment-list'),)
    assert response.status_code == status.HTTP_200_OK
    assert len(response.data)==5

@pytest.mark.django_db
def test_payment_list_other_user(api_client_with_cred,the_user):
    due_date = date.today()
    user = UserFactory()
    for i in range(5):
        PaymentFactory(user=user,due_date=due_date+timedelta(days=i))
    #print(Payment.objects.all())
    response = api_client_with_cred.get(reverse('payment-list'))
    assert response.status_code == status.HTTP_200_OK
    assert len(response.data)==0   

@pytest.mark.django_db
def test_payment_create(api_client_with_cred,the_user):
    new_payment = PaymentFactory.build(user=the_user)
    data = PaymentSerializer(new_payment).data
    response = api_client_with_cred.post(reverse('payment-list'),data)
    assert response.status_code == status.HTTP_201_CREATED
    assert response.data['description'] == data['description']

@pytest.mark.django_db
def test_payment_create_other_user(api_client_with_cred,the_user):
    user = UserFactory()
    new_payment = PaymentFactory.build(user=user)
    data = PaymentSerializer(new_payment).data
    response = api_client_with_cred.post(reverse('payment-list'),data)
    assert response.status_code == status.HTTP_201_CREATED
    assert the_user.payments.count() > 0
    assert user.payments.count() == 0
    
@pytest.mark.django_db
def test_payment_retrieve(api_client_with_cred,the_user):
    payment = PaymentFactory(user=the_user)
    response = api_client_with_cred.get(reverse('payment-detail',args=[payment.id]))
    assert response.status_code == status.HTTP_200_OK
    assert response.data['description'] == payment.description

@pytest.mark.django_db
def test_payment_retrieve_other_user(api_client_with_cred,the_user):
    payment = PaymentFactory()
    response = api_client_with_cred.get(reverse('payment-detail',args=[payment.id]))
    assert response.status_code == status.HTTP_404_NOT_FOUND

@pytest.mark.django_db
def test_payment_update(api_client_with_cred,the_user):
    payment = PaymentFactory(user=the_user)
    payment.amount = 123.45
    data = PaymentSerializer(payment).data
    response = api_client_with_cred.put(
                reverse('payment-detail',args=[payment.id]),
                data)
    assert response.status_code == status.HTTP_200_OK
    assert float(Payment.objects.first().amount) == 123.45

@pytest.mark.django_db
def test_payment_update_other_user(api_client_with_cred,the_user):
    payment = PaymentFactory()
    payment.amount = 123.45
    data = PaymentSerializer(payment).data
    response = api_client_with_cred.put(
                reverse('payment-detail',args=[payment.id]),
                data)
    assert response.status_code == status.HTTP_404_NOT_FOUND
    assert float(Payment.objects.first().amount) != 123.45

@pytest.mark.django_db
def test_payment_partial_update(api_client_with_cred,the_user):
    payment = PaymentFactory(user=the_user)
    data = {'amount': '123.45'}
    response = api_client_with_cred.patch(
                reverse('payment-detail',args=[payment.id]),
                data)
    assert response.status_code == status.HTTP_200_OK
    assert float(Payment.objects.first().amount) == 123.45  

@pytest.mark.django_db
def test_payment_partial_update_other_user(api_client_with_cred,the_user):
    payment = PaymentFactory()
    data = {'amount': '123.45'}
    response = api_client_with_cred.patch(
                reverse('payment-detail',args=[payment.id]),
                data)
    assert response.status_code == status.HTTP_404_NOT_FOUND
    assert float(Payment.objects.first().amount) != 123.45        


@pytest.mark.django_db
def test_payment_destroy(api_client_with_cred,the_user):
    payment = PaymentFactory(user=the_user)
    response = api_client_with_cred.delete(
                reverse('payment-detail',args=[payment.id]))
    assert response.status_code == status.HTTP_204_NO_CONTENT

@pytest.mark.django_db
def test_payment_destroy_other_user(api_client_with_cred,the_user):
    payment = PaymentFactory()
    response = api_client_with_cred.delete(
                reverse('payment-detail',args=[payment.id]))
    assert response.status_code == status.HTTP_404_NOT_FOUND
    assert Payment.objects.count() == 1    


