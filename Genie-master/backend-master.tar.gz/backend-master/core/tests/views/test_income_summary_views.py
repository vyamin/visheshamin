import pytest
from django.urls import reverse
from rest_framework import status

from core.models import IncomeSummary
from core.serializers import IncomeSummarySerializer,ProjectionSerializer
from core.tests.fixtures.common_fixtures import *
from core.tests.factories import IncomeSummaryFactory,IncomeProjectionFactory
from core.tests.factories import UserFactory,IncomeFactory

@pytest.mark.django_db
def test_income_summary_digest(api_client_with_cred,the_user):
    response = api_client_with_cred.get(reverse('income-summary-digest'))
    assert response.status_code == status.HTTP_200_OK
    assert 'projected_monthly_income' in response.data['income_summary']

@pytest.mark.django_db
def test_income_summary_digest_includes_incomes(api_client_with_cred,the_user):
    income_summary = IncomeSummary(user = the_user)
    for i in range(3):
        IncomeFactory(user=the_user)
    response = api_client_with_cred.get(reverse('income-summary-digest'))
    assert response.data['income_summary'] is not None
    assert len(response.data['incomes']) == 3

@pytest.mark.django_db
def test_income_summary_digest_includes_income_projections(api_client_with_cred,the_user):
    income_summary = IncomeSummary(user = the_user)
    for i in range(4):
        IncomeProjectionFactory(user=the_user)
    response = api_client_with_cred.get(reverse('income-summary-digest'))
    assert response.data['income_summary'] is not None
    assert len(response.data['income_projections']) == 4   

@pytest.mark.django_db
def test_income_summary_get_nonadmin_user(api_client_with_cred,the_user):
  income_summary = the_user.incomesummary
  income_summary.projected_monthly_income=4000
  income_summary.amount_earned_this_month=2000
  income_summary.save()
  response = api_client_with_cred.get(reverse('income-summary'))
  new_income_summary = response.data
  assert response.status_code == status.HTTP_200_OK
  assert new_income_summary['projected_monthly_income'] == income_summary.projected_monthly_income

@pytest.mark.django_db
def test_income_summary_get_worker(api_client_with_worker_cred,the_worker):
  response = api_client_with_worker_cred.get(reverse('income-summary'))
  assert response.status_code == status.HTTP_200_OK

@pytest.mark.django_db
def test_income_summary_get_admin_user(api_client_with_admin_cred,the_admin_user):
  response = api_client_with_admin_cred.get(reverse('income-summary'))
  assert response.status_code == status.HTTP_200_OK

@pytest.mark.django_db
def test_income_summary_update_nonadmin_user(api_client_with_cred,the_user):
  data = {'projected_monthly_income':2000}
  response = api_client_with_cred.patch(reverse('income-summary'),data)
  assert response.status_code == status.HTTP_403_FORBIDDEN

@pytest.mark.django_db
def test_income_summary_update_worker(api_client_with_worker_cred,the_worker):
  data = {'projected_monthly_income':2000}
  response = api_client_with_worker_cred.patch(reverse('income-summary'),data)
  assert response.status_code == status.HTTP_200_OK
  assert response.data['projected_monthly_income'] == 2000

@pytest.mark.django_db
def test_income_summary_update_admin_user(api_client_with_admin_cred,the_admin_user):
  data = {'projected_monthly_income':2000}
  response = api_client_with_admin_cred.patch(reverse('income-summary'),data)
  assert response.status_code == status.HTTP_200_OK
  assert response.data['projected_monthly_income'] == 2000

@pytest.mark.django_db
def test_income_projections_get_nonadmin_user(api_client_with_cred,the_user):
  projections = IncomeProjectionFactory.create_batch(12,user=the_user)
  response = api_client_with_cred.get(reverse('income-projections'))
  assert response.status_code == status.HTTP_200_OK
  assert len(response.data) == 12

@pytest.mark.django_db
def test_income_projections_get_worker(api_client_with_worker_cred,the_worker):
  projections = IncomeProjectionFactory.create_batch(12,user=the_worker)
  response = api_client_with_worker_cred.get(reverse('income-projections'))
  assert response.status_code == status.HTTP_200_OK
  assert len(response.data) == 12  

@pytest.mark.django_db
def test_income_projections_get_admin_user(api_client_with_admin_cred,the_admin_user):
  projections = IncomeProjectionFactory.create_batch(12,user=the_admin_user)
  response = api_client_with_admin_cred.get(reverse('income-projections'))
  assert response.status_code == status.HTTP_200_OK
  assert len(response.data) == 12  

@pytest.mark.django_db
def test_income_projections_post_nonadmin_user(api_client_with_cred,the_user):
  projections = IncomeProjectionFactory.build_batch(6)
  data = ProjectionSerializer(projections,many=True).data
  response = api_client_with_cred.post(reverse('income-projections'),data)
  assert response.status_code == status.HTTP_403_FORBIDDEN

@pytest.mark.django_db
def test_income_projections_post_worker(api_client_with_worker_cred,the_worker):
  IncomeProjectionFactory.create_batch(12,user=the_worker)
  projections = IncomeProjectionFactory.build_batch(6)
  data = ProjectionSerializer(projections,many=True).data
  response = api_client_with_worker_cred.post(reverse('income-projections'),data)
  assert response.status_code == status.HTTP_201_CREATED
  assert len(response.data) == 6

@pytest.mark.django_db
def test_income_projections_post_admin_user(api_client_with_admin_cred,the_admin_user):
  IncomeProjectionFactory.create_batch(12,user=the_admin_user)
  projections = IncomeProjectionFactory.build_batch(6)
  data = ProjectionSerializer(projections,many=True).data
  print(data)
  response = api_client_with_admin_cred.post(reverse('income-projections'),data)
  assert response.status_code == status.HTTP_201_CREATED
  assert len(response.data) == 6