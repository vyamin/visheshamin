import pytest
from datetime import date,timedelta

from django.urls import reverse
from rest_framework import status
from core.models import SavingsGoal
from core.serializers import SavingsGoalSerializer
from core.tests.fixtures.common_fixtures import *
from core.tests.factories import SavingsGoalFactory,UserFactory

@pytest.mark.django_db
def test_savings_goal_list(api_client_with_cred,the_user):
    # Available filter and ordering params - guide
    # data = {'target_date__gte':'2020-05-08','search':'School',
    #           'ordering':'-description'}
    target_date = date.today()
    for i in range(5):
        SavingsGoalFactory(user=the_user,target_date=target_date+timedelta(days=i*35))
    response = api_client_with_cred.get(reverse('savings-goal-list'),)
    assert response.status_code == status.HTTP_200_OK
    assert len(response.data)==5

@pytest.mark.django_db
def test_savings_goal_list_other_user(api_client_with_cred,the_user):
    # Available filter and ordering params - guide
    # data = {'target_date__gte':'2020-05-08','search':'School',
    #           'ordering':'-description'}
    target_date = date.today()
    user = UserFactory()
    for i in range(2):
        SavingsGoalFactory(user=user,target_date=target_date+timedelta(days=i*35))
    response = api_client_with_cred.get(reverse('savings-goal-list'),)
    assert len(response.data)==0


@pytest.mark.django_db
def test_savings_goal_create(api_client_with_cred,the_user):
    sg = SavingsGoalFactory.build(user=the_user)
    data = SavingsGoalSerializer(sg).data
    response = api_client_with_cred.post(reverse('savings-goal-list'),data)
    assert response.status_code == status.HTTP_201_CREATED
    assert response.data['description'] == data['description']


@pytest.mark.django_db
def test_savings_goal_create_other_user(api_client_with_cred,the_user):
    user = UserFactory()
    sg = SavingsGoalFactory.build(user=user)
    data = SavingsGoalSerializer(sg).data
    response = api_client_with_cred.post(reverse('savings-goal-list'),data)
    assert response.status_code == status.HTTP_201_CREATED
    assert response.data['description'] == data['description']
    assert user.saving_goals.count()==0
    assert the_user.saving_goals.count() == 1


@pytest.mark.django_db
def test_savings_goal_retrieve(api_client_with_cred,the_user):
    sg1 = SavingsGoalFactory(user = the_user)
    response = api_client_with_cred.get(reverse('savings-goal-detail',args=[sg1.id]))
    assert response.status_code == status.HTTP_200_OK
    assert float(response.data['amount']) == float(sg1.amount)
    assert response.data['description'] == sg1.description
    assert 'monthly_savings_needed' in response.data

@pytest.mark.django_db
def test_savings_goal_retrieve_other_user(api_client_with_cred,the_user):
    sg1 = SavingsGoalFactory()
    response = api_client_with_cred.get(reverse('savings-goal-detail',args=[sg1.id]))
    assert response.status_code == status.HTTP_404_NOT_FOUND

@pytest.mark.django_db
def test_savings_goal_update(api_client_with_cred,the_user):
    sg = SavingsGoalFactory(user=the_user)
    sg.amount = 123.45
    data = SavingsGoalSerializer(sg).data
    response = api_client_with_cred.put(
                reverse('savings-goal-detail',args=[sg.id]),
                data)
    assert response.status_code == status.HTTP_200_OK
    assert float(SavingsGoal.objects.first().amount) == 123.45

@pytest.mark.django_db
def test_savings_goal_update_other_user(api_client_with_cred,the_user):
    sg = SavingsGoalFactory()
    sg.amount = 123.45
    data = SavingsGoalSerializer(sg).data
    response = api_client_with_cred.put(
                reverse('savings-goal-detail',args=[sg.id]),
                data)
    assert response.status_code == status.HTTP_404_NOT_FOUND
    assert float(SavingsGoal.objects.first().amount) != 123.45    


@pytest.mark.django_db
def test_savings_goal_partial_update(api_client_with_cred,the_user):
    sg = SavingsGoalFactory(user=the_user)
    data = {'amount': '123.45'}
    response = api_client_with_cred.patch(
                reverse('savings-goal-detail',args=[sg.id]),
                data)
    assert response.status_code == status.HTTP_200_OK
    assert float(SavingsGoal.objects.first().amount) == 123.45  

@pytest.mark.django_db
def test_savings_goal_partial_update_other_user(api_client_with_cred,the_user):
    sg = SavingsGoalFactory()
    data = {'amount': '123.45'}
    response = api_client_with_cred.patch(
                reverse('savings-goal-detail',args=[sg.id]),
                data)
    assert response.status_code == status.HTTP_404_NOT_FOUND
    assert float(SavingsGoal.objects.first().amount) != 123.45      

@pytest.mark.django_db
def test_savings_goal_destroy(api_client_with_cred,the_user):
    sg = SavingsGoalFactory(user=the_user)
    response = api_client_with_cred.delete(
                reverse('savings-goal-detail',args=[sg.id]))
    assert response.status_code == status.HTTP_204_NO_CONTENT

@pytest.mark.django_db
def test_savings_goal_destroy_other_user(api_client_with_cred,the_user):
    sg = SavingsGoalFactory()
    response = api_client_with_cred.delete(
                reverse('savings-goal-detail',args=[sg.id]))
    assert response.status_code == status.HTTP_404_NOT_FOUND 
    assert SavingsGoal.objects.count()==1   
