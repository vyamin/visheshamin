import pytest
from django.urls import reverse
from rest_framework import status
from core.views import account_views
from core.tests.fixtures.common_fixtures import *
from core.tests.fixtures.plaid_fixtures import *
from core.tests.fixtures.plaid_response_fixtures import *
from core.tests.factories import AccountFactory


@pytest.fixture
def mock_plaid_service(mocker,get_transactions_response):
    class MockPlaidService():
        def __init__(self):
            self.get_transactions = mocker.patch.object(account_views.PlaidService,'get_transactions')
            self.get_transactions.return_value = True,get_transactions_response

    return MockPlaidService()

@pytest.mark.django_db
def test_account_list(api_client_with_cred,the_user):
    account = AccountFactory(user=the_user)
    response = api_client_with_cred.get(reverse('account-list'))
    assert response.status_code == status.HTTP_200_OK
    assert len(response.data)==1
    assert response.data[0]['name'] == account.name

@pytest.mark.django_db
def test_account_list_other_user(api_client_with_cred,the_user):
    account = AccountFactory()
    response = api_client_with_cred.get(reverse('account-list'))
    assert response.status_code == status.HTTP_200_OK
    assert len(response.data)==0

@pytest.mark.django_db
def test_account_detail(api_client_with_cred,the_user):
    account = AccountFactory(user=the_user)
    response = api_client_with_cred.get(reverse('account-detail',args=[account.id]))
    assert response.status_code == status.HTTP_200_OK
    assert response.data['name'] == account.name

@pytest.mark.django_db
def test_account_detail_other_user(api_client_with_cred,the_user):
    account = AccountFactory()
    response = api_client_with_cred.get(reverse('account-detail',args=[account.id]))
    assert response.status_code == status.HTTP_404_NOT_FOUND

@pytest.mark.django_db
def test_transactions_other_account(api_client_with_pu_cred,plaid_user_creds,mock_plaid_service):
    account = AccountFactory()
    response = api_client_with_pu_cred.get(reverse('account-transactions-list',
                    args=[account.id]))
    assert response.status_code == status.HTTP_404_NOT_FOUND

@pytest.mark.django_db
def test_transactions_get_transaction_failure(api_client_with_pu_cred,
        plaid_user_creds,mock_plaid_service):
    mock_plaid_service.get_transactions.return_value = False,'Some error'
    response = api_client_with_pu_cred.get(reverse('account-transactions-list',
                    args=[plaid_user_creds['account'].id]))
    assert response.status_code != status.HTTP_200_OK

@pytest.mark.django_db
def test_transactions_get_transaction_failure(api_client_with_pu_cred,
        plaid_user_creds,mocker):
    get_transactions_from_plaid_response = mocker.patch('core.views.account_views.TransactionService.get_transactions_from_plaid_response')
    get_transactions_from_plaid_response.return_value = False,'some error'
    response = api_client_with_pu_cred.get(reverse('account-transactions-list',
                    args=[plaid_user_creds['account'].id]))
    assert response.status_code != status.HTTP_200_OK

@pytest.mark.django_db
def test_transactions(api_client_with_pu_cred,plaid_user_creds,mock_plaid_service):
    response = api_client_with_pu_cred.get(reverse('account-transactions-list',
                    args=[plaid_user_creds['account'].id]))
    assert response.status_code == status.HTTP_200_OK
    assert len(response.data) > 0

