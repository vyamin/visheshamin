import pytest

from django.urls import reverse
from rest_framework import status
from core.models import Spending
from core.serializers import SpendingSerializer
from core.tests.fixtures.common_fixtures import *
from core.tests.factories import SpendingFactory,UserFactory

@pytest.mark.django_db
def test_spending_list(api_client_with_cred,the_user):
    for i in range(3):
        SpendingFactory(user=the_user)
    response = api_client_with_cred.get(reverse('spending-list'))
    assert response.status_code == status.HTTP_200_OK
    assert len(response.data)==3

@pytest.mark.django_db
def test_spending_list_other_user(api_client_with_cred):
    user = UserFactory()
    for i in range(3):
        SpendingFactory(user=user)
    response = api_client_with_cred.get(reverse('spending-list'))
    assert len(response.data)==0

@pytest.mark.django_db
def test_spending_create(api_client_with_cred,the_user):
    spending = SpendingFactory.build(user=the_user)
    data = SpendingSerializer(spending).data
    response = api_client_with_cred.post(reverse('spending-list'),data)
    assert response.status_code == status.HTTP_201_CREATED
    assert response.data['label'] == spending.label

@pytest.mark.django_db
def test_spending_create_other_user(api_client_with_cred,the_user):
    user = UserFactory()
    spending = SpendingFactory.build(user=user)
    data = SpendingSerializer(spending).data
    response = api_client_with_cred.post(reverse('spending-list'),data)
    assert response.status_code == status.HTTP_201_CREATED
    assert user.spendings.count() == 0
    assert the_user.spendings.count() == 1

@pytest.mark.django_db
def test_spending_retrieve(api_client_with_cred,the_user):
    spending = SpendingFactory(user=the_user)
    response = api_client_with_cred.get(reverse(
        'spending-detail',args=[spending.id]))
    assert response.status_code == status.HTTP_200_OK
    assert response.data['amount'] == float(spending.amount)
    assert response.data['label'] == spending.label

@pytest.mark.django_db
def test_spending_retrieve_other_user(api_client_with_cred):
    spending = SpendingFactory()
    response = api_client_with_cred.get(reverse(
        'spending-detail',args=[spending.id]))
    assert response.status_code == status.HTTP_404_NOT_FOUND

@pytest.mark.django_db
def test_spending_update(api_client_with_cred,the_user):
    spending = SpendingFactory(user=the_user)
    spending.amount = 123.45
    data = SpendingSerializer(spending).data
    response = api_client_with_cred.put(reverse('spending-detail',
                    args=[spending.id]),data)
    assert response.status_code == status.HTTP_200_OK
    assert response.data['amount'] == 123.45
    assert response.data['label'] == spending.label

@pytest.mark.django_db
def test_spending_update_other_user(api_client_with_cred):
    spending = SpendingFactory()
    spending.amount = 123.45
    data = SpendingSerializer(spending).data
    response = api_client_with_cred.put(reverse('spending-detail',
                    args=[spending.id]),data)
    assert response.status_code == status.HTTP_404_NOT_FOUND

@pytest.mark.django_db
def test_spending_partial_update(api_client_with_cred,the_user):
    spending = SpendingFactory(user=the_user)
    data = {'amount': 123.45}
    response = api_client_with_cred.patch(reverse(
        'spending-detail',args=[spending.id]),data)
    assert response.status_code == status.HTTP_200_OK
    assert response.data['amount'] == 123.45

@pytest.mark.django_db
def test_income_partial_update_other_user(api_client_with_cred,the_user):
    spending = SpendingFactory()
    data = {'amount': 123.45}
    response = api_client_with_cred.patch(reverse(
        'spending-detail',args=[spending.id]),data)
    assert response.status_code == status.HTTP_404_NOT_FOUND


@pytest.mark.django_db
def test_spending_destroy(api_client_with_cred,the_user):
    spending = SpendingFactory(user=the_user)
    response = api_client_with_cred.delete(reverse(
                    'spending-detail',args=[spending.id]))
    assert response.status_code == status.HTTP_204_NO_CONTENT
    assert Spending.objects.count() == 0

@pytest.mark.django_db
def test_spending_destroy_other_user(api_client_with_cred):
    spending = SpendingFactory()
    response = api_client_with_cred.delete(reverse(
                    'spending-detail',args=[spending.id]))
    assert response.status_code == status.HTTP_404_NOT_FOUND
    assert Spending.objects.count() == 1
