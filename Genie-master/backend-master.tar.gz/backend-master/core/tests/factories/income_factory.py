import factory

from core.models import Income
from core.tests.factories import UserFactory

class IncomeFactory(factory.django.DjangoModelFactory):
    class Meta:
        model = Income

    label = factory.Faker('random_element', elements=[
        'Salary', 'Tuitions','Uber','TA'
    ])
    amount = factory.Faker('pydecimal',right_digits=0,positive=True,
                    min_value=100,max_value=10000)
    user = factory.SubFactory(UserFactory)