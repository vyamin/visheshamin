import factory
from core.models.institution import Institution


class InstitutionFactory(factory.django.DjangoModelFactory):
    class Meta:
        model = Institution
    plaid_institution_id = factory.Faker('pystr',min_chars=20,max_chars=25)
    name=factory.Faker('company')