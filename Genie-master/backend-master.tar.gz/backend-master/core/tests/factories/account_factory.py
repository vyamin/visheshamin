import factory
from core.tests.factories import UserFactory,InstitutionFactory,PlaidItemFactory
from core.models.account import Account

class AccountFactory(factory.django.DjangoModelFactory):
    class Meta:
        model = Account

    name = factory.Sequence(lambda n: "Bank Account %d" % n)
    nick_name = factory.Sequence(lambda n: "My Account %d" % n)
    institution_name = factory.LazyAttribute(lambda obj: obj.institution.name)
    account_type = factory.Faker('random_element',elements=['DEPOSITORY', 'CREDIT',
                         'INVESTMENT', 'LOAN', 'OTHER'])
    account_subtype = factory.Faker('random_element',elements=['CHECKING',
     'SAVINGS', 'CREDIT_CARD', 'INVESTMENT', 'STUDENT_LOAN', 'MORTGAGE',
      'AUTO_LOAN', 'OTHER'])
    fqn = factory.LazyAttribute(lambda obj: "{}:::{}".format(
                                    obj.institution_name,obj.name))
    current_balance = factory.Faker('random_number',digits=5)
    available_balance = factory.Faker('random_number',digits=5)
    account_limit = factory.Faker('random_number',digits=5)
    plaid_account_id = factory.Faker('pystr',min_chars=28,max_chars=32)

    institution = factory.SubFactory(InstitutionFactory)
    plaid_item = factory.SubFactory(PlaidItemFactory)
    user = factory.SubFactory(UserFactory)
    