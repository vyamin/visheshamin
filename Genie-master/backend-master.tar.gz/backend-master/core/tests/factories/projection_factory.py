import factory
from core.models import Projection
from core.tests.factories import UserFactory

class ProjectionFactory(factory.django.DjangoModelFactory):
    class Meta:
        model = Projection
    
    amount = factory.Faker('pydecimal',right_digits=0,positive=True,
                min_value=2000,max_value=10000)
    target_date = factory.Faker('future_date',end_date='+365d')

    user = factory.SubFactory(UserFactory)

class IncomeProjectionFactory(ProjectionFactory):
    category = Projection.Category.INCOME 
    

class SpendingProjectionFactory(ProjectionFactory):
    category = Projection.Category.SPENDING

class SavingsProjectionFactory(ProjectionFactory):
    category = Projection.Category.SAVINGS 


 