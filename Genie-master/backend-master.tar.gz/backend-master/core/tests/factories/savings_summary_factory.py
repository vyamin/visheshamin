import factory
import random
from core.models import SavingsSummary
from core.tests.factories import UserFactory

class SavingsSummaryFactory(factory.django.DjangoModelFactory):
    class Meta:
        model = SavingsSummary
    
    monthly_savings_goal = factory.Faker('pydecimal',right_digits=0,
                                positive=True,min_value=50,max_value=5000)
    
    current_monthly_savings = factory.LazyAttribute(
        lambda obj: round((float(obj.monthly_savings_goal)*random.random()))
    )
    
    user =  factory.SubFactory(UserFactory)
