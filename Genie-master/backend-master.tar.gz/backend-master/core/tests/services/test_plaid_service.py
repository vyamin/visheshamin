import pytest
from core.services import plaid_service
from core.services.plaid_service import PlaidService
from plaid.errors import PlaidError
from core.tests.fixtures.plaid_fixtures import *
from unittest.mock import ANY
from datetime import date,timedelta

@pytest.fixture
def service():    
    return PlaidService()

def test_client_setup(service):
    assert service.client is not None


@pytest.mark.parametrize(
    'bad_public_token,ret_status',[
        (None,False),
        ('',False)
    ]
)
def test_exchange_token_invalid_inputs(service,bad_public_token,ret_status):
    status,response = service.exchange_token(bad_public_token)
    assert status == ret_status

def test_exchange_token_calls_external_service(mocker,service,plaid_public_token):
    plaid_client = mocker.patch.object(service,'client')
    service.exchange_token(plaid_public_token)
    plaid_client.Item.public_token.exchange.assert_called_once_with(plaid_public_token)

def test_exchange_token_returns_false_on_exception(mocker,service,plaid_public_token):
    plaid_client = mocker.patch.object(service,'client')
    plaid_client.Item.public_token.exchange.side_effect = PlaidError(
            "Some error","some type","some code","some display string")
    status, response = service.exchange_token(plaid_public_token)
    assert status == False

def test_exchange_token_returns_client_response(mocker,service,plaid_public_token):
    #{'access_token': 'access-sandbox-9291d0f0-e434-4c73-a915-82ab563ab64b', 
    # 'item_id': 'KQrow3VWzktpKpZ9p6eZHWwgvDKMvGtVvVVy8', 
    # 'request_id': 'ffqcdpcDqfpze5B'}
    plaid_client = mocker.patch.object(service,'client')
    plaid_client.Item.public_token.exchange.return_value = {
        'access_token': 'access-sandbox-9291d0f0-e434-4c73-a915-82ab563ab64b', 
        'item_id': 'KQrow3VWzktpKpZ9p6eZHWwgvDKMvGtVvVVy8', 
        'request_id': 'ffqcdpcDqfpze5B'}
    status, response = service.exchange_token(plaid_public_token)
    assert status == True
    assert response == {
        'access_token': 'access-sandbox-9291d0f0-e434-4c73-a915-82ab563ab64b', 
        'item_id': 'KQrow3VWzktpKpZ9p6eZHWwgvDKMvGtVvVVy8', 
        'request_id': 'ffqcdpcDqfpze5B'}

@pytest.mark.parametrize(
    'bad_inst_id,ret_status',[
        (None,False),
        ('',False)
    ]
)
def test_get_institution_invalid_input(bad_inst_id,ret_status,service):
    status,response = service.get_institution(bad_inst_id)
    assert status == ret_status

def test_get_institution(service,plaid_institution_id):
    status,response = service.get_institution(plaid_institution_id)
    assert status == True
    assert 'name' in response

@pytest.mark.parametrize(
    'bad_access_token,ret_status',[
        (None,False),
        ('',False)
    ]
)
def test_get_item_on_invalid_input(bad_access_token,ret_status,service):
    status,response = service.get_item(bad_access_token)
    assert status == ret_status    

def test_get_item_on_valid_input(service,plaid_access_token):
    status,response = service.get_item(plaid_access_token)
    assert status == True
    assert 'institution_id' in response

@pytest.mark.parametrize(
    'bad_access_token,ret_status',[
        (None,False),
        ('',False)
    ]
)
def test_get_item_on_invalid_input(bad_access_token,ret_status,service):
    status,response = service.get_accounts(bad_access_token)
    assert status == ret_status    

# This test fails when the access token has expired. Need to renew it to work
def test_get_accounts_on_valid_input(service,plaid_access_token):
    status,response = service.get_accounts(plaid_access_token)
    print(status,response)
    assert status == True
    assert len(response) > 0

@pytest.mark.parametrize(
    'bad_access_token,ret_status',[
        (None,False),
        ('',False)
    ]
)
def test_get_transactions_on_invalid_input(bad_access_token,ret_status,service):
    status,response = service.get_transactions(bad_access_token)
    assert status == ret_status

def test_get_transactions_no_dates(plaid_access_token,service,mocker):
    ''' End date defaults to current date and start date to 30 days before'''
    plaid_client = mocker.patch.object(service,'client')
    status,response = service.get_transactions(plaid_access_token)
    end_date = date.today()
    start_date = end_date-timedelta(days=30)
    end_date_str = end_date.strftime("%Y-%m-%d")
    start_date_str = start_date.strftime("%Y-%m-%d")
    plaid_client.Transactions.get.assert_called_once_with(ANY,
    start_date_str,end_date_str,account_ids=ANY,count=ANY,offset=ANY)

def test_get_transactions_no_end_date(plaid_access_token,service,mocker):
    ''' End date defaults to current date'''
    plaid_client = mocker.patch.object(service,'client')
    status,response = service.get_transactions(plaid_access_token)
    end_date_str = date.today().strftime("%Y-%m-%d")
    plaid_client.Transactions.get.assert_called_once_with(ANY,
    ANY,end_date_str,account_ids=ANY,count=ANY,offset=ANY)

def test_get_transactions_no_start_date(plaid_access_token,service,mocker):
    '''start date defaults to 30 days before end date'''
    plaid_client = mocker.patch.object(service,'client')
    end_date = date(2020,4,20)
    start_date = end_date - timedelta(days=30)
    start_date_str = start_date.strftime("%Y-%m-%d")
    end_date_str = end_date.strftime("%Y-%m-%d")
    status,response = service.get_transactions(plaid_access_token,None,end_date)
    plaid_client.Transactions.get.assert_called_once_with(ANY,
    start_date_str,end_date_str,account_ids=ANY,count=ANY,offset=ANY)    

# This test fails on expired access token. Need to update the fixture 
def test_get_transactions(plaid_access_token,service):
    status,response = service.get_transactions(plaid_access_token)
    assert len(response ) > 0
    a_transaction = response[0]
    assert 'name' in a_transaction
    assert 'amount' in a_transaction
    assert 'date' in a_transaction