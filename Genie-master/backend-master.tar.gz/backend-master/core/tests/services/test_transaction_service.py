import pytest

from core.services import TransactionService
from core.models import Transaction
from core.tests.fixtures.plaid_fixtures import plaid_user_creds
from core.tests.factories.account_factory import AccountFactory
from core.tests.fixtures.plaid_response_fixtures import get_transactions_response

@pytest.fixture
def service():
    return TransactionService()

def test_get_transactions_from_plaid_response_adapter_error(service):
    result,response = service.get_transactions_from_plaid_response(None)
    assert result == False

def test_get_transactions_from_plaid_response_empty(service):
    result,response = service.get_transactions_from_plaid_response([])
    assert result == True
    assert len(response)==0

def test_get_transactions_from_plaid_response(service,
                get_transactions_response):
    result,response = service.get_transactions_from_plaid_response(
                            get_transactions_response)
    assert result == True
    assert len(response) > 0
    assert type(response[0])==Transaction

