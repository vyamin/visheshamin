import pytest
from datetime import date,timedelta

from core.models import Projection,SavingsSummary
from core.tests.fixtures.common_fixtures import *
from core.tests.factories.projection_factory import IncomeProjectionFactory
from core.tests.factories.savings_summary_factory import SavingsSummaryFactory


@pytest.fixture
def yearly_income_projections(the_user):
    this_month = date.today().replace(day=1)
    projections = []
    for i in range(12):
        target_date = (this_month+timedelta(days=(i+1)*31)).replace(day=1)
        ip = IncomeProjectionFactory(target_date=target_date)
        projections.append(ip)
    return projections
        

