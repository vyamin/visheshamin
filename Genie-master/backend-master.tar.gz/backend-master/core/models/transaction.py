from django.db import models
from core.models import Account,User
from django.db import NotSupportedError



class Transaction(models.Model):
    Category = models.TextChoices('Category',
        'CREDIT DEBIT')
    SubCategory = models.TextChoices('SubCategory',
        '''
        BILL_PAYMENT CASH_WITHDRAWL CHEQUE DIRECT_DEBIT INTEREST_INCURRED
        STANDING_ORDER TRANSFER BANK_CHARGE CASH_DEPOSIT CHEQUE_DEPOSIT
        INTEREST_EARNED OTHER
        ''')
    Channel = models.TextChoices('Channel','ONLINE IN_STORE OTHER')

    category = models.CharField(max_length=32,
        choices=Category.choices)    
    sub_category = models.CharField(max_length=32,
        choices=SubCategory.choices)
    channel = models.CharField(max_length=32,
        choices=Channel.choices)
    description = models.CharField(max_length=128)
    amount = models.DecimalField(max_digits=10,decimal_places=2)
    currency = models.CharField(max_length=3,default='USD')
    date = models.DateTimeField()
    authorized_date = models.DateTimeField()

    account = models.ForeignKey(Account,related_name='transactions',on_delete=models.CASCADE)

    def __str__(self):
        return self.description + str(self.amount)

    def save(self):
        raise NotSupportedError()
    


