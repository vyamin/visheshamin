from django.db import models

class Institution(models.Model):
    plaid_institution_id = models.CharField(max_length=128,unique=True)
    name = models.CharField(max_length=256)

    def __str__(self):
        return self.name
