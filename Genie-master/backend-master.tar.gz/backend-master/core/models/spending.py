from django.db import models
from core.models import User

class Spending(models.Model):
    label = models.CharField(max_length=64)
    amount = models.DecimalField(max_digits=10,decimal_places=2)

    user = models.ForeignKey(User,on_delete=models.CASCADE,
                            related_name="spendings")
    
    def __str__(self):
        return "{}::{}".format(self.label,self.amount)