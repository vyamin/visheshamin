from django.db import models
from core.models import User

class Payment(models.Model):
    Status = models.TextChoices('Status',
        'DUE PENDING PAID')
    
    description = models.CharField(max_length=250)
    amount = models.DecimalField(max_digits=10,decimal_places=2)
    due_date = models.DateField()
    status = models.CharField(max_length=16,choices=Status.choices,
                    default= Status.DUE)

    user = models.ForeignKey(User,on_delete=models.CASCADE,related_name='payments')

    def __str__(self):
        return "{}::{}::{}".format(self.due_date.strftime("%Y-%m-%d"),
                    self.amount, self.description)