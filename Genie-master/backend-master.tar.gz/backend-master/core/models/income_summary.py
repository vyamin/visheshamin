from django.db import models
from core.models import User
from annoying.fields import AutoOneToOneField

class IncomeSummary(models.Model):
    projected_monthly_income = models.DecimalField(max_digits=10,
                                decimal_places=2,default=0)
    amount_earned_this_month = models.DecimalField(max_digits=10,
                                decimal_places=2,default=0)
    
    user = AutoOneToOneField(User,on_delete=models.CASCADE,
                                primary_key=True)
    
    def __str__(self):
        return "This month {}/{}".format(self.amount_earned_this_month,
                        self.projected_monthly_income)
