from django.db import models
from core.models import User
from annoying.fields import AutoOneToOneField

class SavingsSummary(models.Model):
    monthly_savings_goal = models.DecimalField(max_digits=10,decimal_places=2,default=0)
    current_monthly_savings = models.DecimalField(max_digits=10,decimal_places=2,default=0)
    
    user = AutoOneToOneField(User,on_delete=models.CASCADE,primary_key=True)


    def __str__(self):
        return "This month {}/{}".format(self.current_monthly_savings,
                                            self.monthly_savings_goal)
