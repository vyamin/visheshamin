from django.core.management.base import BaseCommand
from core.models import User
from core.tests.factories import UserFactory

class Command(BaseCommand):
  help = "Prepopulates database with data for postman tests"

  def handle(self,*args,**options):
    self.stdout.write('Prepopulating database with data')
    user = UserFactory(name='Postman Client',email='postman_client@genieapp.net')
    user.set_password('SomePass123')
    user.save()
    self.stdout.write(str(User.objects.count()))
    
