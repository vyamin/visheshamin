from django_filters import rest_framework as filters
from rest_framework import viewsets
from rest_framework.filters import SearchFilter,OrderingFilter
from rest_framework.permissions import IsAuthenticated
from core.models import SavingsGoal
from core.serializers import SavingsGoalSerializer


class SavingsGoalViewSet(viewsets.ModelViewSet):
    queryset = SavingsGoal.objects.all()
    serializer_class = SavingsGoalSerializer
    permission_classes = [IsAuthenticated]

    filter_backends = [filters.DjangoFilterBackend,
            SearchFilter,OrderingFilter]
    filterset_fields = { 'target_date':['gte','lte']}
    search_fields = ('description',)
    ordering_fields = ('description','target_date','amount')
    ordering = ('target_date',)


    def get_queryset(self):
        return self.queryset.filter(user = self.request.user)

    