import os
from django.shortcuts import render
from rest_framework import permissions
from rest_framework import status
from rest_framework.decorators import api_view
from rest_framework.response import Response
from core.models.plaid_item import PlaidItem
from core.models.institution import Institution
from core.models.account import Account
from core.services.plaid_service import PlaidService
from core.services.account_service import AccountService

@api_view(['GET'])
def plaid_link_options_hash(request):
    plaid_options = {
        'env':os.environ.get('PLAID_ENV'),
        'key':os.environ.get('PLAID_PUBLIC_KEY'),
        'product':os.environ.get('PLAID_PRODUCT')
    }
    return Response(plaid_options)

@api_view(['POST'])
def plaid_get_access_token(request):
    if (('public_token' not in request.data) or 
        (request.data['public_token']==None) or
        (request.data['public_token']=='')):
        data = {
            'public_token':['Public token returned by Link should be present']
        }
        return Response(data, status=status.HTTP_400_BAD_REQUEST)
    public_token = request.data['public_token']
    service = PlaidService()
    result,response = service.exchange_token(public_token)
    if not result:
        return Response({'detail':response},status.HTTP_500_INTERNAL_SERVER_ERROR)
    access_token = response['access_token']
    item_id = response['item_id']
    try:
        item = PlaidItem.objects.get(plaid_item_id=item_id)
    except:
        item = PlaidItem.objects.create(plaid_access_token=access_token,
                        plaid_item_id=item_id,
                        user = request.user)
    else:
        item.plaid_access_token = response['access_token']
        item.save()
    
    # Henceforth all actions are optional. So lets not fail due 
    # to any of them failing
    # try:
    result,response = service.get_item(access_token)
    if not result:
        return Response(status = status.HTTP_200_OK)
    institution_id = response['institution_id']
    # Check if this institution is present in our db
    try:
        institution = Institution.objects.get(
                    plaid_institution_id = institution_id)
    except:
        # Fetch details on the institution and create
        result,response = service.get_institution(institution_id)
        if not result:
            return Response(status=status.HTTP_200_OK)
        institution_name = response['name']
        institution = Institution.objects.create(
            plaid_institution_id=institution_id,
            name = institution_name
        )
    # Set the status of the item to 'ENRICHED'
    item.status = PlaidItem.Status.ENRICHED
    item.save()
    # Let us get the account info
    result,response = service.get_accounts(access_token)
    if not result:
        return Response(status=status.HTTP_200_OK)
    account_service = AccountService()
    result, response = account_service.create_accounts(response,request.user,
                            institution,item)
    if not result:
        return Response(status=status.HTTP_200_OK)
    print(result,response)
    item.status = PlaidItem.Status.ACTIVE
    item.save()
        
    # except Exception as e:
    #     pass
    return Response(status = status.HTTP_200_OK)
    

