from rest_framework import viewsets
from rest_framework.filters import SearchFilter,OrderingFilter
from rest_framework.permissions import IsAuthenticated

from core.models import User, Spending
from core.serializers import SpendingSerializer

class SpendingViewSet(viewsets.ModelViewSet):
    queryset = Spending.objects.all()
    serializer_class = SpendingSerializer
    permission_classes = [IsAuthenticated]

    filter_backends = [SearchFilter,OrderingFilter]
    search_fields = ('label',)
    ordering_fields = ('label','amount')
    ordering = ('-amount')

    def get_queryset(self):
        return self.queryset.filter(user = self.request.user)
