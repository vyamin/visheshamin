from rest_framework import permissions

class IsOwnerOrAdmin(permissions.BasePermission):
    def has_object_permission(self,request,view,obj):
      if (not(request.user) or not(request.user.is_authenticated)):
        return False
      if request.user.is_staff:
        return True
      return obj.user == request.user

class IsWorker(permissions.BasePermission):
  def has_permission(self, request, view):
    return bool(request.user and request.user.is_authenticated and 
            request.user.is_worker)        

class ReadOnly(permissions.BasePermission):
    def has_permission(self,request,view):
      return bool(request.user and request.user.is_authenticated and 
              request.method in permissions.SAFE_METHODS)

class Forbidden(permissions.BasePermission):
  def has_permission():
    return False
  def has_object_permission():
    return False