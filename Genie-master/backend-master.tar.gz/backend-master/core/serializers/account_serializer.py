from rest_framework.serializers import ModelSerializer
from core.models.account import Account

class AccountSerializer(ModelSerializer):
    class Meta:
        model = Account
        fields = '__all__'