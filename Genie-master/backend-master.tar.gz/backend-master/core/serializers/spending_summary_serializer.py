from rest_framework import serializers
from core.models import SpendingSummary

class SpendingSummarySerializer(serializers.ModelSerializer):
    projected_monthly_spending = serializers.FloatField()
    amount_spent_this_month = serializers.FloatField()
    user = serializers.HiddenField(
        default=serializers.CurrentUserDefault())
               
    class Meta:
        model = SpendingSummary
        fields = '__all__'