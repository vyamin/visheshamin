from rest_framework import serializers
from core.models import SavingsGoal

class SavingsGoalSerializer(serializers.ModelSerializer):

    monthly_savings_needed = serializers.ReadOnlyField()
    amount = serializers.FloatField()

    user = serializers.HiddenField(
        default=serializers.CurrentUserDefault())
    class Meta:
        model = SavingsGoal
        fields = '__all__'
