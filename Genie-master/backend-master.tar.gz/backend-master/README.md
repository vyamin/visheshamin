# backend

Backend server for the Genie app 