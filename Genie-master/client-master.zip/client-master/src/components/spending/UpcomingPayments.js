import React from 'react'
import {Container,Row,Col,Button} from 'react-bootstrap'
import { connect } from 'react-redux';
import {Link} from 'react-router-dom';

import {history} from '../../helpers/history';
import { LoadingMessage, SimpleTableWithActions } from '../ui'
import { FailureMessage } from '../ui'

import {spendingActions} from '../../actions';

class UpcomingPayments extends React.Component{

  componentDidMount(){
    this.props.getUpcomingPayments(this.props.token)
  }

  onEditItem = (item)=>{
    history.push('/payments/edit/'+item.id);
  }

  onDeleteItem = (item)=>{
    this.props.deleteUpcomingPayment(this.props.token,item.id);
  }

  renderTable(){
    const upcomingPayments = this.props.upcomingPayments;
    if(!upcomingPayments){
      return <FailureMessage header="There are no upcoming payments currently."
          subheader="Try after some time" buttonText="Spending" buttonRoute="/spending-summary"/>
    }

    return(
      <SimpleTableWithActions 
      header = {['Payment', 'Amount','Due Date']}
      fields = {['description','amount','due_date']}
      id_field = {'id'}
      items = {Object.values(upcomingPayments)}
      itemType = {'Upcoming Payment'}
      onEditItem = {this.onEditItem}
      onDeleteItem = {this.onDeleteItem}/>
    );
  }
  render() {
    if(this.props.fetchingUpcomingPayments){
      return <LoadingMessage 
      header= "Just one second" 
      content= "We are loading your payments"
      />
    }
    return (
      <Container>
        <Row className="justify-content-center">
          <Col md={8} className="p-0">
            <Container>
              <Row className="mt-3">
                <Col className="text-center">
                  <h3>Upcoming Payments</h3>
                </Col>
              </Row>
              <Row>
                <Col className="p-0">
                  {this.renderTable()}
                </Col>
              </Row>
              <Row>
                <Col className="text-right p-0">
                  <Button variant="primary" as={Link} to="/payments/new/">Add a Payment</Button>
                </Col>
              </Row>
            </Container>
          </Col>
        </Row>
      </Container>
    );
  }
}

const mapStateToProps = (state,ownProps)=>{
  return {
    token: state.auth.user.access,
    fetchingUpcomingPayments: state.spending.fetchingUpcomingPayments,
    upcomingPayments: state.spending.upcomingPayments,

  }
}

const actionCreators={
  getUpcomingPayments: spendingActions.getUpcomingPayments,
  deleteUpcomingPayment: spendingActions.deleteUpcomingPayment,
}

const connectedUP = connect(mapStateToProps,actionCreators)(UpcomingPayments)
export {connectedUP as UpcomingPayments};
