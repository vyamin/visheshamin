import React from 'react';
import {connect} from 'react-redux';
import {Container,Row,Col,Button} from 'react-bootstrap';
import {Link} from 'react-router-dom';

import {LoadingMessage,SimpleTable} from '../ui';

class UpcomingPaymentsSmall extends React.Component{

  render(){
    if(this.props.fetchingSpendingSummary){
      return <LoadingMessage 
      header= "Just one second" 
      content= "We are loading your upcoming payments"
      />
    }
    if(!this.props.spendingSummary){
      return <p>Did not find any upcoming payments.</p>
    }
    const upcomingPayments = this.props.spendingSummary.upcoming_payments;
    return (
      <Container>
        <Row className="justify-content-center">
          <Col className="text-center">
            <h4>Upcoming Payments</h4>
          </Col>
        </Row>
        <Row className="justify-content-center">
          <Col>
            <SimpleTable 
              id_field={'id'}
              header={['Due Date','Description','Amount']}
              fields={['due_date','description','amount']}
              items={upcomingPayments}/>
          </Col>
        </Row>
        <Row>
          <Col className="text-right">
            <Link to="/payments">
              <Button>Manage Payments</Button>
            </Link>
          </Col>
        </Row>        
      </Container>
    );
  }
}

const mapStateToProps= (state,ownProps) => {
  return {
    token: state.auth.user.access,
    fetchingSpendingSummary: state.spending.fetchingSpendingSummary,
    spendingSummary: state.spending.spendingSummary
  }
}

const connectedUP = connect(mapStateToProps,null)(UpcomingPaymentsSmall);
export {connectedUP as UpcomingPaymentsSmall}