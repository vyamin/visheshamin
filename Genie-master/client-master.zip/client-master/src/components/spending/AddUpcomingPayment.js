import React from 'react'
import {connect} from 'react-redux'

import {spendingActions} from "../../actions";
import {history} from '../../helpers';
import {UpcomingPaymentForm} from '.';

class AddUpcomingPayment extends React.Component{
  onSubmit = (formValues) => {
    this.props.addUpcomingPayment(this.props.token,formValues);
  }
  onCancel = ()=> {
    history.push('/payments/')
  }

  render(){
    return (
      <UpcomingPaymentForm
        formTitle= "Add Upcoming Payment"
        working = {this.props.addingUpcomingPayment}
        onCancel={this.onCancel}
        onSubmit={this.onSubmit}/>
    );
  }
}

const mapStateToProps = (state, ownProps)=> {
  return {
    token: state.auth.user.access,
    addingUpcomingPayment: state.spending.addingUpcomingPayment
  };
};
const actionCreators = {
  addUpcomingPayment: spendingActions.addUpcomingPayment
}

const connectedAI = connect(mapStateToProps,actionCreators)(AddUpcomingPayment);
export {connectedAI as AddUpcomingPayment};