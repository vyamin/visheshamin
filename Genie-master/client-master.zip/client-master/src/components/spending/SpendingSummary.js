import React from 'react';
import {connect} from 'react-redux';
import {Container,Row,Col,Card} from 'react-bootstrap';

import {SpendingIndicator,UpcomingPaymentsSmall,SpendingProjection} from '.';
import {spendingActions} from '../../actions';
import {LoadingMessage} from '../ui';

class SpendingSummary extends React.Component{

  componentDidMount(){
    this.props.getSpendingSummary(this.props.token);
  }

  renderProjectedMonthlySpending(){
    const spendSum = this.props.spendingSummary;
    if(spendSum && spendSum.spending_summary.projected_monthly_spending!==0){
      return(
      <h4>
        Projected monthly spending : {spendSum.spending_summary.projected_monthly_spending}
      </h4>);
    }
  }
  renderSpendingIndicator(){
    const spendSum = this.props.spendingSummary;
    if(spendSum){
      return <SpendingIndicator/>
    }
  }
  renderPaymentList(){
    return <UpcomingPaymentsSmall/>
  }  
  renderYearlyGraph(){
    if(this.props.spendingSummary){
      return <SpendingProjection/>
    }
  }
  
  render(){
    if(this.props.fetchingSpendingSummary){
      return <LoadingMessage 
      header= "Just one second" 
      content= "We are loading your spending summary"
      />
    }
    return (
      <Container>
        <Row className="justify-content-center">
          <Col md={8}>
            <Container>
              <Row className="mt-3">
                <Col className="text-center">
                  {this.renderProjectedMonthlySpending()}
                </Col>
              </Row>
              <Row className="mt-2">
                <Col className="text-center">
                  {this.renderSpendingIndicator()}
                </Col>
              </Row>
              <Row className="mt-2">
                <Col className="text-center">
                  <Card className="py-2">
                    {this.renderPaymentList()}
                  </Card>
                </Col>
              </Row>
              <Row className="mt-2">
                <Col className="text-center">
                  {this.renderYearlyGraph()}
                </Col>
              </Row>
            </Container>
          </Col>
        </Row>
      </Container>
    )
  }
}

const mapStateToProps= (state,ownProps) => {
  return {
    token: state.auth.user.access,
    fetchingspendingSummary: state.spending.fetchingspendingSummary,
    spendingSummary: state.spending.spendingSummary
  }
}

const actionCreators = {
  getSpendingSummary:spendingActions.getSpendingSummary
}

const connectedSS = connect(mapStateToProps,actionCreators)(SpendingSummary);
export {connectedSS as SpendingSummary}