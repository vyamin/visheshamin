import React from 'react';
import { connect } from 'react-redux';
import {Link} from 'react-router-dom';
import {Table,Container,Row,Col,Button} from 'react-bootstrap';

import {LoadingMessage,FailureMessage} from '../ui';
import {accountActions} from '../../actions';


class TransactionsList extends React.Component{
  componentDidMount(){
    if (!this.props.account)
      this.props.getAccount(this.props.token,
          this.props.match.params.id);
    this.props.getTransactions(this.props.token,
        this.props.match.params.id);
  }

  renderRow(index,transaction){
    let amount = transaction.amount;
    if(transaction.category==='CREDIT'){
      amount = "-"+amount;
    }
    return (
      <tr key={index}>
        <td>
          {transaction.date.substring(0,transaction.date.indexOf('T'))}              
        </td>
        <td>
          {transaction.description}
        </td>
        <td>
          {amount}
        </td>
      </tr>
    )
  }

  render()  {
    const account_id = this.props.match.params.id;
    if(this.props.fetchingTransactions){
      return <LoadingMessage 
      header= "Just one second" 
      content= "We are loading your transactions info"
      />
    }
    const account = this.props.account
    const transactions = this.props.transactions
    if(transactions.length===0){
      return <FailureMessage 
          header="We could not get the transactions at this time"
          subheader="Try after some time" 
          buttonText="Account" buttonRoute={"/accounts/"+account_id}/>
    }
    const bodyRows = []
    for(const[index,transaction] of transactions.entries()){
      bodyRows.push(this.renderRow(index,transaction));
    }
    return (
      <Container>
        <Row className="justify-center-content">
          <Col className="text-center">
            <h3>{"Transactions for " + account.nick_name}</h3>
          </Col>          
        </Row>
        <Row>
          <Table striped bordered hover>
            <thead>
              <tr>
                <th>Date</th>
                <th>Description</th>
                <th>Amount</th>
              </tr>
            </thead>
            <tbody>
              {bodyRows}
            </tbody>
          </Table>
        </Row>
        <Row>
          <Col className="text-center">
            <Button primary as = {Link} to={"/accounts/"+account_id}>Account</Button>
          </Col>
        </Row>
      </Container>
    );    
  }
}


const mapStateToProps = (state,ownProps) => {
  return {
    token: state.auth.user.access,
    account: state.account.account,
    transactions: state.account.transactions,
    fetchingTransactions: state.account.fetchingTransactions
  }
}

const actionCreators={
  getAccount:accountActions.getAccount,
  getTransactions:accountActions.getTransactions
}

const connectedTransactionsList =  connect(mapStateToProps,
                                    actionCreators)(TransactionsList);

export {connectedTransactionsList as TransactionsList};