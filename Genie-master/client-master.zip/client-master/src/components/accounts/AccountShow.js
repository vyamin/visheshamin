import React from 'react';
import {connect} from 'react-redux';
import { Link } from 'react-router-dom';
import {Container,Row,Col,Button, Form} from 'react-bootstrap';

import {accountActions} from '../../actions'
import {history} from '../../helpers';
import {LoadingMessage,FailureMessage} from '../ui/';


class AccountShow extends React.Component{
  
  componentDidMount(){
    this.props.getAccount(this.props.token,this.props.match.params.id);
  }

  backToAccountsClicked = () => {
    history.push('/wallet')
  }

  renderFormGroup(label,value) {
    return(
      <Form.Group as={Row}>
        <Form.Label column xs="3">
          {label}
        </Form.Label>
        <Col xs={9} >
          <Form.Control plaintext readOnly defaultValue= {value}/>
        </Col>
      </Form.Group>
    );
  }

  render() {
    if(this.props.fetchingAccount){
      return <LoadingMessage 
        header= "Just one second" 
        content= "We are loading your account info"
        />
    }
    const account = this.props.account;
    if (!account){
      return <FailureMessage header="We could not get the account details at this time"
          subheader="Try after some time" buttonText="Wallet" buttonRoute="/wallet"/>
    }
    return (
      <Container>
        <Row className="justify-content-center mt-3">  
          <Col md={10}>
            <Container>
              <Row>
                <Col className="text-center">
                  <h3>{account.nick_name}</h3>
                </Col>
              </Row>
              <Row className="mt-2">
                <Col className="auto-ml">
                  <Link to={"/accounts/"+account.id+"/transactions"}>
                    <Button variant="primary">Transactions</Button>
                  </Link>
                </Col>
                <Col className="auto-mr text-right">
                  <Link to="/wallet">
                    <Button variant="secondary">Wallet</Button>
                  </Link>
                </Col>
              </Row>
              <Row>
                <Col>
                  <Form className="mt-3">
                    {this.renderFormGroup('Name:',account.name)}
                    {this.renderFormGroup('Bank:',account.institution_name)}
                    {this.renderFormGroup('Type:',account.account_type)}
                    {this.renderFormGroup("SubType:",account.account_subtype)}
                    {this.renderFormGroup("Current Balance:",account.current_balance)}
                    {this.renderFormGroup("Available Balance:",account.available_balance)}
                    {this.renderFormGroup("Account Limit:",account.account_limit)}
                  </Form>
                </Col>
              </Row>
            </Container>
          </Col>
        </Row>
      </Container>
    );
  }
}

const mapStateToProps = (state,ownProps) => {
  return {
    token: state.auth.user.access,
    account: state.account.account,
    fetchingAccount: state.account.fetchingAccount
  }
}
const actionCreators = {
  getAccount: accountActions.getAccount
}
const connectedAccountShow = connect(mapStateToProps,actionCreators)(AccountShow);
export {connectedAccountShow as AccountShow};