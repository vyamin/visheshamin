import React from 'react'
import {Table} from 'react-bootstrap'

export class SimpleTable extends React.Component{
  renderTableHeader(){
    let headerRow =[]
    for(const headerCol of this.props.header){
      headerRow.push(<th key={headerCol}>{headerCol}</th>)
    }
    return(
      <thead>
        <tr>
          {headerRow}
        </tr>
      </thead>
    );
  }
  renderRow(item){
    let columns=[]
    const fields = this.props.fields;
    const id_field = this.props.id_field;
    for(const field of fields){
      columns.push(<td key={field}>{item[field]}</td>)
    }
    return (
      <tr key={item[id_field]}>
        {columns}
      </tr>
    );
  }
  renderTableBody(){
    let rows=[]
    for(const item of this.props.items){
      rows.push(this.renderRow(item));
    }
    return(
      <tbody>
        {rows}
      </tbody>
    );

  }
  render() {
    return(
      <Table responsive striped bordered hover>
        {this.renderTableHeader()}     
        {this.renderTableBody()}   
      </Table>)
  }
}