import React from 'react'
import {Table,Button} from 'react-bootstrap'
import {FontAwesomeIcon} from '@fortawesome/react-fontawesome'
import {faEdit,faTrash} from '@fortawesome/free-solid-svg-icons'
import {ConfirmDialog} from '.'

//props: header,fields,id,items,itemType,onEditItem,onDeleteItem
export class SimpleTableWithActions extends React.Component{

  state={
    showModal: false,
    curItem: false
  }

  onCancelModal = ()=>{
    this.setState({showModal:false})
  }

  onConfirmModal= ()=> {
    this.setState({showModal:false});
    this.props.onDeleteItem(this.state.curItem);
  }

  onClickDelete = (item) => {
    this.setState({
      showModal: true,
      curItem: item
    })
  }

  renderTableHeader(){
    let headerRow =[]
    for(const headerCol of this.props.header){
      headerRow.push(<th key={headerCol}>{headerCol}</th>)
    }
    headerRow.push(<th key="actions"></th>);
    return(
      <thead>
        <tr>
          {headerRow}
        </tr>
      </thead>
    );
  }

  renderLinks(item){
    return(
      <React.Fragment>
        <Button className="mr-1" variant="outline-dark" onClick={()=>this.props.onEditItem(item)}>
          <FontAwesomeIcon  icon={faEdit}/>
        </Button>
        <Button variant="outline-dark" onClick={()=>this.onClickDelete(item)}>
          <FontAwesomeIcon  icon={faTrash}/>        
          </Button>
      </React.Fragment>
    )
  }

  renderRow(item){
    let columns=[]
    const fields = this.props.fields;
    const id_field = this.props.id_field;
    for(const field of fields){
      columns.push(<td key={field}>{item[field]}</td>)
    }
    columns.push(<td key="actions">{this.renderLinks(item)}</td>)
    return (
      <tr key={item[id_field]}>
        {columns}
      </tr>
    );
  }

  renderTableBody(){
    let rows=[]
    for(const item of this.props.items){
      rows.push(this.renderRow(item));
    }
    return(
      <tbody>
        {rows}
      </tbody>
    );
  }
  
  render() {
    return(
      <React.Fragment>
        <Table responsive bordered striped hover>
          {this.renderTableHeader()}     
          {this.renderTableBody()}   
        </Table>
        <ConfirmDialog show={this.state.showModal}
          header="Warning!!"
          message={"Are you sure you want to delete this "+this.props.itemType+"?"}
          onCancel={this.onCancelModal}
          onConfirm={this.onConfirmModal}
        />
      </React.Fragment>
    );
  }
}