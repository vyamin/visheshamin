import React from 'react';
import {Container,Row, Col,Spinner} from 'react-bootstrap';

export const LoadingMessage = (props) => (
  <Container>
    <Row className="mt-3">
      <Col md={8}>
        <h3><Spinner as="span" animation="border" role="status"/> {props.header}</h3>
        <p>{props.content}</p>
      </Col>
    </Row>
  </Container>
)