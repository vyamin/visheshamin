import React from 'react';
import {connect} from 'react-redux';
import {Container,Row,Col} from 'react-bootstrap';
import {LineChart, Line, CartesianGrid,XAxis,YAxis, ResponsiveContainer} from 'recharts';

import {LoadingMessage} from '../ui';

class IncomeProjection extends React.Component{

  render(){
    if(this.props.fetchingIncomeSummary){
      return <LoadingMessage 
      header= "Just one second" 
      content= "We are loading your income projections"
      />
    }
    if(!this.props.incomeSummary || this.props.incomeSummary.income_projections.length===0){
      return '';
    }
    const income_projections = this.props.incomeSummary.income_projections;
    
    return (
      <Container>
        <Row className="justify-content-center">
          <Col className="text-center">
            <h4>Projection of monthly income</h4>
          </Col>
        </Row>
        <Row className="justify-content-center">
          <Col className="text-center">
            <ResponsiveContainer width="95%" height={300}>
              <LineChart data={income_projections}>
                <Line type="monotone" dataKey="amount" stroke="#8884d8"/>
                <CartesianGrid stroke="#ccc" />
                <XAxis dataKey="target_date" />
                <YAxis domain={['dataMin-1000','dataMax+1000']}/>
              </LineChart>
            </ResponsiveContainer>
          </Col>
        </Row>
      </Container>
    );
  }
}

const mapStateToProps= (state,ownProps) => {
  return {
    fetchingIncomeSummary: state.income.fetchingIncomeSummary,
    incomeSummary: state.income.incomeSummary
  }
}

const connectedIP = connect(mapStateToProps,null)(IncomeProjection);
export {connectedIP as IncomeProjection}