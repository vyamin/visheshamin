import React from 'react';
import {connect} from 'react-redux';
import {Container,Row,Col,Card} from 'react-bootstrap';

import {incomeActions} from '../../actions';
import {LoadingMessage} from '../ui';
import {IncomeIndicator,IncomeListSmall,IncomeProjection} from '.';

class IncomeSummary extends React.Component{

  componentDidMount(){
    this.props.getIncomeSummary(this.props.token);
  }

  renderProjectedMonthlyIncome(){
    const incSum = this.props.incomeSummary;
    if(incSum && incSum.income_summary.projected_monthly_income!==0){
      return(
      <h3>
        Projected monthly income : {incSum.income_summary.projected_monthly_income}
      </h3>);
    }

  }
  renderIncomeIndicator(){
    if(this.props.incomeSummary){
      return <IncomeIndicator/>
    }
  }
  renderIncomeList(){
    if(this.props.incomeSummary){
      return <IncomeListSmall/>
    }
  }  
  renderYearlyGraph(){
    if(this.props.incomeSummary){
      return <IncomeProjection/>
    }
  }
  
  render(){
    if(this.props.fetchingIncomeSummary){
      return <LoadingMessage 
      header= "Just one second" 
      content= "We are loading your income summary"
      />
    }
    return(
      <Container>
        <Row className="justify-content-center">
          <Col md={8}>
            <Container>
              <Row className="mt-3">
                <Col className="text-center">
                    {this.renderProjectedMonthlyIncome()}
                </Col>
              </Row>
              <Row className="mt-2">
                <Col className="text-center">
                    {this.renderIncomeIndicator()}
                </Col>
              </Row>
              <Row className="mt-2">
                <Col className="text-center">
                  <Card className="py-2">
                    {this.renderIncomeList()}
                  </Card>
                </Col>
              </Row>
              <Row className="mt-2">
                <Col className="text-center">
                    {this.renderYearlyGraph()}
                </Col>
              </Row>              
            </Container>
          </Col>
        </Row>
      </Container>
    )
  }
}

const mapStateToProps= (state,ownProps) => {
  return {
    token: state.auth.user.access,
    fetchingIncomeSummary: state.income.fetchingIncomeSummary,
    incomeSummary: state.income.incomeSummary
  }
}

const actionCreators = {
  getIncomeSummary:incomeActions.getIncomeSummary
}

const connectedIS = connect(mapStateToProps,actionCreators)(IncomeSummary);
export {connectedIS as IncomeSummary}