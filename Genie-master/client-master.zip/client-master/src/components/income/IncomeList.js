import React from 'react'
import {Container,Row,Col,Button} from 'react-bootstrap'
import { connect } from 'react-redux';
import {Link} from 'react-router-dom';

import {history} from '../../helpers/history';
import { LoadingMessage, SimpleTableWithActions } from '../ui'
import { FailureMessage } from '../ui'

import {incomeActions} from '../../actions';

class IncomeList extends React.Component{

  componentDidMount(){
    this.props.getIncomeList(this.props.token)
  }

  onEditItem = (item)=>{
    history.push('/incomes/edit/'+item.id);
  }

  onDeleteItem = (item)=>{
    this.props.deleteIncome(this.props.token,item.id);
  }

  renderTable(){
    const incomeSources = this.props.incomeList;
    if(!incomeSources){
      return <FailureMessage header="There are no incomes sources currently."
          subheader="Try after some time" buttonText="Income" buttonRoute="/income-summary"/>
    }

    return(
      <SimpleTableWithActions 
      header = {['Income Source', 'Amount']}
      fields = {['label','amount']}
      id_field = {'id'}
      items = {Object.values(incomeSources)}
      itemType = {'Income Source'}
      onEditItem = {this.onEditItem}
      onDeleteItem = {this.onDeleteItem}/>
    );
  }
  render() {
    if(this.props.fetchingIncomeList){
      return <LoadingMessage 
      header= "Just one second" 
      content= "We are loading your income sources"
      />
    }
    return (
      <Container>
        <Row className="justify-content-center">
          <Col md={8} className="p-0">
            <Container>
              <Row className="mt-3">
                <Col className="text-center">
                  <h3>Income Sources</h3>
                </Col>
              </Row>
              <Row>
                <Col className="p-0">
                  {this.renderTable()}
                </Col>
              </Row>
              <Row>
                <Col className="text-left p-0">
                  <Button variant="secondary" as={Link} to="/income-summary">Income Summary</Button>
                </Col>                
                <Col className="text-right p-0">
                  <Button variant="primary" as={Link} to="/incomes/new/">Add Income Source</Button>
                </Col>
              </Row>
            </Container>
          </Col>
        </Row>
      </Container>
    );
  }
}

const mapStateToProps = (state,ownProps)=>{
  return {
    token: state.auth.user.access,
    fetchingIncomeList: state.income.fetchingIncomeList,
    incomeList: state.income.incomeList,

  }
}

const actionCreators={
  getIncomeList: incomeActions.getIncomeList,
  deleteIncome: incomeActions.deleteIncome,
}

const connectedIL = connect(mapStateToProps,actionCreators)(IncomeList)
export {connectedIL as IncomeList};
