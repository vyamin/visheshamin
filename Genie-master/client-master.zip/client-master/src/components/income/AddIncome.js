import React from 'react'
import {connect} from 'react-redux'

import {incomeActions} from "../../actions";
import {history} from '../../helpers';
import {IncomeForm} from '.';

class AddIncome extends React.Component{
  onSubmit = (formValues) => {
    this.props.addIncome(this.props.token,formValues);
  }
  onCancel = ()=> {
    history.push('/incomes/')
  }

  render(){
    return (
      <IncomeForm
        formTitle= "Add Income Source"
        working = {this.props.addingIncome}
        onCancel={this.onCancel}
        onSubmit={this.onSubmit}/>
    );
  }
}

const mapStateToProps = (state, ownProps)=> {
  return {
    token: state.auth.user.access,
    addingIncome: state.income.addingIncome
  };
};
const actionCreators = {
  addIncome: incomeActions.addIncome
}

const connectedAI = connect(mapStateToProps,actionCreators)(AddIncome);
export {connectedAI as AddIncome};