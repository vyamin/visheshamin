import React from 'react';
import { connect } from 'react-redux';
import {Container,Row,Col,Card} from 'react-bootstrap';

import {SavingsIndicator,SavingsProjection} from '.';
import {SavingsGoalsSmall} from '.';
import {savingsActions} from '../../actions'
import {LoadingMessage} from '../ui'

class SavingsSummary extends React.Component{
  componentDidMount(){
    this.props.getSavingsSummary(this.props.token);
  }

  renderProjectedMonthlySavings(){
    const savSum = this.props.savingsSummary;
    if(savSum && savSum.savings_summary 
        && savSum.savings_summary.monthly_savings_goal !== 0){
      return(
      <h3>{"Monthly savings goal: "+savSum.savings_summary.monthly_savings_goal}</h3>
      );
    }
  }
  renderSavingsIndicator(){
    const savSum = this.props.savingsSummary;
    if(savSum && savSum.savings_summary 
      && savSum.savings_summary.monthly_savings_goal !== 0){
        return  <SavingsIndicator/>
      }
  }
  
  renderSavingsGoals(){
    const savSum = this.props.savingsSummary;
    if (savSum){
      return <SavingsGoalsSmall/>
    }
  }

  renderSavingsProjection(){
    const savSum = this.props.savingsSummary;
    if (savSum){
      return <SavingsProjection/>
    }
  }

  render(){
    if(this.props.fetchingSavingsSummary){
      return <LoadingMessage 
      header= "Just one second" 
      content= "We are loading your savings summary"
      />
    }
    return (
      <Container>
        <Row className="justify-content-center">
          <Col md={8}>
            <Container>
              <Row className="mt-3">
                <Col className="text-center">
                  {this.renderProjectedMonthlySavings()}
                </Col>
              </Row>
              <Row className="mt-2">
                <Col className="text-center">
                  {this.renderSavingsIndicator()}
                </Col>
              </Row>
              <Row className="mt-2">
                <Col className="text-center">
                  <Card className="py-2">
                    {this.renderSavingsGoals()}
                  </Card>
                </Col>
              </Row>     
              <Row className="mt-2">
                <Col className="text-center">
                  {this.renderSavingsProjection()}
                </Col>
              </Row>                            
            </Container>
          </Col>
        </Row>
      </Container>
    )
  }
}

const mapStateToProps = (state,ownProps) => {
  return {
    token: state.auth.user.access,
    fetchingSavingsSummary: state.savings.fetchSavingsSummary,
    savingsSummary: state.savings.savingsSummary
  }
}

const actionCreators = {
  getSavingsSummary: savingsActions.getSavingsSummary
}

const connectedSS = connect(mapStateToProps,actionCreators)(SavingsSummary)
export {connectedSS as SavingsSummary}