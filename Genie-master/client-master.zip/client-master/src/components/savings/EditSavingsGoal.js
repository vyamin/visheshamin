import React from 'react';
import { connect } from 'react-redux';
import _ from 'lodash';


import {SavingsGoalForm} from '.';
import {savingsActions} from '../../actions';
import {LoadingMessage} from '../ui';
import {history} from '../../helpers'

class EditSavingsGoal extends React.Component{
  componentDidMount(){
    this.props.getSavingsGoal(this.props.token,this.props.match.params.id);
  }
  
  onSubmit = (formValues) => {
    this.props.modifySavingsGoal(this.props.token,this.props.match.params.id, formValues);
  }

  onCancel = () => {
    history.push('/savings/');
  }

  render(){
    if(this.props.fetchingSavingsGoal){
      return <LoadingMessage 
      header= "Just one second" 
      content= "We are loading your goals"
      />
    }
    return (
      <SavingsGoalForm
        initialValues={_.pick(this.props.savingsGoal,'description','amount','target_date')}
        formTitle= "Modify Savings Goal"
        working = {this.props.updatingSavingsGoal}
        onCancel={this.onCancel}
        onSubmit={this.onSubmit}/>
    );
  }
}

const mapStateToProps = (state, ownProps)=> {
  return {
    token: state.auth.user.access,
    fetchingSavingsGoal: state.savings.fetchingSavingsGoal,
    updatingSavingsGoal: state.savings.updatingSavingsGoal,
    savingsGoal: state.savings.savingsGoals[ownProps.match.params.id]
  };
};
const actionCreators = {
  getSavingsGoal: savingsActions.getSavingsGoal,
  modifySavingsGoal: savingsActions.modifySavingsGoal
}

const connectedESG = connect(mapStateToProps,actionCreators)(EditSavingsGoal);
export {connectedESG as EditSavingsGoal};