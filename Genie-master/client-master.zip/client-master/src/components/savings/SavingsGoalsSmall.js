import React from 'react';
import {connect} from 'react-redux';
import {Container,Row,Col,Button} from 'react-bootstrap';
import {Link} from 'react-router-dom';

import {LoadingMessage,SimpleTable} from '../ui';

class SavingsGoalsSmall extends React.Component{
  render(){
    if(this.props.fetchingSavingsSummary){
      return <LoadingMessage 
      header= "Just one second" 
      content= "We are loading your savings goals"
      />
    }
    const savingsGoals = this.props.savingsSummary.savings_goals;
    return (
      <Container>
        <Row className="justify-content-center">
          <Col className="text-center">
            <h4>Savings Goals</h4>
          </Col>
        </Row>
        <Row className="justify-content-center">
          <Col>
            <SimpleTable 
              id_field={'id'}
              header={['Goal','Amount','Target Date']}
              fields={['description','amount','target_date']}
              items={savingsGoals}/>
          </Col>
        </Row>
        <Row>
          <Col className="text-right">
            <Link to="/savings">
              <Button>Manage Goals</Button>
            </Link>
          </Col>
        </Row>        
      </Container>
    );
  }
}

const mapStateToProps= (state,ownProps) => {
  return {
    token: state.auth.user.access,
    fetchingSavingsSummary: state.savings.fetchingSavingsSummary,
    savingsSummary: state.savings.savingsSummary
  }
}


const connectedSG = connect(mapStateToProps,null)(SavingsGoalsSmall);
export {connectedSG as SavingsGoalsSmall}