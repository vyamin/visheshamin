import React from 'react';
import {connect} from 'react-redux';
import {Container,Row,Col} from 'react-bootstrap';


import {CircularProgressbar, buildStyles} from 'react-circular-progressbar';
import 'react-circular-progressbar/dist/styles.css';

import {LoadingMessage} from '../ui';

class SavingsIndicator extends React.Component{

  render(){
    if(this.props.fetchingSavingsSummary){
      return <LoadingMessage 
      header= "Just one second" 
      content= "We are loading your savings summary"
      />
    }
    if(!this.props.savingsSummary || 
      (this.props.savingsSummary.savings_summary.current_monthly_savings===0
        && this.props.savingsSummary.savings_summary.monthly_savings_goal===0)){
      return <p>Genie is yet to analyse your savings. Please check after some time.</p>
    }
    const savSum = this.props.savingsSummary;
    const value = savSum.savings_summary.current_monthly_savings;
    const total = savSum.savings_summary.monthly_savings_goal;
    return(
      <Container>
        <Row className="justify-content-center">
          <Col style={{maxWidth:160}}  className="text-center">
            <CircularProgressbar value={value} maxValue={total}  
              text={value} styles={buildStyles({ pathColor: "green",
                trailColor: "black"})} />
            <h5 className="mt-1">Savings this month</h5>
          </Col>
        </Row>
      </Container>
    ); 
  }
}

const mapStateToProps= (state,ownProps) => {
  return {
    token: state.auth.user.access,
    fetchingSavingsSummary: state.savings.fetchingSavingsSummary,
    savingsSummary: state.savings.savingsSummary
  }
}

const connectedSI = connect(mapStateToProps,null)(SavingsIndicator);
export {connectedSI as SavingsIndicator};