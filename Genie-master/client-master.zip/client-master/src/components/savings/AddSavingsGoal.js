import React from 'react'
import {connect} from 'react-redux'

import {savingsActions} from "../../actions";
import {history} from '../../helpers';
import {SavingsGoalForm} from '.';

class AddSavingsGoal extends React.Component{
  onSubmit = (formValues) => {
    this.props.addSavingsGoal(this.props.token,formValues);
  }
  onCancel = ()=> {
    history.push('/savings/')
  }

  render(){
    return (
      <SavingsGoalForm
        formTitle= "Add Savings Goal"
        working = {this.props.addingSavingsGoal}
        onCancel={this.onCancel}
        onSubmit={this.onSubmit}/>
    );
  }
}

const mapStateToProps = (state, ownProps)=> {
  return {
    token: state.auth.user.access,
    addingSavingsGoal: state.spending.addingSavingsGoal
  };
};
const actionCreators = {
  addSavingsGoal: savingsActions.addSavingsGoal
}

const connectedASG = connect(mapStateToProps,actionCreators)(AddSavingsGoal);
export {connectedASG as AddSavingsGoal};