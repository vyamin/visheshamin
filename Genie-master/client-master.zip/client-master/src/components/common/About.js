import React from 'react';
import {Container,Row,Col} from 'react-bootstrap';

export class About extends React.Component {
  render() {
    return (
      <Container>
        <br/><br/>
        <Row className="text-center">
          <Col>
            <h2>Genie</h2>
          </Col>
        </Row>
        <br/>
        <Row>
          <Col>
            <h3>Instantly Boost Your Credit</h3>
            <br/>
            <p>
              Genie figures out actions that you can take to boost your 
              credit - as soon as you sign up.
            </p>
            <p> 
              No extra payments, forms or signups needed. Its like magic.
            </p>          
          </Col>
          <Col>
            <h3>Credit Card Analysis</h3>
            <br/>
            <p>
            We’ll make sure that you the credit card(s) that you’re 
            using are the most beneficial for you. 
            </p>
            <p>
              If not, we’ll show you to quickly switch out of 
              those cards and introduce you to some better ones.
            </p>          
          </Col>
        </Row>
      </Container>
    );
  }
}
