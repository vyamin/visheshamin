import React from 'react';
import {connect} from 'react-redux';
import {Field,reduxForm} from 'redux-form';
import {Container,Row,Form,Button} from 'react-bootstrap';

import {authActions} from '../../actions';


class Register extends React.Component {
  onSubmit = (formValues)=> {
    this.props.register(formValues);
  }

  renderInputField = ({input,placeholder,type,meta})=>{
    const isInvalid = meta.touched && meta.error
    return (
      <React.Fragment>
        <Form.Control {...input} placeholder={placeholder} type={type} isInvalid={isInvalid} />
        {isInvalid && 
          <Form.Control.Feedback type="invalid">{meta.error}</Form.Control.Feedback>
        }
      </React.Fragment>
    );
  }

  render() {
    const {handleSubmit,working} = this.props;
    return(
      <Container>
        <br/>
        <Row className="justify-content-center">
          <Form onSubmit = {handleSubmit(this.onSubmit)} style={{width:600}}>
            <Form.Group className="text-center">
              <h2>Register with GenieApp</h2>
            </Form.Group>            
            <hr />
            <Form.Group>
              <Field name="name" component = {this.renderInputField} 
                  type="text" placeholder='Name' />
            </Form.Group>   
            <Form.Group>
              <Field name="email" component = {this.renderInputField} 
                  type="text" placeholder='Email' />
            </Form.Group> 
            <Form.Group>
              <Field name="password" component = {this.renderInputField} 
                  type="password" placeholder='Password' />
            </Form.Group>
            <Form.Group>
              <Field name="confirmPassword" component = {this.renderInputField} 
                  type="password" placeholder='ConfirmPassword' />    
            </Form.Group>
            <Form.Group className="text-center">
              <Button variant="primary" disabled={working} type="submit">Register</Button>
            </Form.Group>
          </Form>
        </Row>
      </Container>
    )
  }
}

const validate = formValues => {
  const errors = {};
  if (!formValues.name){
    errors.name = 'You must enter a name'
  }
  if (!formValues.email){
    errors.email = 'You must enter an email address'
  }
  if (!(/^\w+([.-]?\w+)*@\w+([.-]?\w+)*(.\w{2,3})+$/.test(formValues.email))){
    errors.email = 'You must enter a valid email address'
  }
  if (!formValues.password){
    errors.password = 'You must enter a password'
  }
  if (!(/(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}/.test(formValues.password))){
    errors.password = 'Must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters'
  }
  if (formValues.password !== formValues.confirmPassword){
    errors.confirmPassword = "Password and confirm password must match"
  }

  return errors;
}

const reduxedForm = reduxForm({
  form: 'register',
  validate
})(Register);

const mapStateToProps = (state, ownProps) => {
  return {
    working: state.auth.working
  }
}

const actionCreators = {
  register: authActions.register
}

const connectedRegister = connect(mapStateToProps,actionCreators)(reduxedForm);
export {connectedRegister as Register};
