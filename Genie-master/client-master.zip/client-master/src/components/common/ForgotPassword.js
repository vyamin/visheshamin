import React from 'react';
import {Container,Row,Col,Button,Form} from 'react-bootstrap';
import { reduxForm, Field } from 'redux-form';
import { connect } from 'react-redux';

import { authActions } from '../../actions';

class ForgotPassword extends React.Component{
  onSubmit = (formValues)=> {
    this.props.forgotPassword(formValues);
  }
  renderInputField = ({input,placeholder,type,meta})=>{
    if (meta.touched && meta.error){
      return (
        <React.Fragment>
          <Form.Control {...input} placeholder={placeholder} type={type} isInvalid={true} />
          <Form.Control.Feedback type="invalid">{meta.error}</Form.Control.Feedback>
        </React.Fragment>
      );
    }
    else{
      return <Form.Control {...input} placeholder={placeholder} type={type}/>
    }
  }  
  render(){
    return(
      <Container>
        <Row className="justify-content-center">
          <Col md={5}>
            <Container>
              <Row>
                <Col>
                  <Form onSubmit = {this.props.handleSubmit(this.onSubmit)}>
                    <Form.Group className="text-center">
                      <h3>Request password reset</h3>
                    </Form.Group>
                    <Form.Group>
                    <p>To reset your password, enter the email 
                      id you used during signup below.</p>
                    <p> A mail with reset instructions will be 
                      sent shortly.</p>
                    </Form.Group>
                    <Form.Group>
                      <Field name="email" component = {this.renderInputField}
                          type="text" placeholder="Email" />
                    </Form.Group>
                    <Form.Group className="text-center">
                      <Button variant="primary" disabled={this.props.working} type="submit">
                      Reset Password
                      </Button>
                    </Form.Group>
                  </Form>
                </Col>
              </Row>
            </Container>
          </Col>
        </Row>
      </Container>
    );
  }
}
const validate = (formValues)=> {
  const errors={};
  if (!formValues.email){
    errors.email = 'You must enter an email address'
  }
  if (!(/^\w+([.-]?\w+)*@\w+([.-]?\w+)*(.\w{2,3})+$/.test(formValues.email))){
    errors.email = 'You must enter a valid email address'
  }
  return errors;
}
const reduxedForm = reduxForm({
  form: 'forgotPassword',
  validate
})(ForgotPassword)

const mapStateToProps = (state, ownProps) => {
  return {
    working: state.auth.forgotPasswordWorking
  }
}
const actionCreators = {
  forgotPassword : authActions.forgotPassword
}

const connectedFP = connect(mapStateToProps,actionCreators)(reduxedForm);
export {connectedFP as ForgotPassword};