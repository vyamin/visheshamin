import React from 'react';
import {connect} from 'react-redux';

import {About, Dashboard} from '.';

class Home extends React.Component{
  render() {
    if (this.props.isAuthenticated){
      return <Dashboard/>
    }
    else {
      return <About/>
    }
  }
}

const mapStateToProps = (state,ownProps)=> {
  return {
    isAuthenticated: state.auth.isAuthenticated
  }
}

const connectedHome = connect(mapStateToProps,null)(Home);

export {connectedHome as Home};