import React from 'react';
import { connect } from 'react-redux';
import { Field, reduxForm} from 'redux-form';
import {Container,Row,Col,Button,Form} from 'react-bootstrap';

import {authActions} from '../../actions';

class PasswordReset extends React.Component{
  
  onSubmit = (formValues)=> {
    this.props.resetPassword(formValues);
  }

  renderInputField = ({input,placeholder,type,meta})=>{
    const isInvalid = meta.touched && meta.error
    return (
      <React.Fragment>
        <Form.Control {...input} placeholder={placeholder} type={type} isInvalid={isInvalid} />
        {isInvalid && 
          <Form.Control.Feedback type="invalid">{meta.error}</Form.Control.Feedback>
        }
      </React.Fragment>
    );
  }  
  render(){
    if(!this.props.initialValues.uid || !this.props.initialValues.token)
      return (<div>
        <p>This page requires more parameters in its URL.</p>
        <p>Please click or copy the entire url from the reset instructions email.</p>
      </div>)
    return(
      <Container>
        <Row className="justify-content-center">
          <Col md={6}>
            <Container>
              <Row>
                <Col>
                <Form onSubmit = {this.props.handleSubmit(this.onSubmit)}>
                  <Form.Group className="text-center">
                    <h3>Reset Password</h3>
                  </Form.Group>
                  {/* <Form.Group>
                    <Field name="uid" component = "input" 
                      type="hidden" value = {this.props.uid}/>
                    <Field name="token" component="input" 
                      type="hidden" value = {this.props.token}/>
                  </Form.Group> */}
                  <Form.Group>
                    <Field name="new_password" component = {this.renderInputField}
                      type="password" placeholder="Password"/>
                  </Form.Group>
                  <Form.Group>
                    <Field name="confirmPassword" component = {this.renderInputField}
                      type="password" placeholder="Confirm Password"/>
                  </Form.Group>
                  <Form.Group className="text-center">
                    <Button variant="primary" disabled={this.props.resettingPassword}
                      type="submit">Reset Password</Button>
                  </Form.Group>
                </Form>
                </Col>
              </Row>
            </Container>
          </Col>
        </Row>
      </Container>
    )
  }
}
const validate = (formValues)=> {
  const errors = {};
  if (!formValues.new_password){
    errors.new_password = 'You must enter a password'
  }
  if (!(/(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}/.test(formValues.new_password))){
    errors.new_password = 'Must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters'
  }
  if (formValues.new_password !== formValues.confirmPassword){
    errors.confirmPassword = "Password and confirm password must match"
  }
  return errors;
}

const reduxedForm = reduxForm({
  form: 'resetPassword',
  validate
})(PasswordReset)

const mapStateToProps = (state,ownProps) => {
  return {
    resettingPassword: state.auth.resettingPassword,
    initialValues: {
      uid: ownProps.match.params.uid,
      token: ownProps.match.params.token,
    }
  }
}

const actionCreators = {
  resetPassword: authActions.resetPassword
}

const connectedPR = connect(mapStateToProps,actionCreators)(reduxedForm)
export {connectedPR as PasswordReset};