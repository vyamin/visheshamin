import React from 'react';
import { withRouter } from 'react-router-dom'
import { connect } from 'react-redux'
import {Nav,Navbar} from 'react-bootstrap';
import {LinkContainer} from 'react-router-bootstrap';

import { authActions } from '../actions';


class Header extends React.Component {

  logout = () => {
    this.props.logout();
  }

  renderLogo() {
    return (
      <Navbar.Brand>
        <LinkContainer exact={true} to="/">
          <img className="logo" alt="logo" src="/logo192.png" width="30" height="30" />
        </LinkContainer>
      </Navbar.Brand>
    );
  }

  renderLoggedInMenu() {
    return (
        <Navbar expand="sm" collapseOnSelect={true} bg="dark" variant="dark">
          {this.renderLogo()}
          <Navbar.Toggle aria-controls="loggedin-navbar-nav" />
          <Navbar.Collapse id="loggedin-navbar-nav">
            <Nav className="mr-auto">
              <LinkContainer to="/wallet">
                <Nav.Link>Wallet</Nav.Link>
              </LinkContainer>
              <LinkContainer to="/income-summary">
                <Nav.Link>Income</Nav.Link>
              </LinkContainer>
              <LinkContainer to="/spending-summary">
                <Nav.Link>Spending</Nav.Link>
              </LinkContainer>
              <LinkContainer to="/savings-summary">
                <Nav.Link>Savings</Nav.Link>
              </LinkContainer>
            </Nav>
            <Nav className="ml-auto">
              <Nav.Link onClick={this.logout}>Logout</Nav.Link>
            </Nav>
          </Navbar.Collapse>
        </Navbar>
      );
  }

  renderLoggedOutMenu() {
    return (
      <Navbar expand="sm" collapseOnSelect={true} bg="dark" variant="dark">
        {this.renderLogo()}
        <Navbar.Toggle aria-controls="loggedout-navbar-nav" />
        <Navbar.Collapse id="loggedout-navbar-nav">
          <Nav className="ml-auto">
            <LinkContainer to="/register">
              <Nav.Link>Register</Nav.Link>
            </LinkContainer>
            <LinkContainer to="/login">
              <Nav.Link>Login</Nav.Link>
            </LinkContainer>
          </Nav>
        </Navbar.Collapse>
      </Navbar>
    );
  }
  render() {
    if (this.props.isAuthenticated)
      return this.renderLoggedInMenu()
    else
      return this.renderLoggedOutMenu()
  }
}

const HeaderWithRouter = withRouter(Header);
const mapStateToProps = (state, ownProps) => {
  return {
    isAuthenticated: state.auth.isAuthenticated
  }
};

const actionCreators = {
  logout: authActions.logout
}

const connectedHeader =  connect(mapStateToProps, 
                          actionCreators)(HeaderWithRouter);
export{connectedHeader as Header};