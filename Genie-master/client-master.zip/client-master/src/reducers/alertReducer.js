import {alertConstants} from '../constants'

export default (state={},action)=> {
  switch(action.type){
    case alertConstants.ALERT_SUCCESS:
      return {
        type: 'success',
        message: action.payload
      };
    case alertConstants.ALERT_ERROR:
      return {
        type: 'danger',
        message: action.payload
      }
    case alertConstants.ALERT_CLEAR:
      return {};
    
    default:
      return state
  }
}