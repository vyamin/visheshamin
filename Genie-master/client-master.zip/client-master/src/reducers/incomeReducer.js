import {authConstants, incomeConstants} from "../constants"
import _ from 'lodash';

const INITIAL_STATE={
  fetchingIncomeSummary:false,
  incomeSummary:null,
  fetchingIncomeList:false,
  incomeList:{},
  fetchingIncome:false,
  updatingIncome:false,
  addingIncome:false,
  deletingIncome:false,
}
export default (state=INITIAL_STATE,action) => {
  switch(action.type){
    case incomeConstants.GET_INCOME_SUMMARY_REQUEST:
      return {...state,fetchingIncomeSummary:true}
    case incomeConstants.GET_INCOME_SUMMARY_SUCCESS:
      return {...state,fetchingIncomeSummary:false,incomeSummary:action.payload}
    case incomeConstants.GET_INCOME_SUMMARY_FAILURE:
      return {...state,fetchingIncomeSummary:false}

    case incomeConstants.GET_INCOME_LIST_REQUEST:
      return {...state,fetchingIncomeList:true}
    case incomeConstants.GET_INCOME_LIST_SUCCESS:
      return {...state,fetchingIncomeList:false,incomeList:_.mapKeys(action.payload,'id')}
    case incomeConstants.GET_INCOME_LIST_FAILURE:
      return {...state,fetchingIncomeList:false}      

    case incomeConstants.GET_INCOME_REQUEST:
      return {...state,fetchingIncome:true}
    case incomeConstants.GET_INCOME_SUCCESS:{
      const incomeList = state.incomeList;
      incomeList[action.payload.id] = action.payload;
      return {...state,fetchingIncome:false,incomeList:incomeList}
    }
    case incomeConstants.GET_INCOME_FAILURE:
      return {...state,fetchingIncome:false}     
      
    case incomeConstants.UPDATE_INCOME_REQUEST:
      return {...state,updatingIncome:true}
    case incomeConstants.UPDATE_INCOME_SUCCESS:{
      const incomeList = state.incomeList;
      incomeList[action.payload.id] = action.payload;
      return {...state,updatingIncome:false,incomeList:incomeList}
    }
    case incomeConstants.UPDATE_INCOME_FAILURE:
      return {...state,updatingIncome:false}    
      
    case incomeConstants.ADD_INCOME_REQUEST:
      return {...state,addingIncome:true}
    case incomeConstants.ADD_INCOME_SUCCESS:{
      const incomeList = state.incomeList;
      incomeList[action.payload.id] = action.payload;
      return {...state,addingIncome:false,incomeList:incomeList}
    }
    case incomeConstants.ADD_INCOME_FAILURE:
      return {...state,addingIncome:false}        
    
    case incomeConstants.DELETE_INCOME_REQUEST:
      return {...state,deletingIncome:true}
    case incomeConstants.DELETE_INCOME_SUCCESS:{
      const incomeList = state.incomeList;
      return {...state,deletingIncome:false,incomeList:_.omit(incomeList,action.payload)}
    }
    case incomeConstants.DELETE_INCOME_FAILURE:
      return {...state,deletingIncome:false}              

    case authConstants.USER_LOGOUT:
      return {...INITIAL_STATE};
      
    default:
      return state;
    
  } 
};   