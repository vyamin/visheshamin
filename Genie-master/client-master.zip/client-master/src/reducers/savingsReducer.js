import _ from 'lodash'
import {authConstants, savingsConstants} from "../constants"

const INITIAL_STATE={
  fetchSavingsSummary:false,
  savingsSummary:null,
  fetchingSavingsGoals:false,
  savingsGoals:{},
  fetchingSavingsGoal:false,
  updatingSavingsGoal:false,
  addingSavingsGoal:false,
  deletingSavingsGoal:false,    
}
export default (state=INITIAL_STATE,action) => {
  switch(action.type){
    case savingsConstants.GET_SAVINGS_SUMMARY_REQUEST:
      return {...state,fetchSavingsSummary:true}
    case savingsConstants.GET_SAVINGS_SUMMARY_SUCCESS:
      return {...state,fetchSavingsSummary:false,savingsSummary:action.payload}
    case savingsConstants.GET_SAVINGS_SUMMARY_FAILURE:
      return {...state,fetchSavingsSummary:false}

    case savingsConstants.GET_SAVINGS_GOALS_REQUEST:
      return {...state,fetchingSavingsGoals:true}
    case savingsConstants.GET_SAVINGS_GOALS_SUCCESS:
      return {...state,fetchingSavingsGoals:false,savingsGoals:_.mapKeys(action.payload,'id')}
    case savingsConstants.GET_SAVINGS_GOALS_FAILURE:
      return {...state,fetchingSavingsGoals:false}      
    
    case savingsConstants.GET_SAVINGS_GOAL_REQUEST:
      return {...state,fetchingSavingsGoal:true}
    case savingsConstants.GET_SAVINGS_GOAL_SUCCESS:{
      const savingsGoals = state.savingsGoals;
      savingsGoals[action.payload.id] = action.payload;
      return {...state,fetchingSavingsGoal:false,savingsGoals:savingsGoals}
    }
    case savingsConstants.GET_SAVINGS_GOAL_FAILURE:
      return {...state,fetchingSavingsGoal:false}     
      
    case savingsConstants.UPDATE_SAVINGS_GOAL_REQUEST:
      return {...state,updatingSavingsGoal:true}
    case savingsConstants.UPDATE_SAVINGS_GOAL_SUCCESS:{
      const savingsGoals = state.savingsGoals;
      savingsGoals[action.payload.id] = action.payload;
      return {...state,updatingSavingsGoal:false,savingsGoals:savingsGoals}
    }
    case savingsConstants.UPDATE_SAVINGS_GOAL_FAILURE:
      return {...state,updatingSavingsGoal:false}    
      
    case savingsConstants.ADD_SAVINGS_GOAL_REQUEST:
      return {...state,addingSavingsGoal:true}
    case savingsConstants.ADD_SAVINGS_GOAL_SUCCESS:{
      const savingsGoals = state.savingsGoals;
      savingsGoals[action.payload.id] = action.payload;
      return {...state,addingSavingsGoal:false,savingsGoals:savingsGoals}
    }
    case savingsConstants.ADD_SAVINGS_GOAL_FAILURE:
      return {...state,addingSavingsGoal:false}        
    
    case savingsConstants.DELETE_SAVINGS_GOAL_REQUEST:
      return {...state,deletingSavingsGoal:true}
    case savingsConstants.DELETE_SAVINGS_GOAL_SUCCESS:{
      const savingsGoals = state.savingsGoals;
      return {...state,deletingSavingsGoal:false,savingsGoals:_.omit(savingsGoals,action.payload)}
    }
    case savingsConstants.DELETE_SAVINGS_GOAL_FAILURE:
      return {...state,deletingSavingsGoal:false}              
      
    case authConstants.USER_LOGOUT:{
      return {...INITIAL_STATE};
    }      
    default:
      return state;
  } 
};   