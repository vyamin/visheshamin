import {accountConstants} from '../constants';
import {accountService} from '../services';
import {alertActions} from '.';
import {history} from '../helpers'

export const accountActions = {
  fetchPlaidOptions,
  getPlaidAccessToken,
  getAccountList,
  getAccount,
  getTransactions
}


function fetchPlaidOptions(token){
  return async (dispatch,getState) => {
    dispatch(request());
    //await new Promise((resolve, reject) => setTimeout(resolve, 30000));
    try{
      const options = await accountService.fetchPlaidOptions(token)
      dispatch(success(options));
    }
    catch(error){
      dispatch(alertActions.error(error.message));
      dispatch(failure(error.message))
    }
    
  }
  function request() { return {type:accountConstants.PLAID_FETCH_OPTIONS_REQUEST}}
  function success(options) { return {type: accountConstants.PLAID_FETCH_OPTIONS_SUCCESS,payload:options}}
  function failure(message) { return {type: accountConstants.PLAID_FETCH_OPTIONS_FAILURE,payload:message}}

}

function getPlaidAccessToken(token,plaidPublicToken,forceFetchAccounts){
  return async (dispatch,getState) => {
    dispatch(request());
    try{
      await accountService.getPlaidAccessToken(token,plaidPublicToken)
      dispatch(success());
      if(forceFetchAccounts){
        dispatch(getAccountList(token))
      }
      history.push('/wallet');
    }
    catch(error){
      dispatch(alertActions.error(error.message));
      dispatch(failure(error.message))
    }
    
  }
  function request() { return {type:accountConstants.PLAID_GET_ACCESS_TOKEN_REQUEST}}
  function success() { return {type: accountConstants.PLAID_GET_ACCESS_TOKEN_SUCCESS}}
  function failure(message) { return {type: accountConstants.PLAID_GET_ACCESS_TOKEN_FAILURE,payload:message}}

}

function getAccountList(token){
  return async (dispatch,getState) => {
    dispatch(request());
    try{
      const accounts = await accountService.getAccountList(token)
      dispatch(success(accounts));
    }
    catch(error){
      dispatch(alertActions.error(error.message));
      dispatch(failure(error.message))
    }

  }
  function request() { return {type:accountConstants.GET_ACCOUNT_LIST_REQUEST}}
  function success(accounts) { return {type: accountConstants.GET_ACCOUNT_LIST_SUCCESS,payload:accounts}}
  function failure(message) { return {type: accountConstants.GET_ACCOUNT_LIST_FAILURE,payload:message}}

}

function getAccount(token,id){
  return async (dispatch,getState) => {
    dispatch(request());
    try{
      const account = await accountService.getAccount(token,id)
      dispatch(success(account));
    }
    catch(error){
      dispatch(alertActions.error(error.message));
      dispatch(failure(error.message))
    }

  }
  function request() { return {type:accountConstants.GET_ACCOUNT_REQUEST}}
  function success(account) { return {type: accountConstants.GET_ACCOUNT_SUCCESS,payload:account}}
  function failure(message) { return {type: accountConstants.GET_ACCOUNT_FAILURE,payload:message}}
}

function getTransactions(token,id){
  return async (dispatch,getState) => {
    dispatch(request());
    try{
      const transactions = await accountService.getTransactions(token,id)
      dispatch(success(transactions));
    }
    catch(error){
      dispatch(alertActions.error(error.message));
      dispatch(failure(error.message))
    }

  }
  function request() { return {type:accountConstants.GET_TRANSACTIONS_REQUEST}}
  function success(transactions) { return {type: accountConstants.GET_TRANSACTIONS_SUCCESS,payload:transactions}}
  function failure(message) { return {type: accountConstants.GET_TRANSACTIONS_FAILURE,payload:message}}
}