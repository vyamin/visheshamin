import {authConstants} from '../constants';
import {authService} from '../services';
import {alertActions} from '.'
import {history} from '../helpers'

export const authActions = {
  register,
  protectedRedirect,
  login,
  logout,
  forgotPassword,
  resetPassword
}

function register(formValues){
  return async(dispatch,getState) => {
    dispatch(request());
    let user = {}
    try {
      user = await authService.registerUser(formValues);
      dispatch(alertActions.success("User registration succeeded"));
    }
    catch(error){
      dispatch(alertActions.error(error.message))
      dispatch(failure(error.message))
      return
    }
    // Now let us try to login the user. If we introduce activation, this 
    // code should go
    try {
      const tokenParams = {email: formValues.email,password: formValues.password};
      user = await authService.createToken(tokenParams);
    }
    catch(error){
      //Nothing to do on error. User can try logging in 
    }
    finally{
      dispatch(success(user))
    }
    history.push('/')
  } 
  function request() { return {type:authConstants.USER_REGISTER_REQUEST}}
  function success(user) { return {type: authConstants.USER_REGISTER_SUCCESS,payload:user}}
  function failure(message) { return {type: authConstants.USER_REGISTER_FAILURE,payload:message}}
}

function protectedRedirect(path){
  return {
    type: authConstants.PROTECTED_PATH_REDIRECT,
    payload: path
  }
}

function login(formValues){
  return async(dispatch,getState) => {
    dispatch(request());
    try {
      const tokenParams = {email: formValues.email,password: formValues.password};
      const user = await authService.createToken(tokenParams);
      dispatch(success(user));
      history.push(getState().auth.protectedPathUrl);
      dispatch(protectedRedirect('/'));

    }
    catch(error){
      dispatch(alertActions.error(error.message))
      dispatch(failure(error.message))
    }
  } 
  function request() { return {type:authConstants.USER_LOGIN_REQUEST}}
  function success(user) { return {type: authConstants.USER_LOGIN_SUCCESS,payload:user}}
  function failure(message) { return {type: authConstants.USER_LOGIN_FAILURE,payload:message}}
}

function forgotPassword(formValues){
  return async(dispatch,getState) => {
    dispatch(request());
    try {
      const params = {email: formValues.email};
      const response = await authService.forgotPassword(params);
      dispatch(success(response));
      history.push('/')
      dispatch(alertActions.success('Check your email for reset instructions'))
    }
    catch(error){
      dispatch(alertActions.error(error.message))
      dispatch(failure(error.message))
    }
  } 
  function request() { return {type:authConstants.FORGOT_PASSWORD_REQUEST}}
  function success(response) { return {type: authConstants.FORGOT_PASSWORD_SUCCESS}}
  function failure(message) { return {type: authConstants.FORGOT_PASSWORD_FAILURE,payload:message}}
}

function resetPassword(formValues){
  return async(dispatch,getState) => {
    dispatch(request());
    try {
      const response = await authService.resetPassword(formValues);
      dispatch(success(response));
      history.push('/login')
      dispatch(alertActions.success('Password reset successful. Please login with your new password'))
    }
    catch(error){
      dispatch(alertActions.error(error.message))
      dispatch(failure(error.message))
    }
  } 
  function request() { return {type:authConstants.RESET_PASSWORD_REQUEST}}
  function success(response) { return {type: authConstants.RESET_PASSWORD_SUCCESS}}
  function failure(message) { return {type: authConstants.RESET_PASSWORD_FAILURE,payload:message}}
}

function logout(){
  return (dispatch,getState)=> {
    dispatch({
      type: authConstants.USER_LOGOUT
    })
    history.push('/');
  }
}