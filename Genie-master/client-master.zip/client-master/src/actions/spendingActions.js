import {spendingConstants} from '../constants';
import {spendingService} from '../services';
import {history} from '../helpers';

export const spendingActions = {
  getSpendingSummary,
  getUpcomingPayments,
  addUpcomingPayment,
  getUpcomingPayment,
  modifyUpcomingPayment,
  deleteUpcomingPayment
}


function getSpendingSummary(token){
  return async (dispatch,getState) => {
    dispatch(request());
    try{
      const spendingSummary = await spendingService.getSpendingSummary(token)
      dispatch(success(spendingSummary));
    }
    catch(error){
      dispatch(failure(error.message))
    }

  }
  function request() { return {type:spendingConstants.GET_SPENDING_SUMMARY_REQUEST}}
  function success(spendingSummary) { return {type: spendingConstants.GET_SPENDING_SUMMARY_SUCCESS,payload:spendingSummary}}
  function failure(message) { return {type: spendingConstants.GET_SPENDING_SUMMARY_FAILURE,payload:message}}
}

function getUpcomingPayments(token){
  return async (dispatch,getState) => {
    dispatch(request());
    try{
      const upcomingPayments = await spendingService.getUpcomingPayments(token)
      dispatch(success(upcomingPayments));
    }
    catch(error){
      dispatch(failure(error.message))
    }

  }
  function request() { return {type:spendingConstants.GET_UPCOMING_PAYMENTS_REQUEST}}
  function success(upcomingPayments) { return {type: spendingConstants.GET_UPCOMING_PAYMENTS_SUCCESS,payload:upcomingPayments}}
  function failure(message) { return {type: spendingConstants.GET_UPCOMING_PAYMENTS_FAILURE,payload:message}}
}

function addUpcomingPayment(token,formValues){
  return async (dispatch,getState) => {
    dispatch(request());
    try{
      const upcomingPayment = await spendingService.addUpcomingPayment(token,formValues)
      dispatch(success(upcomingPayment));
      history.push('/payments');
    }
    catch(error){
      dispatch(failure(error.message))
    }

  }
  function request() { return {type:spendingConstants.ADD_UPCOMING_PAYMENT_REQUEST}}
  function success(upcomingPayment) { return {type: spendingConstants.ADD_UPCOMING_PAYMENT_SUCCESS,payload:upcomingPayment}}
  function failure(message) { return {type: spendingConstants.ADD_UPCOMING_PAYMENT_FAILURE,payload:message}}
}

function getUpcomingPayment(token,id){
  return async (dispatch,getState) => {
    dispatch(request());
    try{
      const upcomingPayment = await spendingService.getUpcomingPayment(token,id);
      dispatch(success(upcomingPayment));
    }
    catch(error){
      dispatch(failure(error.message))
    }

  }
  function request() { return {type:spendingConstants.GET_UPCOMING_PAYMENT_REQUEST}}
  function success(upcomingPayment) { return {type: spendingConstants.GET_UPCOMING_PAYMENT_SUCCESS,payload:upcomingPayment}}
  function failure(message) { return {type: spendingConstants.GET_UPCOMING_PAYMENT_FAILURE,payload:message}}
}

function modifyUpcomingPayment(token,id,formValues){
  return async (dispatch,getState) => {
    dispatch(request());
    try{
      const upcomingPayment = await spendingService.modifyUpcomingPayment(token,id,formValues)
      dispatch(success(upcomingPayment));
      history.push('/payments');
    }
    catch(error){
      dispatch(failure(error.message))
    }

  }
  function request() { return {type:spendingConstants.UPDATE_UPCOMING_PAYMENT_REQUEST}}
  function success(upcomingPayment) { return {type: spendingConstants.UPDATE_UPCOMING_PAYMENT_SUCCESS,payload:upcomingPayment}}
  function failure(message) { return {type: spendingConstants.UPDATE_UPCOMING_PAYMENT_FAILURE,payload:message}}
}

function deleteUpcomingPayment(token,id){
  return async (dispatch,getState) => {
    dispatch(request());
    try{
      const response = await spendingService.deleteUpcomingPayment(token,id)
      dispatch(success(response));
    }
    catch(error){
      dispatch(failure(error.message))
    }

  }
  function request() { return {type:spendingConstants.DELETE_UPCOMING_PAYMENT_REQUEST}}
  function success(response) { return {type: spendingConstants.DELETE_UPCOMING_PAYMENT_SUCCESS,payload:response}}
  function failure(message) { return {type: spendingConstants.DELETE_UPCOMING_PAYMENT_FAILURE,payload:message}}
}

