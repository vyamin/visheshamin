import {genieWS} from '../apis'

export const authService = {
  registerUser,
  createToken,
  forgotPassword,
  resetPassword
}

//params = {name,email,password}
async function registerUser(params){
  try {
    //await new Promise((resolve, reject) => setTimeout(resolve, 3000));
    const response = await genieWS.genie.post('/auth/users/',params);
    const user = response.data;
    return user
  }
  catch (error){
    let errMessage = "Something went wrong. Try after some time"
    if(error.response && error.response.data)
      errMessage = Object.values(error.response.data).join();
    throw Error(errMessage)
  }
}

//params = {email,password}
async function createToken(params){
  try {
    // await new Promise((resolve, reject) => setTimeout(resolve, 10000));
    const response = await genieWS.genie.post('/auth/jwt/create/',params);
    const token = response.data;
    return token
  }
  catch (error){
    let errMessage = "Something went wrong. Try after some time"
    if(error.response && error.response.data)
      errMessage = Object.values(error.response.data).join();
    throw Error(errMessage)
  }
}

//params = {email}
async function forgotPassword(params){
  try {
    const response = await genieWS.genie.post('/auth/users/reset_password/',params);
    return response
  }
  catch (error){
    let errMessage = "Something went wrong. Try after some time"
    if(error.response && error.response.data)
      errMessage = Object.values(error.response.data).join();
    throw Error(errMessage)
  }
}

//params = {uid,token,password}
async function resetPassword(params){
  try {
    const response = await genieWS.genie.post('/auth/users/reset_password_confirm/',params);
    return response
  }
  catch (error){
    let errMessage = "Something went wrong. Try after some time"
    if(error.response && error.response.data)
      errMessage = Object.values(error.response.data).join();
    throw Error(errMessage)
  }
}