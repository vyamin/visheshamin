import {genieWS} from "../apis";

export const incomeService = {
  getIncomeSummary,
  getIncomeList,
  addIncome,
  getIncome,
  modifyIncome,
  deleteIncome
}

async function getIncomeSummary(token){
  const income_summary = await genieWS.get("income-summary/",token);
  return income_summary;
}

async function getIncomeList(token){
  const income_list = await genieWS.get("income/",token);
  return income_list;
}

async function addIncome(token,formValues){
  const response = await genieWS.post('income/',formValues,token)
  return response;
}

async function getIncome(token,id){
  const response = await genieWS.get('income/'+id+'/',token)
  return response;
}

async function modifyIncome(token,id,formValues){
  // await new Promise((resolve, reject) => setTimeout(resolve, 15000));
  const response = await genieWS.patch('income/'+id+'/',formValues,token)
  return response;
}

async function deleteIncome(token,id){
    const response = await genieWS.deleteResource('income/'+id+'/',token);
    return (response || id);
}