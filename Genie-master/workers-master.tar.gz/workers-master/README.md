# workers

Workers that help realise the features of advisor while running in background. These are simple independent modules that do specific tasks. These can be monitored and controlled from the advisor project.