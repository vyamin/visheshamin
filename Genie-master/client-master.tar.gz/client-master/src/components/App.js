import React from 'react';
import { Router, Route, Switch } from 'react-router-dom';
import { connect } from 'react-redux';
import {Container,Alert} from 'react-bootstrap';

import {history} from '../helpers';
import {alertActions} from "../actions"
import {Header} from '.';
import {Home, Login, Register,ProtectedRoute} from './common';
import {ForgotPassword,PasswordReset} from './common';
import {BankLink,Wallet,AccountShow,TransactionsList} from './accounts';
import {IncomeSummary,IncomeList,AddIncome,EditIncome} from './income';
import {SpendingSummary,UpcomingPayments} from './spending';
import {AddUpcomingPayment, EditUpcomingPayment} from './spending';
import {SavingsSummary,SavingsGoals} from './savings';
import {AddSavingsGoal,EditSavingsGoal} from './savings';

class App extends React.Component {

  constructor(props){
    super(props);
    const { dispatch } = this.props;
    history.listen((location,action)=> {
      dispatch(alertActions.clear())
    });
  }

  render (){
    const alert = this.props.alert;
    return (
      <Container>
        <Router history={history}>
          <div>
            <Header/>
            {
              alert.message && 
                <Alert  header={alert.message} variant={alert.type}>
                  {alert.message}
                </Alert>
            }
            <Switch>
              <Route path='/' exact component={Home} />
              <Route path="/register" exact component={Register} />
              <Route path='/login' exact component={Login}/>
              <Route path='/forgot-password' exact component={ForgotPassword}/>
              <Route path="/password-reset/" exact component={PasswordReset}/>
              <Route path="/password-reset/:uid/:token" exact component={PasswordReset}/>
              <ProtectedRoute path="/wallet" exact component={Wallet}/>
              <ProtectedRoute path="/accounts/:id" exact component={AccountShow}/>              
              <ProtectedRoute path="/add-account" exact component={BankLink}/>
              <ProtectedRoute path="/accounts/:id/transactions" exact component={TransactionsList}/>
              <ProtectedRoute path="/income-summary" exact component={IncomeSummary}/>
              <ProtectedRoute path="/incomes" exact component={IncomeList}/>
              <ProtectedRoute path="/incomes/new" exact component={AddIncome}/>
              <ProtectedRoute path="/incomes/edit/:id" exact component={EditIncome}/>
              <ProtectedRoute path="/payments" exact component={UpcomingPayments}/>
              <ProtectedRoute path="/payments/new" exact component={AddUpcomingPayment}/>
              <ProtectedRoute path="/payments/edit/:id" exact component={EditUpcomingPayment}/>
              <ProtectedRoute path="/savings" exact component={SavingsGoals}/>
              <ProtectedRoute path="/savings/new" exact component={AddSavingsGoal}/>
              <ProtectedRoute path="/savings/edit/:id" exact component={EditSavingsGoal}/>
              <ProtectedRoute path="/spending-summary" exact component={SpendingSummary}/>
              <ProtectedRoute path="/savings-summary" exact component={SavingsSummary}/>              
            </Switch>
          </div>
        </Router>
      </Container>
    );
  }
  
}

const mapStateToProps = state => {
  return {
    alert: state.alert
  }
}

const connectedApp =  connect(mapStateToProps, null)(App);
export {connectedApp as App};