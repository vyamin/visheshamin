import React from 'react';
import {Modal,Button} from 'react-bootstrap'

// Properties: show,header,message,onCancel,onCofirm
export class ConfirmDialog extends React.Component{
  render(){
    return(
      <Modal show={this.props.show} onHide={this.props.onCancel} centered>
        <Modal.Header closeButton>
          <Modal.Title>{this.props.header}</Modal.Title>
        </Modal.Header>
        <Modal.Body>{this.props.message}</Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={this.props.onCancel}>
            No
          </Button>
          <Button variant="primary" onClick={this.props.onConfirm}>
            Yes
          </Button>
        </Modal.Footer>
      </Modal>
    )
  }
}