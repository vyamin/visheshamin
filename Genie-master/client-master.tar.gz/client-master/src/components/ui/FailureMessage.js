import React from 'react'
import {Container,Row,Col,Button} from 'react-bootstrap';
import {Link} from 'react-router-dom';


export class FailureMessage extends React.Component{
  renderButton(){
    if(this.props.buttonRoute && this.props.buttonText){
      return (
        <Button as={Link} to={this.props.buttonRoute} variant='primary' size='large' 
        style={{marginTop: '2em'}}>
          {this.props.buttonText}
        </Button>
      );
    }
    return '';
  }
  render(){
    return (
      <Container>
        <Row className="justify-content-center mt-3">
          <Col md={8} className="text-center">
            <h4>{this.props.header}</h4>
            <p className="mt-1">{this.props.subheader}</p>
            {this.renderButton()}
          </Col>
        </Row>
      </Container>
    );
  }
};

