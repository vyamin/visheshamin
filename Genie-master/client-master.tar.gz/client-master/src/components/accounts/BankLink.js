import React from 'react'
import {connect} from 'react-redux';
import {PlaidLink} from 'react-plaid-link';

import {accountActions} from '../../actions';

class BankLink extends React.Component{

  componentDidMount(){
    this.props.fetchPlaidOptions(this.props.token);
  }

  onSuccess = (plaidToken)=> {
    this.props.getPlaidAccessToken(this.props.token,plaidToken,
                this.props.forceFetchAccounts)
  }
  render(){
    if(this.props.plaid_options){
      const options = this.props.plaid_options;
      let className = "ui button primary"
      if(this.props.fetchingAccessToken)
        className += " loading"
      return (
        <PlaidLink
        className= {className}
        style={{background: "#2185d0",outline:0, 
              padding:".8em 1.5em .8em", border:0,
            borderRadius:".28rem"}}
        clientName="Genie App"
        env= {options.env}
        product={options.product}
        publicKey={options.key}
        onSuccess={this.onSuccess}
        >
          {this.props.caption}
        </PlaidLink>
      );
    }
    else{
      return (
        <button
        className={"ui button primary disabled"}
        style={{background: "#2185d0",outline:0, 
              padding:".8em 1.5em .8em", border:0,
            borderRadius:".28rem",disabled:""}}
        >
          Connect your bank account
        </button>
      );
    }
  }
}

const mapStateToProps = (state, ownProps) => {
  return {
    token: state.auth.user.access,
    plaid_options: state.account.plaidLinkOptions,
    fetchingAccessToken: state.account.fetchingAccessToken
  }
}
const actionCreators = {
  fetchPlaidOptions:accountActions.fetchPlaidOptions,
  getPlaidAccessToken:accountActions.getPlaidAccessToken
}
const connectedBankLink =  connect(mapStateToProps,actionCreators)(BankLink);
export {connectedBankLink as BankLink}