import React from 'react';
import {connect} from 'react-redux';
import {Link} from 'react-router-dom';
import {Container,Row,Col,Card,CardDeck} from 'react-bootstrap';

import {accountActions} from '../../actions'
import {BankLink} from '.';

class Wallet extends React.Component{
  
  componentDidMount(){
    this.props.getAccountList(this.props.token);
  }

  renderCard(account){
    return(
      <Link key={account.id} to={"/accounts/"+account.id}>
        <Card className="mt-3" bg="light" style={{width: '18rem'}}>
          <Card.Body>
            <Card.Title>{account.nick_name}</Card.Title>
            <Card.Subtitle>{account.institution_name}</Card.Subtitle>
            <Card.Text>
              <br/>
              {account.currency+" "+account.current_balance}
            </Card.Text>
          </Card.Body>
        </Card>
      </Link>
    );
  }

  renderCardList(){
    if(this.props.accounts.length===0){
      if(this.props.fetchingAccounts){
        return <h3>Please wait while we fetch your accounts</h3>
      }
      else {
        return <h3>We do not have accounts to show currently</h3>
      }
    }    
    let cards = []
    for(const account of this.props.accounts){
      cards.push(this.renderCard(account));
    }
    return (
      <CardDeck>
        {cards}
      </CardDeck>
    );
  }

  render() {
    return (
      <Container>
        <Row className="justify-content-center" >
          <Col  md={8}>
            <h2 className="text-center">Accounts analysed by Genie</h2>
          </Col>
        </Row>
        <br/>
        <Row className="justify-content-center">
          {this.renderCardList()}
        </Row>
        <br/>
        <Row className="justify-content-center">
          <Col md={8} className="text-center">
            <BankLink caption='Add Bank Account' forceFetchAccounts={true} />
          </Col>
        </Row>
      </Container>
    );
  }
}

const mapStateToProps = (state,ownProps) => {
  return {
    token: state.auth.user.access,
    accounts: state.account.accounts,
    fetchingAccounts: state.account.fetchingAccounts,
    fetchingAccessToken: state.account.fetchingAccessToken
  }
}
const actionCreators = {
  getAccountList:accountActions.getAccountList
}
const connectedWallet =  connect(mapStateToProps,actionCreators)(Wallet);
export {connectedWallet as Wallet};