import React from 'react';
import {connect} from 'react-redux';
import {Container,Row,Col} from 'react-bootstrap';


import {accountActions,incomeActions} from '../../actions';
import {spendingActions,savingsActions} from '../../actions';
import {BankLink} from '../accounts';
import {LoadingMessage} from '../ui';
import {IncomeIndicator} from '../income';
import {SpendingIndicator} from '../spending';
import {SavingsIndicator} from '../savings';

class Dashboard extends React.Component {
  componentDidMount(){
    this.props.getAccountList(this.props.token);
    this.props.getIncomeSummary(this.props.token);
    this.props.getSpendingSummary(this.props.token);
    this.props.getSavingsSummary(this.props.token);

  }
  renderIncomeSummary(){
    if(this.props.accounts.length===0){
      return <p>
        Link your checking account to let us analyse your income.
      </p>
    }
    else{
      return <IncomeIndicator />
    }

  }
  renderSpendingSummary(){
    if(this.props.accounts.length===0){
      return <p>
        Link your credit cards to help us analyse and advise on spending.
      </p>
    }
    else{
      return <SpendingIndicator />
    }
  } 
  renderSavingsSummary(){
    if(this.props.accounts.length===0){
      return <p>
        Link your savings account for us to help you with your savings.
      </p>
    }
    else{
      return <SavingsIndicator />
    }
  }    
  renderBankLink(){
    if(this.props.accounts.length===0)
      return <BankLink caption="Connect your Bank Account"/> 
  }
  renderReccomendations(){
    return (  
      <React.Fragment>
        <h5>Recommendations</h5>
        <p>
          After analysing your linked financial accounts, 
          Genie will provide recommendations to improve your financial health.
        </p>
        <p>
          Check this section for regular updates.
        </p>
      </React.Fragment>);
  }
  render() {
    if(this.props.fetchingAccounts){
      return <LoadingMessage 
      header= "Just one second" 
      content= "We are loading your dashboard"
      />
    }
    return (
      <Container>
        <Row className="justify-content-center">
          <Col md={10}>
            <Container>
              <Row className="mt-3">
                <Col className="text-center">
                  <h2>Financial Overview</h2>
                </Col>
              </Row>
              <Row className="mt-2">
                <Col className="text-center">
                  <h4>Income</h4>
                  {this.renderIncomeSummary()}
                </Col>
                <Col className="text-center">
                  <h4>Spending</h4>
                  {this.renderSpendingSummary()}
                </Col>
              </Row>
              <hr/>
              <Row className="mt-2">
                <Col className="text-center">
                  <h4>Savings</h4>
                  {this.renderSavingsSummary()}
                </Col>
                <Col className="text-center">
                  {this.renderReccomendations()}
                </Col>                
              </Row>
              <Row>
                <Col className="text-center">
                  {this.renderBankLink()}
                </Col>
              </Row>
            </Container>
          </Col>
        </Row>
      </Container>
    )
  }
}

const mapStateToProps = (state,ownProps) => {
  return {
    token: state.auth.user.access,
    fetchingAccounts: state.account.fetchingAccounts,
    accounts: state.account.accounts
  }
}

const actionCreators = {
  getAccountList: accountActions.getAccountList,
  getIncomeSummary: incomeActions.getIncomeSummary,
  getSpendingSummary: spendingActions.getSpendingSummary,
  getSavingsSummary: savingsActions.getSavingsSummary
}

const connectedDashboard = connect(mapStateToProps,actionCreators)(Dashboard)

export {connectedDashboard as Dashboard};
