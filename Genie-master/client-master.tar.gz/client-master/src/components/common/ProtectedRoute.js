import React from 'react';
import {  Route, Redirect } from 'react-router-dom';
import { connect } from 'react-redux';

import {authActions} from '../../actions'

class ProtectedRoute extends React.Component {
  
  componentDidMount() {
    if(!this.props.isAuthenticated)
      this.props.protectedRedirect(this.props.path);
  }
  
  render() {  
    const{component:Component, ...props} = this.props
    return (
      <Route 
        {...props}
        render={props => (
          this.props.isAuthenticated ? 
          <Component {...props} />:
          <Redirect to='/login' />
        )}
      />
    );
  }
}

const mapStateToProps = state => {
  return {
    isAuthenticated: state.auth.isAuthenticated,
  }
}

const actionCreators = {
  protectedRedirect: authActions.protectedRedirect
}

const connectedPR = connect(mapStateToProps, actionCreators )(ProtectedRoute);
export {connectedPR as ProtectedRoute};