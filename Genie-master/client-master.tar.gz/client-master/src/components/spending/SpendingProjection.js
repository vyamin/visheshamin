import React from 'react';
import {connect} from 'react-redux';
import {Container,Row,Col} from 'react-bootstrap';
import {LineChart, Line, CartesianGrid,XAxis,YAxis, ResponsiveContainer} from 'recharts';

import {LoadingMessage} from '../ui';

class SpendingProjection extends React.Component{

  render(){
    if(this.props.fetchingSpendingSummary){
      return <LoadingMessage 
      header= "Just one second" 
      content= "We are loading your spending projection"
      />
    }
    if(!this.props.spendingSummary || this.props.spendingSummary.spending_projections.length===0){
      return '';
    }
    const spending_projections = this.props.spendingSummary.spending_projections;
    
    return (
      <Container className= "p-0">
        <Row className="justify-content-center my-2">
          <Col className="text-center">
            <h4>Projection of monthly spending</h4>
          </Col>
        </Row>
        <Row className="justify-content-center">
          <Col className="text-center p-0">
            <ResponsiveContainer width="95%" height={300}>
              <LineChart data={spending_projections}>
                <Line type="monotone" dataKey="amount" stroke="#8884d8"/>
                <CartesianGrid stroke="#ccc" />
                <XAxis dataKey="target_date" />
                <YAxis domain={['dataMin-1000','dataMax+1000']}/>
              </LineChart>
            </ResponsiveContainer>
          </Col>
        </Row>
      </Container>
    );
  }
}

const mapStateToProps= (state,ownProps) => {
  return {
    fetchingSpendingSummary: state.spending.fetchingSpendingSummary,
    spendingSummary: state.spending.spendingSummary
  }
}

const connectedSP = connect(mapStateToProps,null)(SpendingProjection);
export {connectedSP as SpendingProjection}