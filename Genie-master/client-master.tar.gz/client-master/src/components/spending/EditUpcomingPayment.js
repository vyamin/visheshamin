import React from 'react';
import { connect } from 'react-redux';
import _ from 'lodash';


import {UpcomingPaymentForm} from '.';
import {spendingActions} from '../../actions';
import {LoadingMessage} from '../ui';
import {history} from '../../helpers'

class EditUpcomingPayment extends React.Component{
  componentDidMount(){
    this.props.getUpcomingPayment(this.props.token,this.props.match.params.id);
  }
  
  onSubmit = (formValues) => {
    this.props.modifyUpcomingPayment(this.props.token,this.props.match.params.id, formValues);
  }

  onCancel = () => {
    history.push('/payments/');
  }

  render(){
    if(this.props.fetchingUpcomingPayment){
      return <LoadingMessage 
      header= "Just one second" 
      content= "We are loading your payments"
      />
    }
    return (
      <UpcomingPaymentForm
        initialValues={_.pick(this.props.upcomingPayment,'description','amount','due_date')}
        formTitle= "Modify Upcoming Payment"
        working = {this.props.updatingUpcomingPayment}
        onCancel={this.onCancel}
        onSubmit={this.onSubmit}/>
    );
  }
}

const mapStateToProps = (state, ownProps)=> {
  return {
    token: state.auth.user.access,
    fetchingUpcomingPayment: state.spending.fetchingUpcomingPayment,
    updatingUpcomingPayment: state.spending.updatingUpcomingPayment,
    upcomingPayment: state.spending.upcomingPayments[ownProps.match.params.id]
  };
};
const actionCreators = {
  getUpcomingPayment: spendingActions.getUpcomingPayment,
  modifyUpcomingPayment: spendingActions.modifyUpcomingPayment
}

const connectedEUP = connect(mapStateToProps,actionCreators)(EditUpcomingPayment);
export {connectedEUP as EditUpcomingPayment};