import React from 'react';
import {connect} from 'react-redux';
import {Container,Row,Col} from 'react-bootstrap';

import {CircularProgressbar, buildStyles} from 'react-circular-progressbar';
import 'react-circular-progressbar/dist/styles.css';

import {LoadingMessage} from '../ui';

class SpendingIndicator extends React.Component{

  render(){
    if(this.props.fetchingSpendingSummary){
      return <LoadingMessage 
      header= "Just one second" 
      content= "We are loading your spending summary"
      />
    }
    if(!this.props.spendingSummary || (
      this.props.spendingSummary.spending_summary.amount_spent_this_month===0 
      && this.props.spendingSummary.spending_summary.projected_monthly_spending===0
    )){
      return "";
    }
    const spenSum = this.props.spendingSummary;
    const value = spenSum.spending_summary.amount_spent_this_month;
    const total = spenSum.spending_summary.projected_monthly_spending;
    return(
        <Container>
          <Row className="justify-content-center">
            <Col className="text-center" style={{maxWidth:160}}>
              <CircularProgressbar value={value} maxValue={total}  
              text={value} styles={buildStyles({ pathColor: "red",
                trailColor: "lightgreen"})} />
              <h5 style={{marginTop:"0.5em"}}>Spending this month</h5>
            </Col>
          </Row>
        </Container>
    ) 
  }
}

const mapStateToProps= (state,ownProps) => {
  return {
    token: state.auth.user.access,
    fetchingSpendingSummary: state.spending.fetchingSpendingSummary,
    spendingSummary: state.spending.spendingSummary
  }
}

const connectedSI = connect(mapStateToProps,null)(SpendingIndicator);
export {connectedSI as SpendingIndicator};