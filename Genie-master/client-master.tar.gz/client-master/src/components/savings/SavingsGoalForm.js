import React from 'react'
import {Field,reduxForm} from 'redux-form'
import {Container,Row,Col,Button,Form } from 'react-bootstrap';

class SavingsGoalForm extends React.Component{
  
  renderInputField = ({input,label,placeholder,type,meta})=>{
    const isInvalid = meta.touched && meta.error
    return (
      <React.Fragment>
        <Form.Label>{label}</Form.Label>
        <Form.Control {...input} type={type} isInvalid={isInvalid} />
        {isInvalid && 
          <Form.Control.Feedback type="invalid">{meta.error}</Form.Control.Feedback>
        }
      </React.Fragment>
    );
  }
  onSubmit = (formValues)=> {
    this.props.onSubmit(formValues)
  }
  render(){
    return(
      <Container>
        <Row className="justify-content-center">
          <Col className="p-0" md={8}>
            <Form onSubmit={this.props.handleSubmit(this.onSubmit)} >
              <Form.Group className="text-center">
                <h2>{this.props.formTitle}</h2>
              </Form.Group>
              <Form.Group>
                <Field name="description" component={this.renderInputField}
                  type="text" label="Goal" />
              </Form.Group>
              <Form.Group>
                <Field name="amount" component={this.renderInputField}
                  type="number" label="Amount" />
              </Form.Group>
              <Form.Group>
                <Field name="target_date" component={this.renderInputField}
                  type="date" label="Target Date" />
              </Form.Group>              
              <Form.Group>
                <Container>
                  <Row>
                    <Col className = "text-left">
                    <Button variant="secondary" 
                        disabled={this.props.working} 
                        onClick={this.props.onCancel}
                        type="button">Cancel</Button>
                    </Col>
                    <Col className="text-right">
                      <Button variant="primary" 
                        disabled={this.props.working} 
                        type="submit">Submit</Button>
                    </Col>
                  </Row>
                </Container>
              </Form.Group>
            </Form>
          </Col>
        </Row>
      </Container>
    );
  }
}
const validate = (formValues) => {
  const errors={};
  if(!formValues.label){
    errors.label = "You must enter a Goal"
  }
  if(!formValues.amount || formValues.amount<=0){
    errors.amount = "You must enter a valid amount"
  }
  return errors;
}

const reduxedForm = reduxForm({
  form: 'savingsGoalForm',
  validate
})(SavingsGoalForm);

export {reduxedForm as SavingsGoalForm};





