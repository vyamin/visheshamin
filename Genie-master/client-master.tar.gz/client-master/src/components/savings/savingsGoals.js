import React from 'react'
import {Container,Row,Col,Button} from 'react-bootstrap'
import { connect } from 'react-redux';
import {Link} from 'react-router-dom';

import {history} from '../../helpers/history';
import { LoadingMessage, SimpleTableWithActions } from '../ui'
import { FailureMessage } from '../ui'

import {savingsActions} from '../../actions';

class SavingsGoals extends React.Component{

  componentDidMount(){
    this.props.getSavingsGoals(this.props.token)
  }

  onEditItem = (item)=>{
    history.push('/savings/edit/'+item.id);
  }

  onDeleteItem = (item)=>{
    this.props.deleteSavingsGoal(this.props.token,item.id);
  }

  renderTable(){
    const savingsGoals = this.props.savingsGoals;
    if(!savingsGoals){
      return <FailureMessage header="There are no savings goals currently."
          subheader="Try after some time"/>
    }

    return(
      <SimpleTableWithActions 
      header = {['Goal', 'Amount','Target Date']}
      fields = {['description','amount','target_date']}
      id_field = {'id'}
      items = {Object.values(savingsGoals)}
      itemType = {'Savings Goal'}
      onEditItem = {this.onEditItem}
      onDeleteItem = {this.onDeleteItem}/>
    );
  }
  render() {
    if(this.props.fetchingSavingsGoals){
      return <LoadingMessage 
      header= "Just one second" 
      content= "We are loading your goals"
      />
    }
    return (
      <Container>
        <Row className="justify-content-center">
          <Col md={8} className="p-0">
            <Container>
              <Row className="mt-3">
                <Col className="text-center">
                  <h3>Savings Goals</h3>
                </Col>
              </Row>
              <Row>
                <Col className="p-0">
                  {this.renderTable()}
                </Col>
              </Row>
              <Row>
                <Col className="text-right p-0">
                  <Button variant="primary" as={Link} to="/savings/new/">Add a Goal</Button>
                </Col>
              </Row>
            </Container>
          </Col>
        </Row>
      </Container>
    );
  }
}

const mapStateToProps = (state,ownProps)=>{
  return {
    token: state.auth.user.access,
    fetchingSavingsGoals: state.savings.fetchingSavingsGoals,
    savingsGoals: state.savings.savingsGoals,

  }
}

const actionCreators={
  getSavingsGoals: savingsActions.getSavingsGoals,
  deleteSavingsGoal: savingsActions.deleteSavingsGoal,
}

const connectedUP = connect(mapStateToProps,actionCreators)(SavingsGoals)
export {connectedUP as SavingsGoals};
