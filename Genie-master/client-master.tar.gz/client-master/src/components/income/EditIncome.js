import React from 'react';
import { connect } from 'react-redux';
import _ from 'lodash';


import {IncomeForm} from '.';
import {incomeActions} from '../../actions';
import {LoadingMessage} from '../ui';
import {history} from '../../helpers'

class EditIncome extends React.Component{
  componentDidMount(){
    this.props.getIncome(this.props.token,this.props.match.params.id);
  }
  
  onSubmit = (formValues) => {
    this.props.modifyIncome(this.props.token,this.props.match.params.id, formValues);
  }

  onCancel = () => {
    history.push('/incomes/');
  }

  render(){
    if(this.props.fetchingIncome){
      return <LoadingMessage 
      header= "Just one second" 
      content= "We are loading your income"
      />
    }
    return (
      <IncomeForm
        initialValues={_.pick(this.props.incomeSource,'label','amount')}
        formTitle= "Modify Income Source"
        working = {this.props.updatingIncome}
        onCancel={this.onCancel}
        onSubmit={this.onSubmit}/>
    );
  }
}

const mapStateToProps = (state, ownProps)=> {
  return {
    token: state.auth.user.access,
    fetchingIncome: state.income.fetchingIncome,
    updatingIncome: state.income.updatingIncome,
    incomeSource: state.income.incomeList[ownProps.match.params.id]
  };
};
const actionCreators = {
  getIncome: incomeActions.getIncome,
  modifyIncome: incomeActions.modifyIncome
}

const connectedEI = connect(mapStateToProps,actionCreators)(EditIncome);
export {connectedEI as EditIncome};