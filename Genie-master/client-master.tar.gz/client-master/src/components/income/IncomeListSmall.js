import React from 'react';
import {connect} from 'react-redux';
import {Link} from 'react-router-dom';
import {Container,Row,Col,Button} from 'react-bootstrap';

import {LoadingMessage,SimpleTable} from '../ui';

class IncomeListSmall extends React.Component{  
  render(){
    if(this.props.fetchingIncomeSummary){
      return <LoadingMessage 
      header= "Just one second" 
      content= "We are loading your income sources"
      />
    }
    const incomeSources = this.props.incomeSummary.incomes;
    return (
      <Container>
        <Row>
          <Col className="text-center">
            <h4>Sources of Income</h4>
          </Col>
        </Row>
        <Row>
          <Col>
            <SimpleTable header= {['Income Source','Amount']}
                  fields= {['label','amount']} 
                  id_field= {'id'} 
                  items={incomeSources}/>
          </Col>
        </Row>
        <Row>
          <Col className="text-right">
            <Link to="/incomes">
              <Button>Manage Sources</Button>
            </Link>
          </Col>
        </Row>
      </Container>
    );
  }
}

const mapStateToProps= (state,ownProps) => {
  return {
    fetchingIncomeSummary: state.income.fetchingIncomeSummary,
    incomeSummary: state.income.incomeSummary
  }
}

const connectedIL = connect(mapStateToProps,null)(IncomeListSmall);
export {connectedIL as IncomeListSmall}