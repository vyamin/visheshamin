import React from 'react';
import {connect} from 'react-redux';
import {Container,Row,Col} from 'react-bootstrap';

import {CircularProgressbar, buildStyles} from 'react-circular-progressbar';
import 'react-circular-progressbar/dist/styles.css';

import {LoadingMessage} from '../ui';

class IncomeIndicator extends React.Component{

  render(){
    if(this.props.fetchingIncomeSummary){
      return <LoadingMessage 
      header= "Just one second" 
      content= "We are loading your income summary"
      />
    }
    if(!this.props.incomeSummary || (
      this.props.incomeSummary.income_summary.amount_earned_this_month===0 
      && this.props.incomeSummary.income_summary.projected_monthly_income===0
    )){
      return ""
    }    
    const incSum = this.props.incomeSummary;
    const value = incSum.income_summary.amount_earned_this_month;
    const total = incSum.income_summary.projected_monthly_income;
    return(
        <Container>
          <Row className="justify-content-center">
            <Col className="text-center" style={{maxWidth:160}}>
              <CircularProgressbar value={value} maxValue={total}  
              text={value} styles={buildStyles({ pathColor: "blue",
                trailColor: "gray"})} />
              <h4 style={{marginTop:"0.5em"}}>Income this month</h4>
            </Col>
          </Row>
        </Container>
    ) 
  }
}

const mapStateToProps= (state,ownProps) => {
  return {
    fetchingIncomeSummary: state.income.fetchingIncomeSummary,
    incomeSummary: state.income.incomeSummary
  }
}
const connectedII = connect(mapStateToProps,null)(IncomeIndicator);
export {connectedII as IncomeIndicator}