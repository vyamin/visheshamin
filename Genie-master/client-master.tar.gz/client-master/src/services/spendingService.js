import {genieWS} from "../apis";

export const spendingService = {
  getSpendingSummary,
  getUpcomingPayments,
  addUpcomingPayment,
  getUpcomingPayment,
  modifyUpcomingPayment,
  deleteUpcomingPayment
}

async function getSpendingSummary(token){
  const spending_summary = await genieWS.get("spending-summary/",token);
  return spending_summary;
}

async function getUpcomingPayments(token){
  const upcomingPayments = await genieWS.get("payments/",token);
  return upcomingPayments;
}

async function addUpcomingPayment(token,formValues){
  const response = await genieWS.post('payments/',formValues,token)
  return response;
}

async function getUpcomingPayment(token,id){
  const response = await genieWS.get('payments/'+id+'/',token)
  return response;
}

async function modifyUpcomingPayment(token,id,formValues){
  // await new Promise((resolve, reject) => setTimeout(resolve, 15000));
  const response = await genieWS.patch('payments/'+id+'/',formValues,token)
  return response;
}

async function deleteUpcomingPayment(token,id){
    const response = await genieWS.deleteResource('payments/'+id+'/',token);
    return (response || id);
}