import {genieWS} from "../apis";

export const savingsService = {
  getSavingsSummary,
  getSavingsGoals,
  addSavingsGoal,
  getSavingsGoal,
  modifySavingsGoal,
  destroySavingsGoal
}

async function getSavingsSummary(token){
  const savings_summary = await genieWS.get("savings-summary/",token);
  return savings_summary;
}

async function getSavingsGoals(token){
  const savings_goals = await genieWS.get("savings-goals/",token);
  return savings_goals;
}

async function addSavingsGoal(token,formValues){
  const response = await genieWS.post('savings-goals/',formValues,token)
  return response;
}

async function getSavingsGoal(token,id){
  const response = await genieWS.get('savings-goals/'+id+'/',token)
  return response;
}

async function modifySavingsGoal(token,id,formValues){
  const response = await genieWS.patch('savings-goals/'+id+'/',formValues,token)
  return response;
}

async function destroySavingsGoal(token,id){
  const response = await genieWS.deleteResource('savings-goals/'+id+'/',token)
  return (response || id);
}