import {genieWS} from '../apis/genieWS'


export const accountService ={
  fetchPlaidOptions,
  getPlaidAccessToken,
  getAccountList,
  getAccount,
  getTransactions
}

async function fetchPlaidOptions(token){
  let options = await genieWS.get('genie/plaid-link-options/',token)
  options.product = JSON.parse(options.product)
  return options
}

async function getPlaidAccessToken(token,plaidPublicToken){
  await genieWS.post('genie/plaid-get-access-token/',
      {public_token:plaidPublicToken },token);
  return true;
}

async function getAccountList(token){
  const accounts = await genieWS.get('accounts/',token);
  return accounts;
}

async function getAccount(token,id){
  const account = await genieWS.get('accounts/'+id,token);
  return account;
}

async function getTransactions(token,id){
  const transactions = await genieWS.get('accounts/'+id+'/transactions',token)
  return transactions
}