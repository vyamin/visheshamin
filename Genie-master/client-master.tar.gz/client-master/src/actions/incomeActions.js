import {incomeConstants} from '../constants';
import {incomeService} from '../services';
import {history} from '../helpers';

export const incomeActions = {
  getIncomeSummary,
  getIncomeList,
  addIncome,
  getIncome,
  modifyIncome,
  deleteIncome
}



function getIncomeSummary(token){
  return async (dispatch,getState) => {
    dispatch(request());
    try{
      const incomeSummary = await incomeService.getIncomeSummary(token)
      dispatch(success(incomeSummary));
    }
    catch(error){
      dispatch(failure(error.message))
    }

  }
  function request() { return {type:incomeConstants.GET_INCOME_SUMMARY_REQUEST}}
  function success(incomeSummary) { return {type: incomeConstants.GET_INCOME_SUMMARY_SUCCESS,payload:incomeSummary}}
  function failure(message) { return {type: incomeConstants.GET_INCOME_SUMMARY_FAILURE,payload:message}}
}

function getIncomeList(token){
  return async (dispatch,getState) => {
    dispatch(request());
    try{
      const incomeList = await incomeService.getIncomeList(token)
      dispatch(success(incomeList));
    }
    catch(error){
      dispatch(failure(error.message))
    }

  }
  function request() { return {type:incomeConstants.GET_INCOME_LIST_REQUEST}}
  function success(incomeList) { return {type: incomeConstants.GET_INCOME_LIST_SUCCESS,payload:incomeList}}
  function failure(message) { return {type: incomeConstants.GET_INCOME_LIST_FAILURE,payload:message}}
}

function addIncome(token,formValues){
  return async (dispatch,getState) => {
    dispatch(request());
    try{
      const income = await incomeService.addIncome(token,formValues)
      dispatch(success(income));
      history.push('/incomes');
    }
    catch(error){
      dispatch(failure(error.message))
    }

  }
  function request() { return {type:incomeConstants.ADD_INCOME_REQUEST}}
  function success(income) { return {type: incomeConstants.ADD_INCOME_SUCCESS,payload:income}}
  function failure(message) { return {type: incomeConstants.ADD_INCOME_FAILURE,payload:message}}
}

function getIncome(token,id){
  return async (dispatch,getState) => {
    dispatch(request());
    try{
      const income = await incomeService.getIncome(token,id);
      dispatch(success(income));
    }
    catch(error){
      dispatch(failure(error.message))
    }

  }
  function request() { return {type:incomeConstants.GET_INCOME_REQUEST}}
  function success(income) { return {type: incomeConstants.GET_INCOME_SUCCESS,payload:income}}
  function failure(message) { return {type: incomeConstants.GET_INCOME_FAILURE,payload:message}}
}

function modifyIncome(token,id,formValues){
  return async (dispatch,getState) => {
    dispatch(request());
    try{
      const income = await incomeService.modifyIncome(token,id,formValues)
      dispatch(success(income));
      history.push('/incomes');
    }
    catch(error){
      dispatch(failure(error.message))
    }

  }
  function request() { return {type:incomeConstants.UPDATE_INCOME_REQUEST}}
  function success(income) { return {type: incomeConstants.UPDATE_INCOME_SUCCESS,payload:income}}
  function failure(message) { return {type: incomeConstants.UPDATE_INCOME_FAILURE,payload:message}}
}

function deleteIncome(token,id){
  return async (dispatch,getState) => {
    dispatch(request());
    try{
      const response = await incomeService.deleteIncome(token,id)
      dispatch(success(response));
    }
    catch(error){
      dispatch(failure(error.message))
    }

  }
  function request() { return {type:incomeConstants.DELETE_INCOME_REQUEST}}
  function success(response) { return {type: incomeConstants.DELETE_INCOME_SUCCESS,payload:response}}
  function failure(message) { return {type: incomeConstants.DELETE_INCOME_FAILURE,payload:message}}
}

