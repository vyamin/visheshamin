import {alertConstants} from '../constants'

export const alertActions = {
  success,
  error,
  clear
}

function success(message){
  return {
    type: alertConstants.ALERT_SUCCESS,
    payload: message
  };
}

function error(message){
  return {
    type: alertConstants.ALERT_ERROR,
    payload: message
  };
}

function clear(){
  return {
    type: alertConstants.ALERT_CLEAR
  };
}