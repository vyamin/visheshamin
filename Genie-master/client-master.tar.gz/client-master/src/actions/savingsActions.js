import {savingsConstants} from '../constants';
import {savingsService} from '../services';
import {history} from '../helpers';

export const savingsActions = {
  getSavingsSummary,
  getSavingsGoals,
  addSavingsGoal,
  getSavingsGoal,
  modifySavingsGoal,
  deleteSavingsGoal
}


function getSavingsSummary(token){
  return async (dispatch,getState) => {
    dispatch(request());
    try{
      const savingsSummary = await savingsService.getSavingsSummary(token)
      dispatch(success(savingsSummary));
    }
    catch(error){
      dispatch(failure(error.message))
    }

  }
  function request() { return {type:savingsConstants.GET_SAVINGS_SUMMARY_REQUEST}}
  function success(savingsSummary) { return {type: savingsConstants.GET_SAVINGS_SUMMARY_SUCCESS,payload:savingsSummary}}
  function failure(message) { return {type: savingsConstants.GET_SAVINGS_SUMMARY_FAILURE,payload:message}}
}

function getSavingsGoals(token){
  return async (dispatch,getState) => {
    dispatch(request());
    try{
      const incomeList = await savingsService.getSavingsGoals(token)
      dispatch(success(incomeList));
    }
    catch(error){
      dispatch(failure(error.message))
    }

  }
  function request() { return {type:savingsConstants.GET_SAVINGS_GOALS_REQUEST}}
  function success(incomeList) { return {type: savingsConstants.GET_SAVINGS_GOALS_SUCCESS,payload:incomeList}}
  function failure(message) { return {type: savingsConstants.GET_SAVINGS_GOALS_FAILURE,payload:message}}
}

function addSavingsGoal(token,formValues){
  return async (dispatch,getState) => {
    dispatch(request());
    try{
      const savingsGoal = await savingsService.addSavingsGoal(token,formValues)
      dispatch(success(savingsGoal));
      history.push('/savings');
    }
    catch(error){
      dispatch(failure(error.message))
    }

  }
  function request() { return {type:savingsConstants.ADD_SAVINGS_GOAL_REQUEST}}
  function success(savingsGoal) { return {type: savingsConstants.ADD_SAVINGS_GOAL_SUCCESS,payload:savingsGoal}}
  function failure(message) { return {type: savingsConstants.ADD_SAVINGS_GOAL_FAILURE,payload:message}}
}

function getSavingsGoal(token,id){
  return async (dispatch,getState) => {
    dispatch(request());
    try{
      const savingsGoal = await savingsService.getSavingsGoal(token,id);
      dispatch(success(savingsGoal));
    }
    catch(error){
      dispatch(failure(error.message))
    }

  }
  function request() { return {type:savingsConstants.GET_SAVINGS_GOAL_REQUEST}}
  function success(savingsGoal) { return {type: savingsConstants.GET_SAVINGS_GOAL_SUCCESS,payload:savingsGoal}}
  function failure(message) { return {type: savingsConstants.GET_SAVINGS_GOAL_FAILURE,payload:message}}
}

function modifySavingsGoal(token,id,formValues){
  return async (dispatch,getState) => {
    dispatch(request());
    try{
      const savingsGoal = await savingsService.modifySavingsGoal(token,id,formValues)
      dispatch(success(savingsGoal));
      history.push('/savings');
    }
    catch(error){
      dispatch(failure(error.message))
    }

  }
  function request() { return {type:savingsConstants.UPDATE_SAVINGS_GOAL_REQUEST}}
  function success(savingsGoal) { return {type: savingsConstants.UPDATE_SAVINGS_GOAL_SUCCESS,payload:savingsGoal}}
  function failure(message) { return {type: savingsConstants.UPDATE_SAVINGS_GOAL_FAILURE,payload:message}}
}

function deleteSavingsGoal(token,id){
  return async (dispatch,getState) => {
    dispatch(request());
    try{
      const response = await savingsService.destroySavingsGoal(token,id)
      dispatch(success(response));
    }
    catch(error){
      dispatch(failure(error.message))
    }

  }
  function request() { return {type:savingsConstants.DELETE_SAVINGS_GOAL_REQUEST}}
  function success(response) { return {type: savingsConstants.DELETE_SAVINGS_GOAL_SUCCESS,payload:response}}
  function failure(message) { return {type: savingsConstants.DELETE_SAVINGS_GOAL_FAILURE,payload:message}}
}