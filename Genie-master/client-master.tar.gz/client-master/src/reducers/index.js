import { combineReducers } from 'redux';
import { reducer as formReducer } from 'redux-form';

import authReducer from './authReducer';
import alertReducer from './alertReducer';
import accountReducer from './accountReducer';
import incomeReducer from './incomeReducer';
import spendingReducer from './spendingReducer';
import savingsReducer from './savingsReducer';


export default combineReducers({
  form: formReducer,
  auth: authReducer,
  alert: alertReducer,
  account: accountReducer,
  income: incomeReducer,
  spending: spendingReducer,
  savings: savingsReducer
});