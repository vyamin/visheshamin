import {authConstants, accountConstants} from "../constants"

const INITIAL_STATE={
  plaidLinkOptions:null,
  fetchingPlaidLinkOptions:false,
  fetchingAccessToken: false,
  fetchingAccounts: false,
  accounts:[],
  fetchingAccount: false,
  account:null,
  fetchingTransactions: false,
  transactions:[],
}
export default (state=INITIAL_STATE,action) => {
  switch(action.type){
    case accountConstants.PLAID_FETCH_OPTIONS_REQUEST:{
      return {...state,fetchingPlaidLinkOptions:true}
    }   
    case accountConstants.PLAID_FETCH_OPTIONS_SUCCESS:{
      return {...state,plaidLinkOptions:action.payload,fetchingPlaidLinkOptions:false}
    }   
    case accountConstants.PLAID_FETCH_OPTIONS_FAILURE:{
      return {...state,fetchingPlaidLinkOptions:false}
    }   
    
    case accountConstants.PLAID_GET_ACCESS_TOKEN_REQUEST:{
      return {...state,fetchingAccessToken:true}
    }
    case accountConstants.PLAID_GET_ACCESS_TOKEN_SUCCESS:{
      return {...state,fetchingAccessToken:false}
    }
    case accountConstants.PLAID_GET_ACCESS_TOKEN_FAILURE:{
      return {...state,fetchingAccessToken:false}
    }
    
    case accountConstants.GET_ACCOUNT_LIST_REQUEST:{
      return {...state,fetchingAccounts:true}
    }
    case accountConstants.GET_ACCOUNT_LIST_SUCCESS:{
      return {...state,accounts:action.payload,fetchingAccounts:false}
    }
    case accountConstants.GET_ACCOUNT_LIST_FAILURE:{
      return {...state,fetchingAccounts:false}
    }

    case accountConstants.GET_ACCOUNT_REQUEST:{
      return {...state,fetchingAccount:true,account:null}
    }
    case accountConstants.GET_ACCOUNT_SUCCESS:{
      return {...state,account:action.payload,fetchingAccount:false}
    }
    case accountConstants.GET_ACCOUNT_FAILURE:{
      return {...state,fetchingAccount:false}
    }

    case accountConstants.GET_TRANSACTIONS_REQUEST:{
      return {...state,fetchingTransactions:true}
    }
    case accountConstants.GET_TRANSACTIONS_SUCCESS:{
      return {...state,transactions:action.payload,fetchingTransactions:false}
    }
    case accountConstants.GET_TRANSACTIONS_FAILURE:{
      return {...state,fetchingTransactions:false}
    }    

    case authConstants.USER_LOGOUT:{
      return {...INITIAL_STATE};
    }   
    
    default:
      return state;
  }
}