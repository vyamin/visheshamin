import _ from 'lodash';
import {authConstants, spendingConstants} from "../constants"

const INITIAL_STATE={
  fetchingSpendingSummary:false,
  spendingSummary:null,
  fetchingUpcomingPayments:false,
  upcomingPayments:{},
  fetchingUpcomingPayment:false,
  updatingUpcomingPayment:false,
  addingUpcomingPayment:false,
  deletingUpcomingPayment:false,  
}
export default (state=INITIAL_STATE,action) => {
  switch(action.type){
    case spendingConstants.GET_SPENDING_SUMMARY_REQUEST:
      return {...state,fetchingSpendingSummary:true}
    case spendingConstants.GET_SPENDING_SUMMARY_SUCCESS:
      return {...state,fetchingSpendingSummary:false,spendingSummary:action.payload}
    case spendingConstants.GET_SPENDING_SUMMARY_FAILURE:
      return {...state,fetchingSpendingSummary:false}

    case spendingConstants.GET_UPCOMING_PAYMENTS_REQUEST:
      return {...state,fetchingUpcomingPayments:true}
    case spendingConstants.GET_UPCOMING_PAYMENTS_SUCCESS:
      return {...state,fetchingUpcomingPayments:false,upcomingPayments:_.mapKeys(action.payload,'id')}
    case spendingConstants.GET_UPCOMING_PAYMENTS_FAILURE:
      return {...state,fetchingUpcomingPayments:false}      
    
    case spendingConstants.GET_UPCOMING_PAYMENT_REQUEST:
      return {...state,fetchingUpcomingPayment:true}
    case spendingConstants.GET_UPCOMING_PAYMENT_SUCCESS:{
      const upcomingPayments = state.upcomingPayments;
      upcomingPayments[action.payload.id] = action.payload;
      return {...state,fetchingUpcomingPayment:false,upcomingPayments:upcomingPayments}
    }
    case spendingConstants.GET_UPCOMING_PAYMENT_FAILURE:
      return {...state,fetchingUpcomingPayment:false}     
      
    case spendingConstants.UPDATE_UPCOMING_PAYMENT_REQUEST:
      return {...state,updatingUpcomingPayment:true}
    case spendingConstants.UPDATE_UPCOMING_PAYMENT_SUCCESS:{
      const upcomingPayments = state.upcomingPayments;
      upcomingPayments[action.payload.id] = action.payload;
      return {...state,updatingUpcomingPayment:false,upcomingPayments:upcomingPayments}
    }
    case spendingConstants.UPDATE_UPCOMING_PAYMENT_FAILURE:
      return {...state,updatingUpcomingPayment:false}    
      
    case spendingConstants.ADD_UPCOMING_PAYMENT_REQUEST:
      return {...state,addingUpcomingPayment:true}
    case spendingConstants.ADD_UPCOMING_PAYMENT_SUCCESS:{
      const upcomingPayments = state.upcomingPayments;
      upcomingPayments[action.payload.id] = action.payload;
      return {...state,addingUpcomingPayment:false,upcomingPayments:upcomingPayments}
    }
    case spendingConstants.ADD_UPCOMING_PAYMENT_FAILURE:
      return {...state,addingUpcomingPayment:false}        
    
    case spendingConstants.DELETE_UPCOMING_PAYMENT_REQUEST:
      return {...state,deletingUpcomingPayment:true}
    case spendingConstants.DELETE_UPCOMING_PAYMENT_SUCCESS:{
      const upcomingPayments = state.upcomingPayments;
      return {...state,deletingUpcomingPayment:false,upcomingPayments:_.omit(upcomingPayments,action.payload)}
    }
    case spendingConstants.DELETE_UPCOMING_PAYMENT_FAILURE:
      return {...state,deletingUpcomingPayment:false}              
      

    case authConstants.USER_LOGOUT:{
      return {...INITIAL_STATE};
    }      
    default:
      return state;
    
  } 
};   