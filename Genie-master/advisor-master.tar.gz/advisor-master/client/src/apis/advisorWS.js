import axios from 'axios';
console.log(process.env.ADVISOR_API_SERVER)
const genie =  axios.create({
  baseURL: process.env.ADVISOR_API_SERVER
});

export const advisorWS = {
  genie,
  get,
  post,
  patch,
  deleteResource,
}

async function get(path,token){
  try {
    const response = await genie.get(path,{
      headers: {
        'Authorization': 'Bearer ' + token
      }
    });
    return response.data
  }
  catch (error){
    let errMessage = "Something went wrong. Try after some time"
    if(error.response && error.response.data)
      errMessage = Object.values(error.response.data).join();
    throw Error(errMessage)
  }
}

async function post(path,body,token){
  try {
    const response = await genie.post(path,body,
      {
      headers: {
        'Authorization': 'Bearer ' + token
      }
    });
    return response.data;
  }
  catch (error){
    let errMessage = "Something went wrong. Try after some time"
    if(error.response && error.response.data)
      errMessage = Object.values(error.response.data).join();
    throw Error(errMessage)
  }
}

async function patch(path,body,token){
  try {
    const response = await genie.patch(path,body,
      {
      headers: {
        'Authorization': 'Bearer ' + token
      }
    });
    return response.data;
  }
  catch (error){
    let errMessage = "Something went wrong. Try after some time"
    if(error.response && error.response.data)
      errMessage = Object.values(error.response.data).join();
    throw Error(errMessage)
  }
}

async function deleteResource(path,token){
  try {
    const response = await genie.delete(path,
      {
      headers: {
        'Authorization': 'Bearer ' + token
      }
    });
    return response.data;
  }
  catch (error){
    let errMessage = "Something went wrong. Try after some time"
    if(error.response && error.response.data)
      errMessage = Object.values(error.response.data).join();
    throw Error(errMessage)
  }
}