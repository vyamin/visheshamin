import React from 'react';
import {connect} from 'react-redux';
import {Field, reduxForm} from 'redux-form';
import {Container,Form,Row,Button,Spinner} from 'react-bootstrap';
import {LinkContainer} from 'react-router-bootstrap';


import {authActions} from '../../actions';
import {history} from '../../helpers';

class Login extends React.Component{

  onSubmit = (formValues)=> {
    this.props.login(formValues);
  }

  componentDidMount(){
    if(this.props.isAuthenticated)
      history.push(this.props.redirectUrl)
  }

  renderInputField = ({input,placeholder,type,meta})=>{
    if (meta.touched && meta.error){
      return (
        <React.Fragment>
          <Form.Control {...input} placeholder={placeholder} type={type} isInvalid={true} />
          <Form.Control.Feedback type="invalid">{meta.error}</Form.Control.Feedback>
        </React.Fragment>
      );
    }
    else{
      return <Form.Control {...input} placeholder={placeholder} type={type}/>
    }
  }  

  renderButton(label,busy){
    if(busy){
      return(
      <Button variant="primary"  disabled={true} type="submit">
        <Spinner as="span" animation="grow" size="sm" role="status" aria-hidden="true"/>
        {label}
      </Button>);
    }
    else {
      return(
      <Button variant="primary"  type="submit">
        {label}
      </Button>);
    }
  }


  render() {
    const {handleSubmit,working} = this.props;
    
    return(
      <Container>
        <br/>
        <Row className="justify-content-center">
          <Form onSubmit = {handleSubmit(this.onSubmit)}>
            <Form.Group className="text-center">
              <h2>Login to Advisor</h2>
            </Form.Group>
            <Form.Group>
              <Field name="email" component = {this.renderInputField} 
                    type="text" placeholder='Email' />
            </Form.Group>
            <Form.Group>                    
              <Field name="password" component = {this.renderInputField} 
                    type="password" placeholder='Password' />
            </Form.Group>      
            <Form.Group className="text-left">
              <LinkContainer to="/forgot-password">
                <a href='/'>Forgot Password</a>
              </LinkContainer>
            </Form.Group>      
            <Form.Group  className="text-center">
              {this.renderButton("Login",working)}
            </Form.Group>
          </Form>
        </Row>
      </Container>
    )
  }  
}

const validate = formValues => {
  const errors = {};
  if (!formValues.email){
    errors.email = 'You must enter an email address'
  }
  if (!(/^\w+([.-]?\w+)*@\w+([.-]?\w+)*(.\w{2,3})+$/.test(formValues.email))){
    errors.email = 'You must enter a valid email address'
  }
  if (!formValues.password){
    errors.password = 'You must enter a password'
  }
  return errors;
}


const reduxedForm = reduxForm({
  form: 'login',
  validate
})(Login);

const mapStateToProps = (state,ownProps)=> {
  return {
    isAuthenticated: state.auth.isAuthenticated,
    redirectUrl: state.auth.protectedPathUrl,
    working: state.auth.working
  }
}

const actionCreators = {
  login: authActions.login
}

const connectedLogin =  connect(mapStateToProps,actionCreators)(reduxedForm);
export {connectedLogin as Login};