from django.core.management.base import BaseCommand
from django.utils.crypto import get_random_string
from core.models.user import User


class Command(BaseCommand):
  help = "Creates a worker user and outputs the credentials"

  def handle(self,*args,**options):
    User.objects.filter(is_worker=True).delete()
    name = 'worker_'+get_random_string(7)
    email = name+"@genieapp.net"
    password = get_random_string(32)
    user = User.objects.create_worker(email,password,name=name)
    self.stdout.write('Advisor Email: '+email)
    self.stdout.write('Advisor Password: '+password)    
