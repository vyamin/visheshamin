from rest_framework_simplejwt.views import TokenObtainPairView
from rest_framework import permissions
from core.serializers import MyTokenObtainPairSerializer

class MyObtainTokenPairView(TokenObtainPairView):
  permission_classes = (permissions.AllowAny,)
  serializer_class = MyTokenObtainPairSerializer