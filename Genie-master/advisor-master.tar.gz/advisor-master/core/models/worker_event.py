from django.db import models
from django.utils import timezone
from django.contrib.postgres import fields

class WorkerEvent(models.Model):
  EventType = models.TextChoices('EventType','START SUCCESS FAILURE PROGRESS OTHER')
  
  worker = models.CharField(max_length=64)
  event_type = models.CharField(max_length=32,choices=EventType.choices)

  category = models.CharField(max_length=64,null=True,blank=True)
  subCategory = models.CharField(max_length=64,null=True,blank=True)
  int_result = models.IntegerField(null=True,blank=True)
  str_result = models.TextField(null=True,blank=True)
  json_result = fields.JSONField(null=True,blank=True)
  event_time = models.DateTimeField(default=timezone.now)

  def __str__(self):
    return "{}::{}::{}".format(self.worker,self.category,self.event_type)
