import factory

from core.models import WorkerEvent

class WorkerEventFactory(factory.django.DjangoModelFactory):
  class Meta:
    model = WorkerEvent
    
  worker = factory.Faker('random_element',elements=[
    'monthly_income','monthly_spending','monthly_savings',
    'income_sofar','spending_sofar','savings_sofar',
    'yearly_income','yearly_spending','yearly_savings'
  ])
  event_type = factory.Faker('random_element', elements = [
    'START','SUCCESS','FAILURE','PROGRESS','OTHER'
  ])
  int_result = factory.Faker('random_number')
  str_result = factory.Faker('sentence')