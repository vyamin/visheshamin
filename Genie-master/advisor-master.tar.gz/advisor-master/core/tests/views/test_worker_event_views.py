import pytest
import factory

from django.urls import reverse
from rest_framework import status
from core.models import WorkerEvent
from core.serializers import WorkerEventSerializer
from core.tests.fixtures.common_fixtures import *
from core.tests.factories import WorkerEventFactory
from django.utils import timezone

@pytest.mark.django_db
def test_worker_event_list_without_auth(api_client):
  WorkerEventFactory.create_batch(4)
  response = api_client.get(reverse('event-list'))
  assert response.status_code == status.HTTP_401_UNAUTHORIZED

@pytest.mark.django_db
def test_worker_event_list(api_client_with_cred):
  WorkerEventFactory.create_batch(4)
  response = api_client_with_cred.get(reverse('event-list'))
  assert response.status_code == status.HTTP_200_OK
  assert len(response.data) == 4


@pytest.mark.django_db
def test_worker_event_list_admin(api_client_with_admin_cred):
  WorkerEventFactory.create_batch(4)
  response = api_client_with_admin_cred.get(reverse('event-list'))
  assert response.status_code == status.HTTP_200_OK
  assert len(response.data) == 4

@pytest.mark.django_db
def test_worker_event_list_worker(api_client_with_worker_cred):
  WorkerEventFactory.create_batch(4)
  response = api_client_with_worker_cred.get(reverse('event-list'))
  assert response.status_code == status.HTTP_200_OK
  assert len(response.data) == 4


@pytest.mark.django_db
def test_worker_event_create_without_auth(api_client):
  worker_event = factory.build(dict,FACTORY_CLASS=WorkerEventFactory)
  response = api_client.post(reverse('event-list'),worker_event)
  assert response.status_code == status.HTTP_401_UNAUTHORIZED

@pytest.mark.django_db
def test_worker_event_create_normal_user(api_client_with_cred):
  worker_event = factory.build(dict,FACTORY_CLASS=WorkerEventFactory)
  response = api_client_with_cred.post(reverse('event-list'),worker_event)
  assert response.status_code == status.HTTP_403_FORBIDDEN

@pytest.mark.django_db
def test_worker_event_create_worker(api_client_with_worker_cred):
  worker_event = factory.build(dict,FACTORY_CLASS=WorkerEventFactory)
  response = api_client_with_worker_cred.post(reverse('event-list'),worker_event)
  assert response.status_code == status.HTTP_201_CREATED
  assert response.data['str_result'] == worker_event['str_result']

@pytest.mark.django_db
def test_worker_event_create_admin(api_client_with_admin_cred):
  worker_event = factory.build(dict,FACTORY_CLASS=WorkerEventFactory)
  response = api_client_with_admin_cred.post(reverse('event-list'),worker_event)
  assert response.status_code == status.HTTP_201_CREATED
  assert response.data['str_result'] == worker_event['str_result']  

@pytest.mark.django_db
def test_worker_event_retrieve_without_auth(api_client):
  worker_event = WorkerEventFactory()
  response = api_client.get(reverse('event-detail',args=[worker_event.id]))
  assert response.status_code == 401

@pytest.mark.django_db
def test_worker_event_retrieve_with_auth(api_client_with_cred):
  worker_event = WorkerEventFactory()
  response = api_client_with_cred.get(reverse('event-detail',args=[worker_event.id]))
  assert response.status_code == status.HTTP_200_OK
  assert response.data['str_result'] == worker_event.str_result

@pytest.mark.django_db
def test_worker_event_update_not_allowed(api_client_with_admin_cred):
  worker_event = WorkerEventFactory()
  data = {'str_result':'some string'}
  response = api_client_with_admin_cred.patch(
              reverse('event-detail',args=[worker_event.id]),data)
  assert response.status_code == status.HTTP_405_METHOD_NOT_ALLOWED

  